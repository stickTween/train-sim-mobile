import UIKit

enum Characters {

    static let coats: [UIColor] = [.rgb(0xC0392B), .rgb(0x2C6DBE), .rgb(0x2FA35A), .rgb(0xE8B33C),
                                   .rgb(0x8E44AD), .rgb(0xE67E22), .rgb(0x34495E)]
    static let skins: [UIColor] = [.rgb(0xE0B18C), .rgb(0xD6A57E), .rgb(0xC08E64), .rgb(0xF0C9A6)]
    static let hairs: [UIColor] = [.rgb(0x3A2A1E), .rgb(0x1E1814), .rgb(0x6B4A2C), .rgb(0xC9A24A)]

    static func draw(_ g: Pix, x: Int, base: Int, kind: Int, coat: Int,
                     phase: Double, running: Bool, facing: Int, day: Double) {
        let lit = max(0.4, day)
        switch kind {
        case 0:
            adult(g, x, base, coat, phase, running, facing, lit, female: false, old: false, hat: false)
        case 1:
            adult(g, x, base, coat + 3, phase, running, facing, lit, female: true, old: false, hat: false)
        case 2:
            adult(g, x - 5, base, coat, phase, running, facing, lit, female: false, old: false, hat: false)
            child(g, x + 6, base, coat + 2, phase + 0.7, running, facing, lit)
            hand(g, x - 1, base - 14, lit)
        case 3:
            adult(g, x - 5, base, coat + 4, phase, running, facing, lit, female: true, old: false, hat: false)
            child(g, x + 6, base, coat + 1, phase + 0.9, running, facing, lit)
            hand(g, x - 1, base - 14, lit)
        case 4:
            adult(g, x - 11, base, coat, phase, running, facing, lit, female: false, old: false, hat: false)
            child(g, x, base, coat + 5, phase + 0.5, running, facing, lit)
            adult(g, x + 11, base, coat + 4, phase + 0.3, running, facing, lit, female: true, old: false, hat: false)
            hand(g, x - 5, base - 14, lit)
            hand(g, x + 6, base - 14, lit)
        case 5:
            adult(g, x, base, 6, phase, running, facing, lit, female: true, old: true, hat: true)
            bag(g, x - 9, base - 10, .rgb(0x8A5A2A), lit)
            bag(g, x + 8, base - 10, .rgb(0x4A6A8A), lit)
        case 6:
            adult(g, x, base, 6, phase, running, facing, lit, female: false, old: true, hat: true)
            suitcase(g, x + 9, base - 8, lit)
        default:
            adult(g, x - 6, base, 6, phase, running, facing, lit, female: false, old: true, hat: true)
            adult(g, x + 7, base, 4, phase + 0.4, running, facing, lit, female: true, old: true, hat: true)
            hand(g, x + 1, base - 14, lit)
        }
    }

    private static func shade(_ c: UIColor, _ lit: Double) -> UIColor {
        WorldRenderer.mix(c.shade(-0.5), c, lit)
    }

    private static func adult(_ g: Pix, _ x: Int, _ base: Int, _ coat: Int, _ phase: Double,
                              _ running: Bool, _ facing: Int, _ lit: Double,
                              female: Bool, old: Bool, hat: Bool) {
        let swing = running ? 4.0 : 2.0
        let s = Int((sin(phase) * swing).rounded())
        let s2 = Int((sin(phase + .pi) * swing).rounded())
        let lean = running ? facing : 0
        let body = shade(old ? .rgb(0x6E6A72) : coats[coat % coats.count], lit)
        let trous = shade(old ? .rgb(0x4A4650) : .rgb(0x2A2F3A), lit)
        let skin = shade(skins[(coat + 1) % skins.count], lit)
        let hair = shade(old ? .rgb(0xC8CCD2) : hairs[coat % hairs.count], lit)

        g.rect(x - 3, base - 9, 3, 9, trous)
        g.rect(x + 1, base - 9, 3, 9, trous)
        g.rect(x - 3 + s, base - 2, 4, 2, shade(.rgb(0x1A1E24), lit))
        g.rect(x + 1 + s2, base - 2, 4, 2, shade(.rgb(0x1A1E24), lit))

        g.rect(x - 4 + lean, base - 21, 9, 12, body)
        g.rect(x - 4 + lean, base - 21, 9, 2, body.shade(0.18))
        if female {
            g.rect(x - 5 + lean, base - 12, 11, 4, body.shade(-0.1))
        }
        g.rect(x - 6 + lean + s2 / 2, base - 20, 2, 8, body.shade(-0.12))
        g.rect(x + 5 + lean + s / 2, base - 20, 2, 8, body.shade(-0.12))

        g.rect(x - 2 + lean, base - 27, 6, 6, skin)
        g.rect(x - 3 + lean, base - 29, 8, 3, hair)
        if hat {
            g.rect(x - 4 + lean, base - 31, 10, 2, shade(.rgb(0x3A4048), lit))
            g.rect(x - 2 + lean, base - 33, 6, 2, shade(.rgb(0x3A4048), lit))
        } else if female {
            g.rect(x - 4 + lean, base - 29, 9, 6, hair)
        }
        if facing > 0 {
            g.rect(x + 2 + lean, base - 26, 1, 1, .rgb(0x101418))
        } else {
            g.rect(x - 1 + lean, base - 26, 1, 1, .rgb(0x101418))
        }
    }

    private static func child(_ g: Pix, _ x: Int, _ base: Int, _ coat: Int, _ phase: Double,
                              _ running: Bool, _ facing: Int, _ lit: Double) {
        let swing = running ? 3.0 : 1.5
        let s = Int((sin(phase) * swing).rounded())
        let s2 = Int((sin(phase + .pi) * swing).rounded())
        let body = shade(coats[coat % coats.count], lit)
        let trous = shade(.rgb(0x33384A), lit)
        let skin = shade(skins[coat % skins.count], lit)
        let hair = shade(hairs[(coat + 2) % hairs.count], lit)
        g.rect(x - 2, base - 6, 2, 6, trous)
        g.rect(x + 1, base - 6, 2, 6, trous)
        g.rect(x - 2 + s, base - 1, 3, 1, shade(.rgb(0x1A1E24), lit))
        g.rect(x + 1 + s2, base - 1, 3, 1, shade(.rgb(0x1A1E24), lit))
        g.rect(x - 3, base - 14, 7, 8, body)
        g.rect(x - 1, base - 19, 5, 5, skin)
        g.rect(x - 2, base - 21, 7, 3, hair)
    }

    private static func hand(_ g: Pix, _ x: Int, _ y: Int, _ lit: Double) {
        g.rect(x, y, 4, 1, shade(.rgb(0xE0B18C), lit))
    }

    private static func bag(_ g: Pix, _ x: Int, _ y: Int, _ c: UIColor, _ lit: Double) {
        g.rect(x, y, 7, 9, shade(c, lit))
        g.rect(x, y, 7, 2, shade(c, lit).shade(0.2))
        g.rect(x + 2, y - 2, 3, 2, shade(.rgb(0x4A4038), lit))
    }

    private static func suitcase(_ g: Pix, _ x: Int, _ y: Int, _ lit: Double) {
        g.rect(x, y, 8, 10, shade(.rgb(0x6B4A2C), lit))
        g.rect(x, y + 4, 8, 1, shade(.rgb(0x3A2A18), lit))
        g.rect(x + 3, y - 3, 3, 3, shade(.rgb(0x3A2A18), lit))
        g.rect(x + 1, y + 10, 2, 2, .rgb(0x1A1E24))
        g.rect(x + 5, y + 10, 2, 2, .rgb(0x1A1E24))
    }
}
