import SceneKit
import UIKit

enum CabBuilder {

    static func build(_ s: TrainSpec, _ lang: Lang) -> SCNNode {
        let cab = SCNNode()
        let w: CGFloat = 2.9, h: CGFloat = 2.4, d: CGFloat = 2.9, t: CGFloat = 0.08
        let wallMat = Mat.pbr(s.wall, rough: 0.75, both: true)
        let darkMat = Mat.pbr(s.panel, rough: 0.6, both: true)

        cab.addChildNode(panel(w, t, d, SCNVector3(0, -0.04, 0), Mat.pbr(.hex(0x1B1E22), rough: 0.9, both: true)))
        cab.addChildNode(panel(w, t, d, SCNVector3(0, Float(h), 0), darkMat))
        cab.addChildNode(panel(w, h, t, SCNVector3(0, Float(h / 2), Float(d / 2)), wallMat))

        cab.addChildNode(panel(w, 1.05, t, SCNVector3(0, 0.52, -Float(d / 2)), darkMat))
        cab.addChildNode(panel(w, h - 1.95, t, SCNVector3(0, Float((1.95 + h) / 2), -Float(d / 2)), wallMat))
        for dx in [Float(-1), Float(1)] {
            cab.addChildNode(panel(w / 2 - 1.15, 0.9, t, SCNVector3(dx * 1.275, 1.5, -Float(d / 2)), wallMat))
        }

        for dx in [Float(-1), Float(1)] {
            let x = dx * Float(w / 2)
            cab.addChildNode(panel(d, 1.05, t, SCNVector3(x, 0.52, 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(panel(d, h - 1.9, t, SCNVector3(x, Float((1.9 + h) / 2), 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(panel(0.95, 0.85, t, SCNVector3(x, 1.475, Float(d / 2) - 0.48), wallMat, rotY: .pi / 2))
        }

        let strip = Mat.box(1.6, 0.05, 0.22, .hex(0xFFF6D8), chamfer: 0.02, both: true)
        strip.geometry?.firstMaterial = Mat.glow(.hex(0xFFF3D0))
        strip.position = SCNVector3(0, Float(h) - 0.07, 0.2)
        cab.addChildNode(strip)

        let console = SCNNode(geometry: SCNBox(width: 2.35, height: 0.15, length: 0.9, chamferRadius: 0.06))
        console.geometry?.firstMaterial = Mat.pbr(s.panel, rough: 0.45, both: true)
        console.position = SCNVector3(0, 1.0, -Float(d / 2) + 0.66)
        console.eulerAngles.x = -0.16
        cab.addChildNode(console)

        let front = Mat.box(2.6, 0.85, 0.1, s.panel, chamfer: 0.04, rough: 0.5, both: true)
        front.position = SCNVector3(0, 0.72, -Float(d / 2) + 0.09)
        cab.addChildNode(front)

        let dialNode = SCNNode(geometry: SCNPlane(width: 0.46, height: 0.46))
        let dm = SCNMaterial()
        dm.lightingModel = .lambert
        dm.diffuse.contents = Mat.dial(Int(s.maxSpeed))
        dialNode.geometry?.firstMaterial = dm
        dialNode.position = SCNVector3(-0.62, 0.86, -Float(d / 2) + 0.15)
        cab.addChildNode(dialNode)

        let needle = SCNNode()
        needle.name = "needle"
        let stick = Mat.box(0.02, 0.19, 0.01, .hex(0xE23B3B), chamfer: 0.005, both: true)
        stick.geometry?.firstMaterial = Mat.glow(.hex(0xE23B3B))
        stick.position = SCNVector3(0, 0.095, 0.012)
        needle.addChildNode(stick)
        needle.position = SCNVector3(0, 0, 0.01)
        dialNode.addChildNode(needle)

        let screen = SCNNode(geometry: SCNPlane(width: 0.72, height: 0.34))
        screen.name = "screen"
        let sm = SCNMaterial()
        sm.lightingModel = .constant
        sm.diffuse.contents = Mat.textImage("---", size: CGSize(width: 512, height: 242),
                                            bg: .hex(0x07130D), fg: .hex(0x4CE08A), font: 62)
        screen.geometry?.firstMaterial = sm
        screen.position = SCNVector3(0.52, 0.9, -Float(d / 2) + 0.15)
        cab.addChildNode(screen)

        console.addChildNode(button("btn_autostop", Loc.s("autostop", lang), .hex(0x2FA35A), -0.72, -0.14))
        console.addChildNode(button("btn_doors", Loc.s("doors", lang), .hex(0x2C6DBE), -0.24, -0.14))
        console.addChildNode(button("btn_lights", Loc.s("lights", lang), .hex(0xD5A021), 0.24, -0.14))
        console.addChildNode(button("btn_horn", Loc.s("horn", lang), .hex(0xC0392B), 0.72, -0.14))

        cab.addChildNode(lever("lever_throttle", Loc.s("throttle", lang), s.accent, x: -0.78, d: d))
        cab.addChildNode(lever("lever_brake", Loc.s("brake", lang), .hex(0xC0392B), x: 0.78, d: d))

        let seat = SCNNode()
        let cushion = Mat.box(0.62, 0.14, 0.6, s.seat, chamfer: 0.08, rough: 0.9, both: true)
        cushion.position = SCNVector3(0, 0.55, 0)
        seat.addChildNode(cushion)
        let backrest = Mat.box(0.62, 0.75, 0.14, s.seat, chamfer: 0.08, rough: 0.9, both: true)
        backrest.position = SCNVector3(0, 0.95, 0.3)
        backrest.eulerAngles.x = -0.12
        seat.addChildNode(backrest)
        let post = Mat.box(0.12, 0.55, 0.12, .hex(0x33383E), chamfer: 0.03, both: true)
        post.position = SCNVector3(0, 0.27, 0)
        seat.addChildNode(post)
        seat.position = SCNVector3(-0.2, 0, 0.45)
        cab.addChildNode(seat)

        let light = SCNNode()
        light.light = SCNLight()
        light.light?.type = .omni
        light.light?.intensity = 420
        light.light?.color = UIColor.hex(0xFFF0D6)
        light.position = SCNVector3(0, Float(h) - 0.25, 0.1)
        cab.addChildNode(light)

        return cab
    }

    private static func panel(_ w: CGFloat, _ h: CGFloat, _ t: CGFloat, _ pos: SCNVector3,
                              _ mat: SCNMaterial, rotY: Float = 0) -> SCNNode {
        let n = SCNNode(geometry: SCNBox(width: w, height: h, length: t, chamferRadius: 0.01))
        n.geometry?.firstMaterial = mat
        n.position = pos
        n.eulerAngles.y = rotY
        return n
    }

    private static func button(_ name: String, _ title: String, _ color: UIColor,
                               _ x: CGFloat, _ z: CGFloat) -> SCNNode {
        let holder = SCNNode()
        holder.name = name
        let cap = SCNNode(geometry: SCNBox(width: 0.19, height: 0.06, length: 0.19, chamferRadius: 0.025))
        cap.name = name + "_cap"
        cap.geometry?.firstMaterial = Mat.pbr(color, metal: 0.2, rough: 0.35)
        holder.addChildNode(cap)
        let lamp = SCNNode(geometry: SCNBox(width: 0.13, height: 0.02, length: 0.05, chamferRadius: 0.01))
        lamp.name = name + "_lamp"
        lamp.geometry?.firstMaterial = Mat.pbr(.hex(0x333A42), rough: 0.4)
        lamp.position = SCNVector3(0, 0.035, 0.05)
        holder.addChildNode(lamp)
        let lbl = Mat.label(title, w: 0.34, h: 0.1, bg: .hex(0x1A1E24), fg: .hex(0xE6EDF4), font: 92)
        lbl.position = SCNVector3(0, 0.1, 0.19)
        lbl.eulerAngles.x = -0.5
        holder.addChildNode(lbl)
        holder.position = SCNVector3(Float(x), 0.09, Float(z))
        return holder
    }

    private static func lever(_ name: String, _ title: String, _ color: UIColor, x: CGFloat, d: CGFloat) -> SCNNode {
        let root = SCNNode()
        let base = SCNNode(geometry: SCNBox(width: 0.34, height: 0.1, length: 0.5, chamferRadius: 0.04))
        base.geometry?.firstMaterial = Mat.pbr(.hex(0x22262B), rough: 0.5)
        root.addChildNode(base)

        let pivot = SCNNode()
        pivot.name = name
        let shaft = SCNNode(geometry: SCNCylinder(radius: 0.035, height: 0.42))
        shaft.geometry?.firstMaterial = Mat.pbr(.hex(0xB6BCC3), metal: 0.85, rough: 0.25)
        shaft.position = SCNVector3(0, 0.21, 0)
        pivot.addChildNode(shaft)
        let knob = SCNNode(geometry: SCNSphere(radius: 0.085))
        knob.geometry?.firstMaterial = Mat.pbr(color, rough: 0.35)
        knob.position = SCNVector3(0, 0.44, 0)
        pivot.addChildNode(knob)
        pivot.position = SCNVector3(0, 0.05, 0)
        root.addChildNode(pivot)

        let lbl = Mat.label(title, w: 0.36, h: 0.11, bg: .hex(0x1A1E24), fg: .hex(0xE6EDF4), font: 92)
        lbl.position = SCNVector3(0, 0.08, 0.3)
        lbl.eulerAngles.x = -0.6
        root.addChildNode(lbl)

        root.position = SCNVector3(Float(x), 1.05, -Float(d / 2) + 1.15)
        return root
    }
}
