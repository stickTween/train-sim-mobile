import SceneKit
import UIKit

enum CabBuilder {

    static let deskY: CGFloat = 0.93
    static let eyeHeight: Float = 1.25
    static let eyeZ: Float = 0.28

    static func build(_ s: TrainSpec, _ lang: Lang) -> SCNNode {
        let cab = SCNNode()
        let w: CGFloat = 3.0, h: CGFloat = 2.45, d: CGFloat = 3.0, t: CGFloat = 0.08
        let winBot: CGFloat = 1.02, winTop: CGFloat = 2.05, winHalf: CGFloat = 1.25
        let wallMat = Mat.pbr(s.wall, rough: 0.7, both: true)
        let ceilMat = Mat.pbr(s.ceiling, rough: 0.85, both: true)
        let trimMat = Mat.pbr(s.trim, rough: 0.55, both: true)

        cab.addChildNode(panel(w, t, d, SCNVector3(0, -0.04, 0), Mat.pbr(.hex(0x15181C), rough: 0.95, both: true)))
        cab.addChildNode(panel(w, t, d, SCNVector3(0, Float(h), 0), ceilMat))
        cab.addChildNode(panel(w, h, t, SCNVector3(0, Float(h / 2), Float(d / 2)), wallMat))

        cab.addChildNode(panel(w, winBot, t, SCNVector3(0, Float(winBot / 2), -Float(d / 2)), trimMat))
        cab.addChildNode(panel(w, h - winTop, t, SCNVector3(0, Float((winTop + h) / 2), -Float(d / 2)), wallMat))
        for dx in [Float(-1), Float(1)] {
            let pw = w / 2 - winHalf
            cab.addChildNode(panel(pw, winTop - winBot, t,
                                   SCNVector3(dx * Float(winHalf + pw / 2), Float((winBot + winTop) / 2), -Float(d / 2)),
                                   trimMat))
        }

        for dx in [Float(-1), Float(1)] {
            let x = dx * Float(w / 2)
            cab.addChildNode(panel(d, winBot, t, SCNVector3(x, Float(winBot / 2), 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(panel(d, h - 1.98, t, SCNVector3(x, Float((1.98 + h) / 2), 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(panel(1.05, 0.96, t, SCNVector3(x, Float(winBot + 0.48), Float(d / 2) - 0.52), wallMat, rotY: .pi / 2))
        }

        cab.addChildNode(ceilingConsole(s, w: w, h: h))

        let center = deskSegment(s, width: 1.72, depth: 0.82)
        center.position = SCNVector3(0, Float(deskY), -1.02)
        cab.addChildNode(center)
        center.addChildNode(centerConsole(s, lang))
        center.addChildNode(joystick("lever_throttle", Loc.s("throttle", lang), s.accent, SCNVector3(-0.46, 0.035, 0.13)))
        center.addChildNode(joystick("lever_brake", Loc.s("brake", lang), .hex(0xC0392B), SCNVector3(0.46, 0.035, 0.13)))

        for dx in [Float(-1), Float(1)] {
            let side = deskSegment(s, width: 1.08, depth: 0.74)
            side.position = SCNVector3(dx * 1.2, Float(deskY), -0.66)
            side.eulerAngles.y = dx * Float(s.wrap)
            cab.addChildNode(side)
            side.addChildNode(sideConsole(s, right: dx > 0))
        }

        cab.addChildNode(seatNode(s))

        for z in [Float(-0.6), Float(0.7)] {
            let light = SCNNode()
            light.light = SCNLight()
            light.light?.type = .omni
            light.light?.intensity = 380
            light.light?.attenuationEndDistance = 6
            light.light?.color = UIColor.hex(0xFFF3DE)
            light.position = SCNVector3(0, Float(h) - 0.3, z)
            cab.addChildNode(light)
        }

        return cab
    }

    private static func panel(_ w: CGFloat, _ h: CGFloat, _ t: CGFloat, _ pos: SCNVector3,
                              _ mat: SCNMaterial, rotY: Float = 0) -> SCNNode {
        let n = SCNNode(geometry: SCNBox(width: w, height: h, length: t, chamferRadius: 0.01))
        n.geometry?.firstMaterial = mat
        n.position = pos
        n.eulerAngles.y = rotY
        return n
    }

    private static func invisible() -> SCNMaterial {
        let m = SCNMaterial()
        m.diffuse.contents = UIColor.clear
        m.transparency = 0.0
        m.writesToDepthBuffer = false
        m.isDoubleSided = true
        return m
    }

    private static func deskSegment(_ s: TrainSpec, width: CGFloat, depth: CGFloat) -> SCNNode {
        let n = SCNNode()
        let top = Mat.box(width, 0.07, depth, s.deskTop, chamfer: 0.03, metal: 0.35, rough: 0.35, both: true)
        n.addChildNode(top)
        let lip = Mat.box(width + 0.06, 0.11, 0.1, s.trim, chamfer: 0.045, rough: 0.4, both: true)
        lip.position = SCNVector3(0, -0.005, Float(depth / 2))
        n.addChildNode(lip)
        let apron = Mat.box(width, 0.9, 0.1, s.deskBody, chamfer: 0.03, rough: 0.5, both: true)
        apron.position = SCNVector3(0, -0.49, Float(depth / 2) - 0.07)
        n.addChildNode(apron)
        let body = Mat.box(width - 0.12, 0.86, depth - 0.12, s.deskBody, chamfer: 0.03, rough: 0.6, both: true)
        body.position = SCNVector3(0, -0.47, 0)
        n.addChildNode(body)
        return n
    }

    private static func centerConsole(_ s: TrainSpec, _ lang: Lang) -> SCNNode {
        let plate = Mat.box(1.72, 0.66, 0.06, s.trim, chamfer: 0.03, rough: 0.5, both: true)
        plate.position = SCNVector3(0, 0.32, -0.33)
        plate.eulerAngles.x = -0.32

        plate.addChildNode(screenNode("MAIN", accent: .hex(0x17527F), kind: 0,
                                      w: 0.54, h: 0.34, name: "screen_main", pos: SCNVector3(-0.45, 0.13, 0.035)))
        plate.addChildNode(screenNode("ALS", accent: .hex(0x1E6B4A), kind: 3,
                                      w: 0.54, h: 0.34, name: nil, pos: SCNVector3(0.45, 0.13, 0.035)))
        plate.addChildNode(dialNode(s, pos: SCNVector3(0, 0.14, 0.035)))

        let defs: [(String, String, UIColor)] = [
            ("btn_autostop", Loc.s("autostop", lang), .hex(0x2FA35A)),
            ("btn_doors", Loc.s("doors", lang), .hex(0x2C6DBE)),
            ("btn_lights", Loc.s("lights", lang), .hex(0xD5A021)),
            ("btn_horn", Loc.s("horn", lang), .hex(0xC0392B))
        ]
        for (i, b) in defs.enumerated() {
            let x = -0.63 + CGFloat(i) * 0.42
            plate.addChildNode(roundButton(b.0, b.1, b.2, SCNVector3(Float(x), -0.19, 0.032)))
        }
        return plate
    }

    private static func sideConsole(_ s: TrainSpec, right: Bool) -> SCNNode {
        let plate = Mat.box(1.06, 0.6, 0.06, s.trim, chamfer: 0.03, rough: 0.5, both: true)
        plate.position = SCNVector3(0, 0.3, -0.29)
        plate.eulerAngles.x = -0.32

        plate.addChildNode(screenNode(right ? "DIAG" : "TRAIN", accent: .hex(0x2A3E66),
                                      kind: right ? 1 : 2, w: 0.62, h: 0.34, name: nil,
                                      pos: SCNVector3(0, 0.12, 0.035)))

        for i in 0..<5 {
            for j in 0..<2 {
                let key = SCNNode(geometry: SCNBox(width: 0.07, height: 0.05, length: 0.02, chamferRadius: 0.008))
                key.geometry?.firstMaterial = Mat.pbr(.hex(0x2B3138), rough: 0.5)
                key.position = SCNVector3(-0.32 + Float(i) * 0.082, -0.13 - Float(j) * 0.07, 0.035)
                plate.addChildNode(key)
            }
        }

        let lamps: [UIColor] = [.hex(0x2FA35A), .hex(0xD5A021), .hex(0xC0392B)]
        for (i, c) in lamps.enumerated() {
            let l = SCNNode(geometry: SCNCylinder(radius: 0.028, height: 0.02))
            l.geometry?.firstMaterial = Mat.glow(c)
            l.eulerAngles.x = .pi / 2
            l.position = SCNVector3(0.26 + Float(i) * 0.075, -0.16, 0.035)
            plate.addChildNode(l)
        }

        let node = SCNNode()
        node.addChildNode(plate)

        if right {
            let stop = SCNNode(geometry: SCNCylinder(radius: 0.075, height: 0.06))
            stop.geometry?.firstMaterial = Mat.pbr(.hex(0xB0261B), rough: 0.35)
            stop.position = SCNVector3(0.26, 0.06, 0.14)
            node.addChildNode(stop)
            let ring = SCNNode(geometry: SCNTube(innerRadius: 0.08, outerRadius: 0.1, height: 0.03))
            ring.geometry?.firstMaterial = Mat.pbr(.hex(0xE8C13A), rough: 0.5)
            ring.position = SCNVector3(0.26, 0.045, 0.14)
            node.addChildNode(ring)
        } else {
            let mic = SCNNode(geometry: SCNBox(width: 0.07, height: 0.05, length: 0.16, chamferRadius: 0.02))
            mic.geometry?.firstMaterial = Mat.pbr(.hex(0x1C2026), rough: 0.6)
            mic.position = SCNVector3(-0.3, 0.06, 0.16)
            node.addChildNode(mic)
        }
        return node
    }

    private static func screenNode(_ title: String, accent: UIColor, kind: Int,
                                   w: CGFloat, h: CGFloat, name: String?, pos: SCNVector3) -> SCNNode {
        let holder = SCNNode()
        let bezel = Mat.box(w + 0.05, h + 0.05, 0.03, .hex(0x0C0F13), chamfer: 0.012, rough: 0.5, both: true)
        holder.addChildNode(bezel)
        let plane = SCNNode(geometry: SCNPlane(width: w, height: h))
        plane.name = name
        let m = SCNMaterial()
        m.lightingModel = .constant
        m.diffuse.contents = Mat.hmi(title, accent: accent, kind: kind)
        plane.geometry?.firstMaterial = m
        plane.position = SCNVector3(0, 0, 0.017)
        holder.addChildNode(plane)
        holder.position = pos
        return holder
    }

    private static func dialNode(_ s: TrainSpec, pos: SCNVector3) -> SCNNode {
        let holder = SCNNode()
        let bezel = SCNNode(geometry: SCNTube(innerRadius: 0.155, outerRadius: 0.175, height: 0.03))
        bezel.geometry?.firstMaterial = Mat.pbr(.hex(0x0C0F13), rough: 0.5)
        bezel.eulerAngles.x = .pi / 2
        holder.addChildNode(bezel)

        let face = SCNNode(geometry: SCNPlane(width: 0.32, height: 0.32))
        let m = SCNMaterial()
        m.lightingModel = .constant
        m.diffuse.contents = Mat.dial(Int(s.maxSpeed))
        face.geometry?.firstMaterial = m
        face.position = SCNVector3(0, 0, 0.014)
        holder.addChildNode(face)

        let needle = SCNNode()
        needle.name = "needle"
        let stick = Mat.box(0.016, 0.13, 0.008, .hex(0xE23B3B), chamfer: 0.004, both: true)
        stick.geometry?.firstMaterial = Mat.glow(.hex(0xF04545))
        stick.position = SCNVector3(0, 0.065, 0)
        needle.addChildNode(stick)
        needle.position = SCNVector3(0, 0, 0.02)
        holder.addChildNode(needle)

        holder.position = pos
        return holder
    }

    private static func roundButton(_ name: String, _ title: String, _ color: UIColor, _ pos: SCNVector3) -> SCNNode {
        let holder = SCNNode()
        holder.name = name

        let cap = SCNNode(geometry: SCNCylinder(radius: 0.05, height: 0.035))
        cap.name = name + "_cap"
        cap.geometry?.firstMaterial = Mat.pbr(color, metal: 0.15, rough: 0.35)
        cap.eulerAngles.x = .pi / 2
        cap.position = SCNVector3(0, 0, 0.018)
        holder.addChildNode(cap)

        let ring = SCNNode(geometry: SCNTube(innerRadius: 0.052, outerRadius: 0.066, height: 0.022))
        ring.name = name + "_lamp"
        ring.geometry?.firstMaterial = Mat.pbr(.hex(0x2A3037), rough: 0.4)
        ring.eulerAngles.x = .pi / 2
        ring.position = SCNVector3(0, 0, 0.012)
        holder.addChildNode(ring)

        let lbl = Mat.label(title, w: 0.3, h: 0.072, bg: .hex(0x0E1216), fg: .hex(0xE8EFF5), font: 96)
        lbl.position = SCNVector3(0, 0.092, 0.032)
        holder.addChildNode(lbl)

        let grab = SCNNode(geometry: SCNBox(width: 0.24, height: 0.2, length: 0.14, chamferRadius: 0))
        grab.geometry?.firstMaterial = invisible()
        grab.position = SCNVector3(0, 0.01, 0.05)
        holder.addChildNode(grab)

        holder.position = pos
        return holder
    }

    private static func joystick(_ name: String, _ title: String, _ color: UIColor, _ pos: SCNVector3) -> SCNNode {
        let root = SCNNode()

        let pad = Mat.box(0.36, 0.035, 0.42, .hex(0x1A1E22), chamfer: 0.02, rough: 0.5, both: true)
        root.addChildNode(pad)

        let scale = Mat.box(0.1, 0.012, 0.34, .hex(0xB6BCC3), chamfer: 0.004, metal: 0.6, rough: 0.3, both: true)
        scale.position = SCNVector3(0.13, 0.024, 0)
        root.addChildNode(scale)

        let lbl = Mat.label(title, w: 0.32, h: 0.075, bg: .hex(0x0E1216), fg: .hex(0xE8EFF5), font: 96)
        lbl.eulerAngles.x = -0.85
        lbl.position = SCNVector3(0, 0.06, 0.21)
        root.addChildNode(lbl)

        let pivot = SCNNode()
        pivot.name = name

        let shaft = SCNNode(geometry: SCNCylinder(radius: 0.03, height: 0.22))
        shaft.geometry?.firstMaterial = Mat.pbr(.hex(0x2A2E33), metal: 0.45, rough: 0.4)
        shaft.position = SCNVector3(0, 0.11, 0)
        pivot.addChildNode(shaft)

        for i in 0..<4 {
            let rib = SCNNode(geometry: SCNTorus(ringRadius: 0.04, pipeRadius: 0.013))
            rib.geometry?.firstMaterial = Mat.pbr(.hex(0x0F1216), rough: 0.65)
            rib.position = SCNVector3(0, 0.12 + Float(i) * 0.048, 0)
            pivot.addChildNode(rib)
        }

        let cap = SCNNode(geometry: SCNSphere(radius: 0.058))
        cap.geometry?.firstMaterial = Mat.pbr(color, rough: 0.32)
        cap.position = SCNVector3(0, 0.33, 0)
        pivot.addChildNode(cap)

        let grab = SCNNode(geometry: SCNBox(width: 0.34, height: 0.5, length: 0.34, chamferRadius: 0))
        grab.geometry?.firstMaterial = invisible()
        grab.position = SCNVector3(0, 0.22, 0)
        pivot.addChildNode(grab)

        pivot.position = SCNVector3(0, 0.02, 0)
        root.addChildNode(pivot)

        root.position = pos
        return root
    }

    private static func ceilingConsole(_ s: TrainSpec, w: CGFloat, h: CGFloat) -> SCNNode {
        let n = SCNNode()
        let box = Mat.box(w - 0.5, 0.16, 0.5, s.trim, chamfer: 0.04, rough: 0.6, both: true)
        box.position = SCNVector3(0, Float(h) - 0.13, -0.75)
        n.addChildNode(box)
        for i in 0..<6 {
            let sw = SCNNode(geometry: SCNBox(width: 0.05, height: 0.05, length: 0.03, chamferRadius: 0.01))
            sw.geometry?.firstMaterial = Mat.pbr(.hex(0x3A4149), rough: 0.5)
            sw.position = SCNVector3(-0.42 + Float(i) * 0.17, Float(h) - 0.2, -0.51)
            n.addChildNode(sw)
        }
        let strip = Mat.box(1.5, 0.04, 0.18, .hex(0xFFF6D8), chamfer: 0.015, both: true)
        strip.geometry?.firstMaterial = Mat.glow(.hex(0xFFF3D0))
        strip.position = SCNVector3(0, Float(h) - 0.05, 0.35)
        n.addChildNode(strip)
        return n
    }

    private static func seatNode(_ s: TrainSpec) -> SCNNode {
        let seat = SCNNode()
        let fabric = Mat.pbr(s.seat, rough: 0.95, both: true)
        let frame = Mat.pbr(.hex(0x24282D), rough: 0.7, both: true)

        let cushion = SCNNode(geometry: SCNBox(width: 0.58, height: 0.16, length: 0.56, chamferRadius: 0.08))
        cushion.geometry?.firstMaterial = fabric
        cushion.position = SCNVector3(0, 0.5, 0)
        seat.addChildNode(cushion)

        let back = SCNNode(geometry: SCNBox(width: 0.58, height: 0.66, length: 0.16, chamferRadius: 0.08))
        back.geometry?.firstMaterial = fabric
        back.position = SCNVector3(0, 0.88, 0.28)
        back.eulerAngles.x = -0.14
        seat.addChildNode(back)

        let head = SCNNode(geometry: SCNBox(width: 0.34, height: 0.22, length: 0.14, chamferRadius: 0.06))
        head.geometry?.firstMaterial = fabric
        head.position = SCNVector3(0, 1.28, 0.32)
        seat.addChildNode(head)

        for dx in [Float(-1), Float(1)] {
            let arm = SCNNode(geometry: SCNBox(width: 0.1, height: 0.08, length: 0.42, chamferRadius: 0.04))
            arm.geometry?.firstMaterial = frame
            arm.position = SCNVector3(dx * 0.33, 0.68, 0.05)
            seat.addChildNode(arm)
        }

        let post = SCNNode(geometry: SCNCylinder(radius: 0.06, height: 0.42))
        post.geometry?.firstMaterial = frame
        post.position = SCNVector3(0, 0.23, 0)
        seat.addChildNode(post)

        let base = SCNNode(geometry: SCNCylinder(radius: 0.28, height: 0.06))
        base.geometry?.firstMaterial = frame
        base.position = SCNVector3(0, 0.04, 0)
        seat.addChildNode(base)

        seat.position = SCNVector3(0, 0, 0.72)
        return seat
    }
}
