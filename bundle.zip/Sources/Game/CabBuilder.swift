import SceneKit
import UIKit

enum CabBuilder {

    static let eyeHeight: Float = 1.27
    static let eyeZ: Float = 0.58

    private static let w: CGFloat = 3.02
    private static let h: CGFloat = 2.45
    private static let d: CGFloat = 3.3
    private static let t: CGFloat = 0.07
    private static let winBot: CGFloat = 1.00
    private static let winTop: CGFloat = 2.04
    private static let winHalf: CGFloat = 1.29
    private static let deskY: CGFloat = 0.90

    static func build(_ s: TrainSpec, _ lang: Lang) -> SCNNode {
        let cab = SCNNode()
        shell(s, into: cab)
        switch s.layout {
        case .lastochka: lastochkaDesk(s, lang, into: cab)
        case .sapsan: sapsanDesk(s, lang, into: cab)
        case .ivolga: ivolgaDesk(s, lang, into: cab)
        }
        lights(into: cab)
        return cab
    }

    private static func shell(_ s: TrainSpec, into cab: SCNNode) {
        let wallMat = Mat.pbr(s.wall, rough: 0.72, both: true)
        let lowerMat = Mat.pbr(s.wallLower, rough: 0.6, both: true)
        let ceilMat = Mat.pbr(s.ceiling, rough: 0.85, both: true)
        let trimMat = Mat.pbr(s.trim, rough: 0.5, both: true)
        let accentMat = Mat.pbr(s.cabAccent, metal: 0.1, rough: 0.4, both: true)

        let floor = SCNNode(geometry: SCNBox(width: w, height: t, length: d, chamferRadius: 0))
        let floorMat = Mat.tiled(Mat.ribbed(s.floorMat, groove: .hex(0x14181C)), 6, 6, rough: 0.95, both: true)
        floor.geometry?.firstMaterial = floorMat
        floor.position = SCNVector3(0, -Float(t / 2), 0)
        cab.addChildNode(floor)

        cab.addChildNode(plate(w, t, d, SCNVector3(0, Float(h), 0), ceilMat))
        cab.addChildNode(plate(w, h, t, SCNVector3(0, Float(h / 2), Float(d / 2)), wallMat))

        let doorFrame = Mat.box(0.86, 1.95, 0.05, s.trim, chamfer: 0.02, rough: 0.5, both: true)
        doorFrame.position = SCNVector3(0.7, 0.97, Float(d / 2) - 0.05)
        cab.addChildNode(doorFrame)
        let doorLeaf = Mat.box(0.76, 1.85, 0.04, s.wallLower, chamfer: 0.02, rough: 0.6, both: true)
        doorLeaf.position = SCNVector3(0.7, 0.95, Float(d / 2) - 0.09)
        cab.addChildNode(doorLeaf)

        cab.addChildNode(plate(w, winBot, t, SCNVector3(0, Float(winBot / 2), -Float(d / 2)), trimMat))
        cab.addChildNode(plate(w, h - winTop, t, SCNVector3(0, Float((winTop + h) / 2), -Float(d / 2)), wallMat))
        for dx in [Float(-1), Float(1)] {
            let pw = w / 2 - winHalf
            cab.addChildNode(plate(pw, winTop - winBot, t,
                                   SCNVector3(dx * Float(winHalf + pw / 2), Float((winBot + winTop) / 2), -Float(d / 2)),
                                   trimMat))
        }

        for dx in [Float(-1), Float(1)] {
            let arm = Mat.box(0.04, 0.72, 0.04, .hex(0x14181C), chamfer: 0.015, rough: 0.5, both: true)
            arm.eulerAngles.z = dx * 0.42
            arm.position = SCNVector3(dx * 0.55, Float(winBot) + 0.3, -Float(d / 2) - 0.09)
            cab.addChildNode(arm)
            let blade = Mat.box(0.78, 0.04, 0.03, .hex(0x0F1216), chamfer: 0.012, rough: 0.6, both: true)
            blade.eulerAngles.z = dx * 0.42
            blade.position = SCNVector3(dx * 0.78, Float(winBot) + 0.62, -Float(d / 2) - 0.1)
            cab.addChildNode(blade)
        }

        let visor = Mat.box(w - 0.3, 0.05, 0.28, s.trim, chamfer: 0.02, rough: 0.6, both: true)
        visor.position = SCNVector3(0, Float(winTop) - 0.09, -Float(d / 2) + 0.19)
        visor.eulerAngles.x = 0.32
        cab.addChildNode(visor)

        for dx in [Float(-1), Float(1)] {
            let x = dx * Float(w / 2)
            cab.addChildNode(plate(d, 0.44, t, SCNVector3(x, 0.22, 0), lowerMat, rotY: .pi / 2))
            cab.addChildNode(plate(d, winBot - 0.5, t, SCNVector3(x, Float(0.44 + (winBot - 0.5) / 2), 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(plate(d, 0.06, t + 0.01, SCNVector3(x, 0.47, 0), accentMat, rotY: .pi / 2))
            cab.addChildNode(plate(d, h - 1.92, t, SCNVector3(x, Float((1.92 + h) / 2), 0), wallMat, rotY: .pi / 2))
            cab.addChildNode(plate(1.15, 0.92, t, SCNVector3(x, Float(winBot + 0.46), Float(d / 2) - 0.57), wallMat, rotY: .pi / 2))

            let rail = SCNNode(geometry: SCNCylinder(radius: 0.022, height: 0.7))
            rail.geometry?.firstMaterial = Mat.pbr(.hex(0xB9C0C7), metal: 0.85, rough: 0.25)
            rail.eulerAngles.z = .pi / 2
            rail.position = SCNVector3(dx * Float(w / 2 - 0.09), 1.9, 0.9)
            cab.addChildNode(rail)
        }

        let accentBand = Mat.box(w - 0.06, 0.05, 0.05, s.cabAccent, chamfer: 0.02, rough: 0.4, both: true)
        accentBand.position = SCNVector3(0, Float(h) - 0.22, Float(d / 2) - 0.05)
        cab.addChildNode(accentBand)

        let ceilBox = Mat.box(w - 0.55, 0.17, 0.55, s.trim, chamfer: 0.04, rough: 0.6, both: true)
        ceilBox.position = SCNVector3(0, Float(h) - 0.13, -0.82)
        cab.addChildNode(ceilBox)
        for i in 0..<7 {
            let sw = Mat.box(0.05, 0.05, 0.03, .hex(0x454C55), chamfer: 0.012, rough: 0.5)
            sw.position = SCNVector3(-0.51 + Float(i) * 0.17, Float(h) - 0.2, -0.55)
            cab.addChildNode(sw)
        }
        let strip = Mat.box(1.7, 0.05, 0.2, .hex(0xFFF6DC), chamfer: 0.015, both: true)
        strip.geometry?.firstMaterial = Mat.glow(.hex(0xFFF2CC), strength: 0.9)
        strip.position = SCNVector3(0, Float(h) - 0.06, 0.45)
        cab.addChildNode(strip)

        let ext = SCNNode(geometry: SCNCylinder(radius: 0.075, height: 0.42))
        ext.geometry?.firstMaterial = Mat.pbr(.hex(0xC2231C), rough: 0.4)
        ext.position = SCNVector3(-Float(w / 2) + 0.16, 0.55, Float(d / 2) - 0.35)
        cab.addChildNode(ext)

        let warn = Mat.label("⚡", w: 0.16, h: 0.16, bg: .hex(0xE8C13A), fg: .black, font: 150)
        warn.position = SCNVector3(-Float(w / 2) + 0.09, 0.3, 0.4)
        warn.eulerAngles.y = .pi / 2
        cab.addChildNode(warn)
    }

    private static func lights(into cab: SCNNode) {
        for z in [Float(-0.7), Float(0.6)] {
            let light = SCNNode()
            light.light = SCNLight()
            light.light?.type = .omni
            light.light?.intensity = 260
            light.light?.attenuationStartDistance = 0.5
            light.light?.attenuationEndDistance = 5.5
            light.light?.color = UIColor.hex(0xFFF1D9)
            light.position = SCNVector3(0, Float(h) - 0.28, z)
            cab.addChildNode(light)
        }
        let fill = SCNNode()
        fill.light = SCNLight()
        fill.light?.type = .omni
        fill.light?.intensity = 130
        fill.light?.attenuationEndDistance = 3.5
        fill.light?.color = UIColor.hex(0xBFD8F0)
        fill.position = SCNVector3(0, 1.35, -1.0)
        cab.addChildNode(fill)
    }

    private static func plate(_ pw: CGFloat, _ ph: CGFloat, _ pt: CGFloat, _ pos: SCNVector3,
                              _ mat: SCNMaterial, rotY: Float = 0) -> SCNNode {
        let n = SCNNode(geometry: SCNBox(width: pw, height: ph, length: pt, chamferRadius: 0.008))
        n.geometry?.firstMaterial = mat
        n.position = pos
        n.eulerAngles.y = rotY
        return n
    }

    private static func invisible() -> SCNMaterial {
        let m = SCNMaterial()
        m.diffuse.contents = UIColor.clear
        m.transparency = 0.0
        m.writesToDepthBuffer = false
        m.isDoubleSided = true
        return m
    }

    private static func desk(_ s: TrainSpec, width: CGFloat, depth: CGFloat) -> SCNNode {
        let n = SCNNode()
        let top = SCNNode(geometry: SCNBox(width: width, height: 0.075, length: depth, chamferRadius: 0.03))
        top.geometry?.firstMaterial = Mat.tiled(Mat.noise(s.deskTop, .hex(0x000000).withAlphaComponent(0.08),
                                                          .hex(0xFFFFFF).withAlphaComponent(0.08), dots: 500),
                                                2, 2, metal: 0.3, rough: 0.42, both: true)
        n.addChildNode(top)

        let lip = Mat.box(width + 0.05, 0.1, 0.1, s.trim, chamfer: 0.045, rough: 0.45, both: true)
        lip.position = SCNVector3(0, -0.008, Float(depth / 2))
        n.addChildNode(lip)

        let accentLine = Mat.box(width + 0.055, 0.02, 0.055, s.cabAccent, chamfer: 0.008, rough: 0.4, both: true)
        accentLine.position = SCNVector3(0, 0.036, Float(depth / 2) + 0.005)
        n.addChildNode(accentLine)

        let apron = Mat.box(width, 0.92, 0.09, s.deskBody, chamfer: 0.03, rough: 0.55, both: true)
        apron.position = SCNVector3(0, -0.5, Float(depth / 2) - 0.06)
        n.addChildNode(apron)

        let body = Mat.box(width - 0.14, 0.88, depth - 0.14, s.deskBody, chamfer: 0.03, rough: 0.65, both: true)
        body.position = SCNVector3(0, -0.48, 0)
        n.addChildNode(body)
        return n
    }

    private static func console(_ s: TrainSpec, width: CGFloat, height: CGFloat, tilt: Float) -> SCNNode {
        let node = Mat.box(width, height, 0.06, s.trim, chamfer: 0.025, rough: 0.5, both: true)
        node.eulerAngles.x = tilt
        return node
    }

    private static func screen(_ title: String, accent: UIColor, kind: Int,
                               w sw: CGFloat, h sh: CGFloat, name: String?, pos: SCNVector3) -> SCNNode {
        let holder = SCNNode()
        let bezel = Mat.box(sw + 0.045, sh + 0.045, 0.028, .hex(0x0A0D11), chamfer: 0.012, rough: 0.45, both: true)
        holder.addChildNode(bezel)
        let plane = SCNNode(geometry: SCNPlane(width: sw, height: sh))
        plane.name = name
        let m = SCNMaterial()
        m.lightingModel = .constant
        m.diffuse.contents = Mat.hmi(title, accent: accent, kind: kind)
        plane.geometry?.firstMaterial = m
        plane.position = SCNVector3(0, 0, 0.016)
        holder.addChildNode(plane)
        holder.position = pos
        return holder
    }

    private static func speedo(_ s: TrainSpec, size: CGFloat, pos: SCNVector3) -> SCNNode {
        let holder = SCNNode()
        let bezel = SCNNode(geometry: SCNTube(innerRadius: size * 0.48, outerRadius: size * 0.55, height: 0.028))
        bezel.geometry?.firstMaterial = Mat.pbr(.hex(0x0A0D11), metal: 0.4, rough: 0.35)
        bezel.eulerAngles.x = .pi / 2
        holder.addChildNode(bezel)

        let face = SCNNode(geometry: SCNPlane(width: size, height: size))
        let m = SCNMaterial()
        m.lightingModel = .constant
        m.diffuse.contents = Mat.dial(Int(s.maxSpeed))
        face.geometry?.firstMaterial = m
        face.position = SCNVector3(0, 0, 0.013)
        holder.addChildNode(face)

        let needle = SCNNode()
        needle.name = "needle"
        let stick = Mat.box(0.015, size * 0.4, 0.008, .hex(0xF04545), chamfer: 0.004, both: true)
        stick.geometry?.firstMaterial = Mat.glow(.hex(0xF04545))
        stick.position = SCNVector3(0, Float(size * 0.2), 0)
        needle.addChildNode(stick)
        needle.position = SCNVector3(0, 0, 0.019)
        holder.addChildNode(needle)

        let hub = SCNNode(geometry: SCNSphere(radius: 0.018))
        hub.geometry?.firstMaterial = Mat.pbr(.hex(0x1A1F26), rough: 0.4)
        hub.position = SCNVector3(0, 0, 0.024)
        holder.addChildNode(hub)

        holder.position = pos
        return holder
    }

    private static func button(_ name: String, _ title: String, _ color: UIColor,
                               _ pos: SCNVector3, panel: UIColor) -> SCNNode {
        let holder = SCNNode()
        holder.name = name

        let cap = SCNNode(geometry: SCNCylinder(radius: 0.05, height: 0.034))
        cap.name = name + "_cap"
        cap.geometry?.firstMaterial = Mat.pbr(color, metal: 0.12, rough: 0.32)
        cap.eulerAngles.x = .pi / 2
        cap.position = SCNVector3(0, 0, 0.018)
        holder.addChildNode(cap)

        let ring = SCNNode(geometry: SCNTube(innerRadius: 0.052, outerRadius: 0.068, height: 0.022))
        ring.name = name + "_lamp"
        ring.geometry?.firstMaterial = Mat.pbr(.hex(0x2E353D), rough: 0.4)
        ring.eulerAngles.x = .pi / 2
        ring.position = SCNVector3(0, 0, 0.012)
        holder.addChildNode(ring)

        let lbl = Mat.label(title, w: 0.29, h: 0.062, bg: panel, fg: .hex(0xF0F5FA), font: 96)
        lbl.position = SCNVector3(0, 0.095, 0.031)
        holder.addChildNode(lbl)

        let grab = SCNNode(geometry: SCNBox(width: 0.26, height: 0.22, length: 0.16, chamferRadius: 0))
        grab.geometry?.firstMaterial = invisible()
        grab.position = SCNVector3(0, 0.01, 0.06)
        holder.addChildNode(grab)

        holder.position = pos
        return holder
    }

    private static func buttonRow(_ s: TrainSpec, _ lang: Lang, y: Float, spacing: Float, z: Float) -> [SCNNode] {
        let defs: [(String, String, UIColor)] = [
            ("btn_autostop", Loc.s("autostop", lang), .hex(0x2FA35A)),
            ("btn_doors", Loc.s("doors", lang), .hex(0x2C6DBE)),
            ("btn_lights", Loc.s("lights", lang), .hex(0xD5A021)),
            ("btn_horn", Loc.s("horn", lang), .hex(0xC0392B))
        ]
        var out: [SCNNode] = []
        for (i, b) in defs.enumerated() {
            let x = -spacing * 1.5 + Float(i) * spacing
            out.append(button(b.0, b.1, b.2, SCNVector3(x, y, z), panel: s.trim))
        }
        return out
    }

    private static func handleBase(_ name: String, _ title: String, _ panel: UIColor, _ pos: SCNVector3) -> (SCNNode, SCNNode) {
        let root = SCNNode()
        let pad = Mat.box(0.36, 0.035, 0.44, .hex(0x181C21), chamfer: 0.02, rough: 0.5, both: true)
        root.addChildNode(pad)

        let notches = Mat.box(0.08, 0.014, 0.36, .hex(0xAEB6BE), chamfer: 0.004, metal: 0.7, rough: 0.25, both: true)
        notches.position = SCNVector3(0.13, 0.024, 0)
        root.addChildNode(notches)

        let lbl = Mat.label(title, w: 0.3, h: 0.065, bg: panel, fg: .hex(0xF0F5FA), font: 96)
        lbl.eulerAngles.x = -0.9
        lbl.position = SCNVector3(0, 0.055, 0.225)
        root.addChildNode(lbl)

        let pivot = SCNNode()
        pivot.name = name
        pivot.position = SCNVector3(0, 0.02, 0)
        root.addChildNode(pivot)

        let grab = SCNNode(geometry: SCNBox(width: 0.36, height: 0.52, length: 0.36, chamferRadius: 0))
        grab.geometry?.firstMaterial = invisible()
        grab.position = SCNVector3(0, 0.24, 0)
        pivot.addChildNode(grab)

        root.position = pos
        return (root, pivot)
    }

    private static func ribbedHandle(_ name: String, _ title: String, _ color: UIColor,
                                     _ panel: UIColor, _ pos: SCNVector3) -> SCNNode {
        let (root, pivot) = handleBase(name, title, panel, pos)
        let shaft = SCNNode(geometry: SCNCylinder(radius: 0.029, height: 0.24))
        shaft.geometry?.firstMaterial = Mat.pbr(.hex(0x272C32), metal: 0.4, rough: 0.4)
        shaft.position = SCNVector3(0, 0.12, 0)
        pivot.addChildNode(shaft)
        for i in 0..<4 {
            let rib = SCNNode(geometry: SCNTorus(ringRadius: 0.04, pipeRadius: 0.013))
            rib.geometry?.firstMaterial = Mat.pbr(.hex(0x0F1216), rough: 0.7)
            rib.position = SCNVector3(0, 0.13 + Float(i) * 0.05, 0)
            pivot.addChildNode(rib)
        }
        let cap = SCNNode(geometry: SCNSphere(radius: 0.057))
        cap.geometry?.firstMaterial = Mat.pbr(color, rough: 0.3)
        cap.position = SCNVector3(0, 0.35, 0)
        pivot.addChildNode(cap)
        return root
    }

    private static func tHandle(_ name: String, _ title: String, _ color: UIColor,
                                _ panel: UIColor, _ pos: SCNVector3) -> SCNNode {
        let (root, pivot) = handleBase(name, title, panel, pos)
        let shaft = SCNNode(geometry: SCNCylinder(radius: 0.026, height: 0.34))
        shaft.geometry?.firstMaterial = Mat.pbr(.hex(0xA8B0B8), metal: 0.8, rough: 0.25)
        shaft.position = SCNVector3(0, 0.17, 0)
        pivot.addChildNode(shaft)
        let bar = SCNNode(geometry: SCNCylinder(radius: 0.032, height: 0.3))
        bar.geometry?.firstMaterial = Mat.pbr(color, rough: 0.3)
        bar.eulerAngles.z = .pi / 2
        bar.position = SCNVector3(0, 0.35, 0)
        pivot.addChildNode(bar)
        for dx in [Float(-1), Float(1)] {
            let end = SCNNode(geometry: SCNSphere(radius: 0.036))
            end.geometry?.firstMaterial = Mat.pbr(color, rough: 0.3)
            end.position = SCNVector3(dx * 0.15, 0.35, 0)
            pivot.addChildNode(end)
        }
        return root
    }

    private static func wheelHandle(_ name: String, _ title: String, _ color: UIColor,
                                    _ panel: UIColor, _ pos: SCNVector3) -> SCNNode {
        let (root, pivot) = handleBase(name, title, panel, pos)
        let stem = SCNNode(geometry: SCNCylinder(radius: 0.03, height: 0.18))
        stem.geometry?.firstMaterial = Mat.pbr(.hex(0x272C32), metal: 0.4, rough: 0.4)
        stem.position = SCNVector3(0, 0.09, 0)
        pivot.addChildNode(stem)
        let disc = SCNNode(geometry: SCNCylinder(radius: 0.105, height: 0.05))
        disc.geometry?.firstMaterial = Mat.pbr(color, metal: 0.2, rough: 0.35)
        disc.position = SCNVector3(0, 0.2, 0)
        pivot.addChildNode(disc)
        for i in 0..<6 {
            let a = Float(i) * .pi / 3
            let grip = SCNNode(geometry: SCNBox(width: 0.03, height: 0.055, length: 0.03, chamferRadius: 0.01))
            grip.geometry?.firstMaterial = Mat.pbr(.hex(0x14181C), rough: 0.6)
            grip.position = SCNVector3(cos(a) * 0.085, 0.24, sin(a) * 0.085)
            pivot.addChildNode(grip)
        }
        return root
    }

    private static func keypad(_ cols: Int, _ rows: Int, _ pos: SCNVector3) -> SCNNode {
        let n = SCNNode()
        for i in 0..<cols {
            for j in 0..<rows {
                let key = Mat.box(0.062, 0.046, 0.02, .hex(0x2E353D), chamfer: 0.008, rough: 0.5)
                key.position = SCNVector3(Float(i) * 0.072, -Float(j) * 0.058, 0)
                n.addChildNode(key)
            }
        }
        n.position = pos
        return n
    }

    private static func lampRow(_ colors: [UIColor], _ pos: SCNVector3) -> SCNNode {
        let n = SCNNode()
        for (i, c) in colors.enumerated() {
            let l = SCNNode(geometry: SCNCylinder(radius: 0.026, height: 0.022))
            l.geometry?.firstMaterial = Mat.glow(c, strength: 0.8)
            l.eulerAngles.x = .pi / 2
            l.position = SCNVector3(Float(i) * 0.075, 0, 0)
            n.addChildNode(l)
        }
        n.position = pos
        return n
    }

    private static func mushroom(_ pos: SCNVector3) -> SCNNode {
        let n = SCNNode()
        let ring = SCNNode(geometry: SCNTube(innerRadius: 0.082, outerRadius: 0.1, height: 0.02))
        ring.geometry?.firstMaterial = Mat.pbr(.hex(0xE8C13A), rough: 0.5)
        n.addChildNode(ring)
        let cap = SCNNode(geometry: SCNCylinder(radius: 0.075, height: 0.055))
        cap.geometry?.firstMaterial = Mat.pbr(.hex(0xB0261B), rough: 0.35)
        cap.position = SCNVector3(0, 0.035, 0)
        n.addChildNode(cap)
        n.position = pos
        return n
    }

    private static func seat(_ s: TrainSpec, pos: SCNVector3, small: Bool) -> SCNNode {
        let seat = SCNNode()
        let fabric = Mat.pbr(s.seat, rough: 0.95, both: true)
        let frame = Mat.pbr(.hex(0x22262B), rough: 0.7, both: true)
        let scale: CGFloat = small ? 0.8 : 1.0

        let cushion = SCNNode(geometry: SCNBox(width: 0.58 * scale, height: 0.16, length: 0.56 * scale, chamferRadius: 0.07))
        cushion.geometry?.firstMaterial = fabric
        cushion.position = SCNVector3(0, 0.5, 0)
        seat.addChildNode(cushion)

        let back = SCNNode(geometry: SCNBox(width: 0.58 * scale, height: 0.64, length: 0.15, chamferRadius: 0.07))
        back.geometry?.firstMaterial = fabric
        back.position = SCNVector3(0, 0.87, 0.27)
        back.eulerAngles.x = -0.15
        seat.addChildNode(back)

        if !small {
            let head = SCNNode(geometry: SCNBox(width: 0.32, height: 0.22, length: 0.14, chamferRadius: 0.06))
            head.geometry?.firstMaterial = fabric
            head.position = SCNVector3(0, 1.26, 0.31)
            seat.addChildNode(head)

            for dx in [Float(-1), Float(1)] {
                let arm = SCNNode(geometry: SCNBox(width: 0.09, height: 0.075, length: 0.4, chamferRadius: 0.035))
                arm.geometry?.firstMaterial = frame
                arm.position = SCNVector3(dx * 0.33, 0.68, 0.04)
                seat.addChildNode(arm)
            }
        }

        let post = SCNNode(geometry: SCNCylinder(radius: 0.055, height: 0.42))
        post.geometry?.firstMaterial = frame
        post.position = SCNVector3(0, 0.23, 0)
        seat.addChildNode(post)

        let base = SCNNode(geometry: SCNCylinder(radius: 0.26, height: 0.055))
        base.geometry?.firstMaterial = frame
        base.position = SCNVector3(0, 0.035, 0)
        seat.addChildNode(base)

        seat.position = pos
        return seat
    }

    private static func lastochkaDesk(_ s: TrainSpec, _ lang: Lang, into cab: SCNNode) {
        let center = desk(s, width: 1.72, depth: 0.9)
        center.position = SCNVector3(0, Float(deskY), -1.12)
        cab.addChildNode(center)

        let panel = console(s, width: 1.72, height: 0.6, tilt: -0.30)
        panel.position = SCNVector3(0, 0.3, -0.37)
        center.addChildNode(panel)
        panel.addChildNode(screen("МАРШРУТ", accent: .hex(0x17527F), kind: 0, w: 0.5, h: 0.31,
                                  name: "screen_main", pos: SCNVector3(-0.54, 0.12, 0.035)))
        panel.addChildNode(speedo(s, size: 0.33, pos: SCNVector3(0, 0.12, 0.035)))
        panel.addChildNode(screen("АЛСН", accent: .hex(0x1E6B4A), kind: 3, w: 0.5, h: 0.31,
                                  name: nil, pos: SCNVector3(0.54, 0.12, 0.035)))
        for b in buttonRow(s, lang, y: -0.18, spacing: 0.42, z: 0.032) {
            panel.addChildNode(b)
        }

        center.addChildNode(ribbedHandle("lever_throttle", Loc.s("throttle", lang), s.cabAccent, s.trim,
                                         SCNVector3(-0.48, 0.035, 0.17)))
        center.addChildNode(ribbedHandle("lever_brake", Loc.s("brake", lang), .hex(0xC0392B), s.trim,
                                         SCNVector3(0.48, 0.035, 0.17)))

        for dx in [Float(-1), Float(1)] {
            let side = desk(s, width: 1.05, depth: 0.76)
            side.position = SCNVector3(dx * 1.2, Float(deskY), -0.74)
            side.eulerAngles.y = dx * 0.42
            cab.addChildNode(side)

            let sp = console(s, width: 1.03, height: 0.55, tilt: -0.30)
            sp.position = SCNVector3(0, 0.27, -0.3)
            side.addChildNode(sp)

            if dx < 0 {
                sp.addChildNode(screen("СОСТАВ", accent: .hex(0x2A3E66), kind: 2, w: 0.6, h: 0.3,
                                       name: nil, pos: SCNVector3(0, 0.11, 0.035)))
                sp.addChildNode(keypad(4, 2, SCNVector3(-0.32, -0.12, 0.032)))
                let handset = Mat.box(0.08, 0.055, 0.2, .hex(0x14181C), chamfer: 0.025, rough: 0.6)
                handset.position = SCNVector3(-0.3, 0.06, 0.2)
                side.addChildNode(handset)
            } else {
                sp.addChildNode(screen("ДИАГ", accent: .hex(0x394B7A), kind: 1, w: 0.6, h: 0.3,
                                       name: nil, pos: SCNVector3(0, 0.11, 0.035)))
                sp.addChildNode(lampRow([.hex(0x2FA35A), .hex(0xE8C13A), .hex(0xC0392B)], SCNVector3(-0.3, -0.13, 0.032)))
                side.addChildNode(mushroom(SCNVector3(0.28, 0.06, 0.2)))
            }
        }

        cab.addChildNode(seat(s, pos: SCNVector3(-0.12, 0, 0.85), small: false))
        cab.addChildNode(seat(s, pos: SCNVector3(1.12, 0, 1.0), small: true))
    }

    private static func sapsanDesk(_ s: TrainSpec, _ lang: Lang, into cab: SCNNode) {
        let center = desk(s, width: 2.0, depth: 0.94)
        center.position = SCNVector3(0, Float(deskY), -1.14)
        cab.addChildNode(center)

        let panel = console(s, width: 2.0, height: 0.64, tilt: -0.36)
        panel.position = SCNVector3(0, 0.32, -0.38)
        center.addChildNode(panel)
        panel.addChildNode(screen("МАРШРУТ", accent: .hex(0x8E1A2C), kind: 0, w: 0.44, h: 0.29,
                                  name: "screen_main", pos: SCNVector3(-0.72, 0.14, 0.035)))
        panel.addChildNode(screen("КЛУБ-У", accent: .hex(0x1E6B4A), kind: 3, w: 0.44, h: 0.29,
                                  name: nil, pos: SCNVector3(-0.24, 0.14, 0.035)))
        panel.addChildNode(speedo(s, size: 0.3, pos: SCNVector3(0.26, 0.14, 0.035)))
        panel.addChildNode(screen("ДИАГ", accent: .hex(0x394B7A), kind: 1, w: 0.44, h: 0.29,
                                  name: nil, pos: SCNVector3(0.76, 0.14, 0.035)))
        for b in buttonRow(s, lang, y: -0.2, spacing: 0.46, z: 0.032) {
            panel.addChildNode(b)
        }
        panel.addChildNode(lampRow([.hex(0x2FA35A), .hex(0xE8C13A), .hex(0xC0392B), .hex(0x2C6DBE)],
                                   SCNVector3(0.66, -0.2, 0.032)))

        center.addChildNode(tHandle("lever_throttle", Loc.s("throttle", lang), .hex(0xD8DDE2), s.trim,
                                    SCNVector3(-0.5, 0.035, 0.18)))
        center.addChildNode(wheelHandle("lever_brake", Loc.s("brake", lang), .hex(0xC0392B), s.trim,
                                        SCNVector3(0.5, 0.035, 0.18)))

        for dx in [Float(-1), Float(1)] {
            let side = desk(s, width: 1.0, depth: 0.76)
            side.position = SCNVector3(dx * 1.32, Float(deskY), -0.66)
            side.eulerAngles.y = dx * 0.55
            cab.addChildNode(side)

            let sp = console(s, width: 0.98, height: 0.5, tilt: -0.36)
            sp.position = SCNVector3(0, 0.25, -0.3)
            side.addChildNode(sp)
            sp.addChildNode(keypad(5, 3, SCNVector3(-0.36, 0.12, 0.032)))
            if dx > 0 {
                side.addChildNode(mushroom(SCNVector3(0.26, 0.06, 0.2)))
            } else {
                let handset = Mat.box(0.08, 0.055, 0.2, .hex(0x14181C), chamfer: 0.025, rough: 0.6)
                handset.position = SCNVector3(-0.28, 0.06, 0.2)
                side.addChildNode(handset)
            }
        }

        cab.addChildNode(seat(s, pos: SCNVector3(-0.15, 0, 0.9), small: false))
        cab.addChildNode(seat(s, pos: SCNVector3(1.15, 0, 1.05), small: false))
    }

    private static func ivolgaDesk(_ s: TrainSpec, _ lang: Lang, into cab: SCNNode) {
        let center = desk(s, width: 1.9, depth: 0.86)
        center.position = SCNVector3(0, Float(deskY), -1.1)
        cab.addChildNode(center)

        let panel = console(s, width: 1.9, height: 0.62, tilt: -0.24)
        panel.position = SCNVector3(0, 0.31, -0.35)
        center.addChildNode(panel)
        panel.addChildNode(screen("МАРШРУТ", accent: .hex(0xA31C22), kind: 0, w: 0.92, h: 0.34,
                                  name: "screen_main", pos: SCNVector3(-0.36, 0.12, 0.035)))
        panel.addChildNode(speedo(s, size: 0.3, pos: SCNVector3(0.34, 0.14, 0.035)))
        panel.addChildNode(screen("СИСТ", accent: .hex(0x1D3F8C), kind: 2, w: 0.36, h: 0.24,
                                  name: nil, pos: SCNVector3(0.76, 0.13, 0.035)))
        for b in buttonRow(s, lang, y: -0.2, spacing: 0.4, z: 0.032) {
            panel.addChildNode(b)
        }

        center.addChildNode(ribbedHandle("lever_throttle", Loc.s("throttle", lang), s.cabAccent, s.trim,
                                         SCNVector3(0.42, 0.035, 0.16)))
        center.addChildNode(wheelHandle("lever_brake", Loc.s("brake", lang), .hex(0x1D3F8C), s.trim,
                                        SCNVector3(-0.44, 0.035, 0.16)))

        for dx in [Float(-1), Float(1)] {
            let side = desk(s, width: 0.9, depth: 0.7)
            side.position = SCNVector3(dx * 1.28, Float(deskY), -0.6)
            side.eulerAngles.y = dx * 0.3
            cab.addChildNode(side)
            if dx > 0 {
                side.addChildNode(mushroom(SCNVector3(0.16, 0.06, -0.12)))
                side.addChildNode(lampRow([.hex(0x2FA35A), .hex(0xE8C13A)], SCNVector3(-0.24, 0.05, 0.0)))
            } else {
                side.addChildNode(keypad(4, 2, SCNVector3(-0.2, 0.06, -0.05)))
            }
        }

        cab.addChildNode(seat(s, pos: SCNVector3(-0.1, 0, 0.82), small: false))
    }
}
