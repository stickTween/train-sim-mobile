import UIKit

enum WorldRenderer {

    static let ppm: Double = 10
    static let horizonY = 84
    static let railY = 96
    static let winH = 118

    static func frontX(_ w: Int) -> Int { w - 78 }

    static func screenX(_ pos: Double, _ st: GameState, _ w: Int) -> Int {
        Int(((pos - st.distance) * ppm).rounded()) + frontX(w)
    }

    static func draw(_ g: Pix, _ st: GameState, flipped: Bool) {
        let w = g.width
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))
        if flipped {
            g.ctx.translateBy(x: CGFloat(w), y: 0)
            g.ctx.scaleBy(x: -1, y: 1)
        }

        sky(g, st, w)
        hills(g, st, w)
        farProps(g, st, w)
        ground(g, st, w)
        nearProps(g, st, w)
        signals(g, st, w)
        platform(g, st, w, front: false)
        train(g, st, w)
        platform(g, st, w, front: true)
        passengers(g, st, w)

        g.ctx.restoreGState()
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))
        stationText(g, st, w, flipped: flipped)
        g.ctx.restoreGState()

        g.rect(0, winH - 2, w, 2, .rgb(0x141820))
    }

    private static func sky(_ g: Pix, _ st: GameState, _ w: Int) {
        g.gradientV(0, 0, w, horizonY, .rgb(0x4E86C6), .rgb(0xBFD9EC), steps: 14)
        let sunX = 62
        g.circle(sunX, 22, 9, .rgb(0xFFF3C4))
        g.circle(sunX, 22, 7, .rgb(0xFFFBE6))
        let drift = Int(st.distance * 0.6) % (w + 220)
        for i in 0..<4 {
            let cx = (i * 150 + 40 - drift + 440) % (w + 220) - 110
            cloud(g, cx, 14 + (i % 3) * 12, 1 + i % 2)
        }
    }

    private static func cloud(_ g: Pix, _ x: Int, _ y: Int, _ size: Int) {
        let c = UIColor.rgb(0xFFFFFF)
        let s = UIColor.rgb(0xD7E6F4)
        let k = size + 1
        g.rect(x, y + 3 * k, 22 * k, 3 * k, s)
        g.rect(x + 2 * k, y + k, 16 * k, 3 * k, c)
        g.rect(x + 6 * k, y, 9 * k, 3 * k, c)
        g.rect(x + 2 * k, y + 3 * k, 18 * k, 2 * k, c)
    }

    private static func hills(_ g: Pix, _ st: GameState, _ w: Int) {
        let off1 = st.distance * ppm * 0.18
        let off2 = st.distance * ppm * 0.36
        var x = 0
        while x < w {
            let t1 = (Double(x) + off1) * 0.011
            let h1 = 16 + sin(t1) * 6 + sin(t1 * 2.3) * 3.5
            g.rect(x, horizonY - Int(h1), 2, Int(h1) + 2, .rgb(0x7C97B4))
            x += 2
        }
        x = 0
        while x < w {
            let t2 = (Double(x) + off2) * 0.017
            let h2 = 10 + sin(t2 * 1.4 + 1.2) * 5 + sin(t2 * 3.1) * 2.5
            g.rect(x, horizonY - Int(h2), 2, Int(h2) + 2, .rgb(0x5E7F5A))
            x += 2
        }
    }

    private static func ground(_ g: Pix, _ st: GameState, _ w: Int) {
        g.rect(0, horizonY, w, 14, .rgb(0x6E9450))
        g.rect(0, horizonY + 6, w, 8, .rgb(0x5F8544))
        g.rect(0, railY + 2, w, 8, .rgb(0x8A8377))
        g.rect(0, railY + 2, w, 2, .rgb(0x9C9488))
        g.rect(0, railY + 10, w, winH - railY - 10, .rgb(0x4F7038))
        g.rect(0, railY + 10, w, 2, .rgb(0x5E8442))

        let sleeperGap = 6
        let shift = Int((st.distance * ppm).rounded()) % sleeperGap
        var x = -shift
        while x < w {
            g.rect(x, railY + 3, 3, 6, .rgb(0x5A4A38))
            x += sleeperGap
        }
        g.rect(0, railY, w, 2, .rgb(0xB9BEC4))
        g.rect(0, railY + 2, w, 1, .rgb(0x6E7278))
    }

    private static func farProps(_ g: Pix, _ st: GameState, _ w: Int) {
        for p in st.props where p.layer >= 2 {
            let x = screenX(p.pos, st, w)
            if x < -80 || x > w + 80 { continue }
            if p.kind == 5 {
                let h = 12 + p.seed % 16
                let bw = 10 + p.seed % 14
                g.rect(x, horizonY - h, bw, h, .rgb(0x8E9AA6))
                g.rect(x, horizonY - h, bw, 2, .rgb(0xA4AEB8))
                var wy = horizonY - h + 4
                while wy < horizonY - 3 {
                    var wx = x + 2
                    while wx < x + bw - 2 {
                        g.rect(wx, wy, 2, 2, .rgb(0x5A6672))
                        wx += 4
                    }
                    wy += 5
                }
            } else {
                let h = 14 + p.seed % 10
                g.rect(x + 3, horizonY - h / 3, 3, h / 3, .rgb(0x4A3A28))
                g.circle(x + 4, horizonY - h / 2, h / 3, .rgb(0x3E6B3A))
            }
        }
    }

    private static func nearProps(_ g: Pix, _ st: GameState, _ w: Int) {
        for p in st.props where p.layer == 1 {
            let x = screenX(p.pos, st, w)
            if x < -70 || x > w + 70 { continue }
            switch p.kind {
            case 0: tree(g, x, railY + 4, 20 + p.seed % 18, p.seed)
            case 1: bush(g, x, railY + 6, p.seed)
            case 3: house(g, x, railY + 2, p.seed)
            case 4: catenary(g, x, w)
            default: break
            }
        }
    }

    private static func tree(_ g: Pix, _ x: Int, _ baseY: Int, _ h: Int, _ seed: Int) {
        let trunkH = h / 3
        g.rect(x + 2, baseY - trunkH, 3, trunkH, .rgb(0x4A3524))
        g.rect(x + 2, baseY - trunkH, 1, trunkH, .rgb(0x5C4430))
        let greens: [UIColor] = [.rgb(0x2F6B34), .rgb(0x3B7C39), .rgb(0x28602E), .rgb(0x477F3C)]
        let c = greens[seed % greens.count]
        let cw = h / 2
        var lay = 0
        var y = baseY - trunkH
        while lay < 3 {
            let ww = cw - lay * 2
            g.rect(x + 3 - ww / 2, y - (h / 4), ww, h / 4 + 2, c)
            g.rect(x + 3 - ww / 2, y - (h / 4), ww, 2, c.shade(0.12))
            y -= h / 5
            lay += 1
        }
    }

    private static func bush(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int) {
        let c: UIColor = seed % 2 == 0 ? .rgb(0x3E7A3A) : .rgb(0x4C8A42)
        g.rect(x, baseY - 5, 9, 5, c)
        g.rect(x + 1, baseY - 7, 7, 3, c.shade(0.1))
    }

    private static func house(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int) {
        let hw = 20 + seed % 12
        let hh = 14 + seed % 8
        let walls: [UIColor] = [.rgb(0xD8C7A8), .rgb(0xC9B79B), .rgb(0xB6C2CC), .rgb(0xD9C0B0)]
        let roofs: [UIColor] = [.rgb(0x8A3B32), .rgb(0x5A6470), .rgb(0x7A5236)]
        g.rect(x, baseY - hh, hw, hh, walls[seed % walls.count])
        g.rect(x, baseY - hh, hw, 2, walls[seed % walls.count].shade(0.15))
        g.rect(x - 2, baseY - hh - 4, hw + 4, 4, roofs[seed % roofs.count])
        var wx = x + 3
        while wx < x + hw - 4 {
            g.rect(wx, baseY - hh + 5, 4, 4, .rgb(0x3A4E60))
            g.rect(wx, baseY - hh + 5, 4, 1, .rgb(0x8FA8BC))
            wx += 8
        }
        g.rect(x + hw / 2 - 2, baseY - 7, 5, 7, .rgb(0x5A4430))
    }

    private static func catenary(_ g: Pix, _ x: Int, _ w: Int) {
        g.rect(x, railY - 44, 3, 44, .rgb(0x8A9098))
        g.rect(x, railY - 44, 1, 44, .rgb(0xA6ACB4))
        g.rect(x - 22, railY - 44, 24, 2, .rgb(0x8A9098))
        g.rect(x - 20, railY - 42, 2, 4, .rgb(0x8A9098))
    }

    private static func wires(_ g: Pix, _ st: GameState, _ w: Int) {
        g.rect(0, railY - 40, w, 1, .rgb(0x3A4048))
        g.rect(0, railY - 33, w, 1, .rgb(0x4A5058))
    }

    private static func signals(_ g: Pix, _ st: GameState, _ w: Int) {
        wires(g, st, w)
        for s in st.signals {
            let x = screenX(s.pos, st, w)
            if x < -20 || x > w + 20 { continue }
            g.rect(x, railY - 34, 3, 34, .rgb(0x6E747A))
            g.rect(x - 3, railY - 46, 9, 13, .rgb(0x24282E))
            g.frame(x - 3, railY - 46, 9, 13, .rgb(0x14181C))
            let green = s.pos > st.distance
            g.circle(x + 1, railY - 42, 2, green ? .rgb(0x30E070) : .rgb(0x1E3A28))
            g.circle(x + 1, railY - 37, 2, green ? .rgb(0x3A2018) : .rgb(0xF04030))
        }
    }

    private static func platform(_ g: Pix, _ st: GameState, _ w: Int, front: Bool) {
        for s in World.stations {
            let cx = screenX(s.pos, st, w)
            let half = Int(s.platformHalf * ppm)
            if cx + half < -40 || cx - half > w + 40 { continue }
            let x0 = cx - half
            let ww = half * 2

            if !front {
                var px = x0
                while px < x0 + ww {
                    g.rect(px, railY - 52, 3, 8, .rgb(0x9AA4AE))
                    px += 46
                }
                g.rect(x0, railY - 56, ww, 5, .rgb(0x2E5F86))
                g.rect(x0, railY - 56, ww, 2, .rgb(0x3F7AA8))
                g.rect(x0, railY - 51, ww, 1, .rgb(0x1E4260))
            } else {
                let surf = railY - 11
                g.rect(x0, surf, ww, winH - surf, .rgb(0xB4AEA4))
                g.rect(x0, surf, ww, 3, .rgb(0xC6C0B6))
                g.rect(x0, surf, ww, 1, .rgb(0xE8C93E))
                g.rect(x0, surf + 3, ww, 1, .rgb(0x8E887E))
                var tx = x0
                while tx < x0 + ww {
                    g.rect(tx, surf + 5, 3, 2, .rgb(0x9E988E))
                    tx += 7
                }
                var mx = x0 + 20
                while mx < x0 + ww - 20 {
                    g.rect(mx, surf + 16, 26, 2, .rgb(0xA49E94))
                    mx += 90
                }
                var bx = x0 + 60
                while bx < x0 + ww - 60 {
                    bench(g, bx, surf - 2)
                    bx += 190
                }
            }
        }
    }

    private static func bench(_ g: Pix, _ x: Int, _ y: Int) {
        g.rect(x, y, 22, 3, .rgb(0x2E86C1))
        g.rect(x, y - 6, 22, 3, .rgb(0x2E86C1))
        g.rect(x + 1, y + 3, 2, 4, .rgb(0x3A4048))
        g.rect(x + 19, y + 3, 2, 4, .rgb(0x3A4048))
    }

    private static func stationText(_ g: Pix, _ st: GameState, _ w: Int, flipped: Bool) {
        for s in World.stations {
            var cx = screenX(s.pos, st, w)
            if flipped { cx = w - cx }
            if cx < -60 || cx > w + 60 { continue }
            let label = s.name(st.lang)
            let tw = g.textWidth(label, size: 8) + 10
            g.rect(cx - tw / 2, railY - 74, tw, 12, .rgb(0x123C6E))
            g.frame(cx - tw / 2, railY - 74, tw, 12, .rgb(0x2C6DBE))
            g.text(label, cx, railY - 73, size: 8, color: .white, align: .center)
        }
    }

    private static func passengers(_ g: Pix, _ st: GameState, _ w: Int) {
        let coats: [UIColor] = [.rgb(0xC0392B), .rgb(0x2C6DBE), .rgb(0x2FA35A), .rgb(0xE8B33C),
                                .rgb(0x8E44AD), .rgb(0xE67E22), .rgb(0x34495E)]
        for p in st.passengers where !p.done {
            let x = screenX(p.pos, st, w)
            if x < -12 || x > w + 12 { continue }
            let walking = p.boarding
            let step = walking ? Int(sin(p.phase) * 2) : 0
            let baseY = railY - 11
            let coat = coats[p.coat % coats.count]
            g.rect(x - 1, baseY - 5, 2, 5, .rgb(0x2A2F36))
            g.rect(x + 1, baseY - 5, 2, 5, .rgb(0x2A2F36))
            if walking {
                g.rect(x - 1 - step, baseY - 2, 2, 2, .rgb(0x22262C))
                g.rect(x + 1 + step, baseY - 2, 2, 2, .rgb(0x22262C))
            }
            g.rect(x - 2, baseY - 13, 6, 8, coat)
            g.rect(x - 2, baseY - 13, 6, 2, coat.shade(0.18))
            g.rect(x - 1, baseY - 17, 4, 4, .rgb(0xD6A57E))
            g.rect(x - 1, baseY - 18, 4, 2, .rgb(0x3A2A1E))
        }
    }

    private static func train(_ g: Pix, _ st: GameState, _ w: Int) {
        let spec = st.spec
        let carPx = Int(spec.carLengthM * ppm)
        let gapPx = 6
        let bodyH = Int(spec.carHeightM * ppm)
        let floorY = railY - 11
        let topY = floorY - bodyH
        let front = frontX(w)

        for c in 0..<spec.cars {
            let x1 = front - c * (carPx + gapPx)
            let x0 = x1 - carPx
            if x1 < -40 || x0 > w + 40 { continue }
            car(g, st, x0: x0, x1: x1, topY: topY, floorY: floorY, head: c == 0, index: c)
        }
    }

    private static func car(_ g: Pix, _ st: GameState, x0: Int, x1: Int, topY: Int, floorY: Int,
                            head: Bool, index: Int) {
        let spec = st.spec
        let h = floorY - topY
        let nose = head ? Int(spec.noseSlopeM * WorldRenderer.ppm) : 0
        let bodyEnd = x1 - nose
        let noseCut = Int(Double(h) * 0.44)

        g.rect(x0, topY, bodyEnd - x0, h, spec.body)
        g.rect(x0, topY, bodyEnd - x0, 3, spec.roof)

        if head && nose > 0 {
            g.poly([(bodyEnd, topY), (x1 - 1, topY + noseCut), (x1 - 1, floorY), (bodyEnd, floorY)], spec.body)
            g.line(bodyEnd, topY, x1 - 1, topY + noseCut, spec.roof, 3)
            g.poly([(bodyEnd, topY + noseCut - 2), (x1 - 1, topY + noseCut + 6),
                    (x1 - 1, floorY), (bodyEnd, floorY)], spec.accent)
            g.poly([(bodyEnd, topY + noseCut + 5), (x1 - 1, topY + noseCut + 13),
                    (x1 - 1, floorY), (bodyEnd, floorY)], spec.body)
        }

        g.rect(x0, floorY - 6, bodyEnd - x0, 6, spec.bodyShade)
        g.rect(x0, topY + Int(Double(h) * 0.60), bodyEnd - x0, 5, spec.stripe)
        g.rect(x0, topY + Int(Double(h) * 0.60) + 5, bodyEnd - x0, 2, spec.accent)

        let winTop = topY + Int(Double(h) * 0.20)
        let wh = Int(Double(h) * 0.32)
        var wx = x0 + 6
        let winEnd = head ? bodyEnd - 4 : x1 - 6
        while wx + 14 < winEnd {
            g.rect(wx, winTop, 14, wh, spec.glass)
            g.rect(wx, winTop, 14, 2, spec.glass.shade(0.28))
            g.rect(wx, winTop + wh - 1, 14, 1, spec.glass.shade(-0.3))
            wx += 22
        }

        let doorW = 12
        let open = Int(Double(doorW / 2) * st.doorAnim)
        for frac in [0.32, 0.72] {
            let dx = x1 - Int(Double(x1 - x0) * frac) - doorW / 2
            if dx < x0 + 2 || dx + doorW > bodyEnd - 2 { continue }
            g.rect(dx, floorY - Int(Double(h) * 0.78), doorW, Int(Double(h) * 0.78), .rgb(0x161C24))
            g.rect(dx - open, floorY - Int(Double(h) * 0.78), doorW / 2, Int(Double(h) * 0.78), spec.doorColor)
            g.rect(dx + doorW / 2 + open, floorY - Int(Double(h) * 0.78), doorW / 2, Int(Double(h) * 0.78), spec.doorColor)
            g.rect(dx - open, floorY - Int(Double(h) * 0.78), doorW / 2, 2, spec.doorColor.shade(0.2))
            g.rect(dx + doorW / 2 + open, floorY - Int(Double(h) * 0.78), doorW / 2, 2, spec.doorColor.shade(0.2))
        }

        if st.cabinLight {
            g.rect(x0 + 4, topY + 4, x1 - x0 - 8, 2, .rgb(0xFFF6D8))
        }

        if head {
            let lampY = floorY - 10
            let lx = x1 - 7
            g.rect(lx, lampY, 5, 4, st.headlights ? .rgb(0xFFF6C8) : .rgb(0xB6BCC2))
            g.rect(lx, lampY + 5, 4, 2, .rgb(0xC02020))
            let cabW = min(30, max(12, (x1 - x0) / 6))
            g.rect(bodyEnd - cabW, topY + 5, cabW, Int(Double(h) * 0.34), spec.glass.shade(-0.15))
            g.rect(bodyEnd - cabW, topY + 5, cabW, 2, spec.glass.shade(0.3))
        }

        let bogieY = railY - 9
        for bf in [0.22, 0.78] {
            let bx = x1 - Int(Double(x1 - x0) * bf)
            g.rect(bx - 12, bogieY, 24, 5, spec.skirt)
            wheel(g, st, bx - 7, railY - 4)
            wheel(g, st, bx + 7, railY - 4)
        }

        if index == 1 {
            let px = x0 + (x1 - x0) / 2
            g.rect(px - 10, topY - 2, 20, 2, .rgb(0x5A626A))
            g.line(px - 8, topY - 2, px + 2, topY - 12, .rgb(0xA6ACB4))
            g.line(px + 2, topY - 12, px + 10, topY - 6, .rgb(0xA6ACB4))
            g.rect(px + 2, topY - 14, 14, 2, .rgb(0xC9CFD5))
        } else {
            g.rect(x0 + (x1 - x0) / 3, topY - 2, 16, 2, .rgb(0x6E767E))
        }
    }

    private static func wheel(_ g: Pix, _ st: GameState, _ cx: Int, _ cy: Int) {
        g.circle(cx, cy, 4, .rgb(0x2A2F36))
        g.circle(cx, cy, 3, .rgb(0x6E767E))
        let a = st.distance * 2.2
        let (x1, y1) = g.polar(cx, cy, 3, a)
        let (x2, y2) = g.polar(cx, cy, 3, a + 1.57)
        g.rect(x1, y1, 1, 1, .rgb(0x2A2F36))
        g.rect(x2, y2, 1, 1, .rgb(0x2A2F36))
    }
}
