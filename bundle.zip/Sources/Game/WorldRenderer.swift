import UIKit

enum WorldRenderer {

    static let ppm: Double = 10
    static let horizonY = 82
    static let railY = 96
    static let farRailY = 78
    static let winH = 118

    static func frontX(_ w: Int) -> Int { w - 74 }

    static func sx(_ pos: Double, _ st: GameState, _ w: Int) -> Int {
        Int(((pos - st.distance) * ppm).rounded()) + frontX(w)
    }

    private static func mix(_ a: UIColor, _ b: UIColor, _ t: Double) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        a.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        b.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        let f = CGFloat(max(0, min(1, t)))
        return UIColor(red: r1 + (r2 - r1) * f, green: g1 + (g2 - g1) * f,
                       blue: b1 + (b2 - b1) * f, alpha: 1)
    }

    static func draw(_ g: Pix, _ st: GameState, flipped: Bool) {
        let w = g.width
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))
        if flipped {
            g.ctx.translateBy(x: CGFloat(w), y: 0)
            g.ctx.scaleBy(x: -1, y: 1)
        }

        let day = st.dayPhase
        sky(g, st, w, day)
        hills(g, st, w, day)
        props(g, st, w, day)
        farTrack(g, st, w, day)
        canopy(g, st, w, day)
        ground(g, st, w, day)
        signals(g, st, w)
        ownTrain(g, st, w, day)
        platform(g, st, w, day)
        passengers(g, st, w, day)

        g.ctx.restoreGState()
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))
        stationSigns(g, st, w, flipped: flipped)
        g.ctx.restoreGState()
        g.rect(0, winH - 2, w, 2, .rgb(0x10141A))
    }

    private static func sky(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let topNight = UIColor.rgb(0x0A1024)
        let topDay = UIColor.rgb(0x3E7CC0)
        let botNight = UIColor.rgb(0x203050)
        let botDay = UIColor.rgb(0xC6DCEE)
        let dusk = day > 0 && day < 1
        var top = mix(topNight, topDay, day)
        var bot = mix(botNight, botDay, day)
        if dusk {
            top = mix(top, .rgb(0x8E4A6E), 0.35)
            bot = mix(bot, .rgb(0xE8A060), 0.45)
        }
        g.gradientV(0, 0, w, horizonY, top, bot, steps: 16)

        if day < 0.45 {
            for i in 0..<26 {
                let x = Int(World.rnd(i, 61) * Double(w))
                let y = Int(World.rnd(i, 67) * Double(horizonY - 26))
                let bright = World.rnd(i, 71) > 0.6
                g.rect(x, y, 1, 1, bright ? .rgb(0xFFFFFF) : .rgb(0xB6C4E0))
            }
        }

        let cx = 62
        if day > 0.35 {
            g.circle(cx, 20, 9, .rgb(0xFFEFB0))
            g.circle(cx, 20, 7, .rgb(0xFFFBE0))
        } else {
            g.circle(cx, 20, 7, .rgb(0xE6ECF6))
            g.circle(cx + 3, 18, 6, mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day))
        }

        let drift = Int(st.distance * 0.5) % (w + 260)
        for i in 0..<4 {
            let x = (i * 170 + 30 - drift + 520) % (w + 260) - 130
            cloud(g, x, 12 + (i % 3) * 13, 1 + i % 2, day)
        }
    }

    private static func cloud(_ g: Pix, _ x: Int, _ y: Int, _ size: Int, _ day: Double) {
        let c = mix(.rgb(0x36405C), .rgb(0xFFFFFF), day)
        let s = mix(.rgb(0x28304A), .rgb(0xD4E4F2), day)
        let k = size + 1
        g.rect(x, y + 3 * k, 22 * k, 3 * k, s)
        g.rect(x + 2 * k, y + k, 16 * k, 3 * k, c)
        g.rect(x + 6 * k, y, 9 * k, 3 * k, c)
        g.rect(x + 2 * k, y + 3 * k, 18 * k, 2 * k, c)
    }

    private static func hills(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let far = mix(.rgb(0x1C2740), .rgb(0x7C97B4), day)
        let near = mix(.rgb(0x16251C), .rgb(0x5E7F5A), day)
        let o1 = st.distance * ppm * 0.16
        let o2 = st.distance * ppm * 0.34
        var x = 0
        while x < w {
            let t = (Double(x) + o1) * 0.010
            let h = 16 + sin(t) * 6 + sin(t * 2.3) * 3.5
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, far)
            x += 2
        }
        x = 0
        while x < w {
            let t = (Double(x) + o2) * 0.016
            let h = 10 + sin(t * 1.4 + 1.2) * 5 + sin(t * 3.1) * 2.5
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, near)
            x += 2
        }
    }

    private static func ground(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let grass = mix(.rgb(0x1E3020), .rgb(0x5F8544), day)
        let grass2 = mix(.rgb(0x17251A), .rgb(0x4F7038), day)
        let ballast = mix(.rgb(0x2A2A2E), .rgb(0x8A8377), day)
        g.rect(0, horizonY, w, railY - horizonY + 2, grass)
        g.rect(0, railY + 2, w, 8, ballast)
        g.rect(0, railY + 10, w, winH - railY - 10, grass2)

        let gap = 6
        let shift = Int((st.distance * ppm).rounded()) % gap
        var x = -shift
        while x < w {
            g.rect(x, railY + 3, 3, 6, mix(.rgb(0x1E1A16), .rgb(0x5A4A38), day))
            x += gap
        }
        g.rect(0, railY, w, 2, mix(.rgb(0x555C64), .rgb(0xB9BEC4), day))
    }

    private static func farTrack(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        g.rect(0, farRailY + 2, w, 5, mix(.rgb(0x26262A), .rgb(0x7E7870), day))
        g.rect(0, farRailY, w, 2, mix(.rgb(0x4A5058), .rgb(0xA6ACB2), day))
        for t in st.traffic where t.active && !t.sameTrack {
            let spec = TrainSpec.by(t.specId)
            drawTrain(g, st, spec: spec, cars: t.cars, frontPos: t.pos, base: farRailY,
                      w: w, day: day, doorAnim: 0, scale: 0.82, reversed: true)
        }
    }

    private static func props(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let from = st.distance - Double(frontX(w)) / ppm - 20
        let to = st.distance + 40
        for p in World.props(from: from, to: to) {
            let x = sx(p.pos, st, w)
            if x < -80 || x > w + 80 { continue }
            switch p.kind {
            case 0: tree(g, x, farRailY + 2, 22 + p.seed % 20, p.seed, day)
            case 1: bush(g, x, farRailY + 4, p.seed, day)
            case 2: building(g, x, farRailY - 2, p.seed, day)
            case 3: house(g, x, farRailY, p.seed, day)
            case 4: catenary(g, x, day)
            default: break
            }
        }
    }

    private static func tree(_ g: Pix, _ x: Int, _ baseY: Int, _ h: Int, _ seed: Int, _ day: Double) {
        let trunkH = h / 3
        g.rect(x + 2, baseY - trunkH, 3, trunkH, mix(.rgb(0x1A1410), .rgb(0x4A3524), day))
        let greens: [UIColor] = [.rgb(0x2F6B34), .rgb(0x3B7C39), .rgb(0x28602E), .rgb(0x477F3C)]
        let c = mix(.rgb(0x14241A), greens[seed % greens.count], day)
        let cw = h / 2
        var y = baseY - trunkH
        for lay in 0..<3 {
            let ww = cw - lay * 2
            g.rect(x + 3 - ww / 2, y - h / 4, ww, h / 4 + 2, c)
            y -= h / 5
        }
    }

    private static func bush(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let c = mix(.rgb(0x16281A), seed % 2 == 0 ? .rgb(0x3E7A3A) : .rgb(0x4C8A42), day)
        g.rect(x, baseY - 5, 9, 5, c)
        g.rect(x + 1, baseY - 7, 7, 3, c)
    }

    private static func house(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let hw = 18 + seed % 12
        let hh = 13 + seed % 8
        let walls: [UIColor] = [.rgb(0xD8C7A8), .rgb(0xC9B79B), .rgb(0xB6C2CC), .rgb(0xD9C0B0)]
        let roofs: [UIColor] = [.rgb(0x8A3B32), .rgb(0x5A6470), .rgb(0x7A5236)]
        g.rect(x, baseY - hh, hw, hh, mix(.rgb(0x2A2A30), walls[seed % walls.count], day))
        g.rect(x - 2, baseY - hh - 4, hw + 4, 4, mix(.rgb(0x1E1E24), roofs[seed % roofs.count], day))
        var wx = x + 3
        var i = 0
        while wx < x + hw - 4 {
            let lit = day < 0.5 && (seed + i) % 3 != 0
            g.rect(wx, baseY - hh + 5, 4, 4, lit ? .rgb(0xFFE9A0) : mix(.rgb(0x181C24), .rgb(0x3A4E60), day))
            wx += 8
            i += 1
        }
    }

    private static func building(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let bw = 14 + seed % 14
        let bh = 22 + seed % 34
        g.rect(x, baseY - bh, bw, bh, mix(.rgb(0x232833), .rgb(0x9AA6B2), day))
        g.rect(x, baseY - bh, bw, 2, mix(.rgb(0x2C323E), .rgb(0xB2BCC6), day))
        var wy = baseY - bh + 5
        var row = 0
        while wy < baseY - 4 {
            var wx = x + 2
            var col = 0
            while wx < x + bw - 3 {
                let lit = day < 0.5 && ((seed + row * 7 + col * 3) % 5 < 2)
                g.rect(wx, wy, 2, 3, lit ? .rgb(0xFFE08A) : mix(.rgb(0x141820), .rgb(0x54606C), day))
                wx += 4
                col += 1
            }
            wy += 6
            row += 1
        }
    }

    private static func catenary(_ g: Pix, _ x: Int, _ day: Double) {
        let c = mix(.rgb(0x3A4048), .rgb(0x8A9098), day)
        g.rect(x, railY - 46, 3, 46, c)
        g.rect(x - 24, railY - 46, 26, 2, c)
        g.rect(x - 22, railY - 44, 2, 5, c)
    }

    private static func signals(_ g: Pix, _ st: GameState, _ w: Int) {
        g.rect(0, railY - 40, w, 1, .rgb(0x3A4048))
        g.rect(0, railY - 33, w, 1, .rgb(0x4A5058))
        let step: Double = 700
        var i = Int((st.distance - 60) / step)
        while Double(i) * step < st.distance + 60 {
            let pos = Double(i) * step
            let x = sx(pos, st, w)
            i += 1
            if x < -20 || x > w + 20 { continue }
            g.rect(x, railY - 34, 3, 34, .rgb(0x6E747A))
            g.rect(x - 3, railY - 47, 9, 14, .rgb(0x22262C))
            g.frame(x - 3, railY - 47, 9, 14, .rgb(0x12161A))
            let green = st.signalGreen(at: pos)
            g.circle(x + 1, railY - 43, 2, green ? .rgb(0x30E070) : .rgb(0x1E3A28))
            g.circle(x + 1, railY - 37, 2, green ? .rgb(0x3A2018) : .rgb(0xF04030))
        }
    }

    private static func canopy(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for s in World.stations {
            let cx = sx(s.pos, st, w)
            let half = Int(s.platformHalf * ppm)
            if cx + half < -40 || cx - half > w + 40 { continue }
            let x0 = cx - half
            let ww = half * 2
            var px = x0 + 20
            while px < x0 + ww - 20 {
                g.rect(px, railY - 58, 3, 14, mix(.rgb(0x3A4048), .rgb(0x9AA4AE), day))
                px += 60
            }
            g.rect(x0, railY - 64, ww, 6, mix(.rgb(0x14283A), .rgb(0x2E5F86), day))
            g.rect(x0, railY - 64, ww, 2, mix(.rgb(0x1C3A50), .rgb(0x3F7AA8), day))
            var lx = x0 + 30
            while lx < x0 + ww - 30 {
                g.rect(lx, railY - 57, 10, 2, day < 0.5 ? .rgb(0xFFF0C0) : .rgb(0xD8DCE0))
                lx += 60
            }
        }
    }

    private static func platform(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for s in World.stations {
            let cx = sx(s.pos, st, w)
            let half = Int(s.platformHalf * ppm)
            if cx + half < -40 || cx - half > w + 40 { continue }
            let x0 = cx - half
            let ww = half * 2
            let surf = railY - 11
            g.rect(x0, surf, ww, winH - surf, mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day))
            g.rect(x0, surf, ww, 3, mix(.rgb(0x44444A), .rgb(0xC6C0B6), day))
            g.rect(x0, surf, ww, 1, .rgb(0xE8C93E))
            var tx = x0
            while tx < x0 + ww {
                g.rect(tx, surf + 5, 3, 2, mix(.rgb(0x34343A), .rgb(0x9E988E), day))
                tx += 7
            }
            var bx = x0 + 70
            while bx < x0 + ww - 70 {
                g.rect(bx, surf - 4, 22, 3, .rgb(0x2E86C1))
                g.rect(bx, surf - 9, 22, 3, .rgb(0x2E86C1))
                g.rect(bx + 1, surf - 1, 2, 3, .rgb(0x3A4048))
                g.rect(bx + 19, surf - 1, 2, 3, .rgb(0x3A4048))
                bx += 200
            }
        }
    }

    private static func stationSigns(_ g: Pix, _ st: GameState, _ w: Int, flipped: Bool) {
        for s in World.stations {
            var cx = sx(s.pos, st, w)
            if flipped { cx = w - cx }
            if cx < -80 || cx > w + 80 { continue }
            let label = s.name(st.lang)
            let tw = g.textWidth(label, size: 8) + 12
            g.rect(cx - tw / 2, railY - 80, tw, 12, .rgb(0x123C6E))
            g.frame(cx - tw / 2, railY - 80, tw, 12, .rgb(0x3C7ACE))
            g.text(label, cx, railY - 79, size: 8, color: .white, align: .center)
        }
    }

    private static func passengers(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let coats: [UIColor] = [.rgb(0xC0392B), .rgb(0x2C6DBE), .rgb(0x2FA35A), .rgb(0xE8B33C),
                                .rgb(0x8E44AD), .rgb(0xE67E22), .rgb(0x34495E)]
        for s in World.stations {
            if abs(s.pos - st.distance) > 90 { continue }
            for p in st.passengersFor(s.index) where !p.done {
                let x = sx(p.pos, st, w)
                if x < -12 || x > w + 12 { continue }
                let base = railY - 11
                let coat = mix(coats[p.coat % coats.count].shade(-0.4), coats[p.coat % coats.count], max(0.35, day))
                let step = p.boarding ? Int(sin(p.phase) * 2) : 0
                g.rect(x - 1, base - 5, 2, 5, .rgb(0x2A2F36))
                g.rect(x + 1, base - 5, 2, 5, .rgb(0x2A2F36))
                if p.boarding {
                    g.rect(x - 1 - step, base - 2, 2, 2, .rgb(0x22262C))
                    g.rect(x + 1 + step, base - 2, 2, 2, .rgb(0x22262C))
                }
                g.rect(x - 2, base - 13, 6, 8, coat)
                g.rect(x - 1, base - 17, 4, 4, mix(.rgb(0x6A5340), .rgb(0xD6A57E), max(0.4, day)))
                g.rect(x - 1, base - 18, 4, 2, .rgb(0x3A2A1E))
            }
        }
    }

    private static func ownTrain(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for t in st.traffic where t.active && t.sameTrack {
            let spec = TrainSpec.by(t.specId)
            drawTrain(g, st, spec: spec, cars: t.cars, frontPos: t.pos, base: railY,
                      w: w, day: day, doorAnim: 0, scale: 1.0, reversed: false)
        }
        drawTrain(g, st, spec: st.spec, cars: st.carCount, frontPos: st.distance, base: railY,
                  w: w, day: day, doorAnim: st.doorAnim, scale: 1.0, reversed: false)
    }

    static func drawTrain(_ g: Pix, _ st: GameState, spec: TrainSpec, cars: Int, frontPos: Double,
                          base: Int, w: Int, day: Double, doorAnim: Double, scale: Double, reversed: Bool) {
        let carPx = Int(spec.carLengthM * ppm * scale)
        let gapPx = max(3, Int(6 * scale))
        let bodyH = Int(spec.carHeightM * ppm * scale)
        let floorY = base - Int(11 * scale)
        let topY = floorY - bodyH
        let front = sx(frontPos, st, w)

        for c in 0..<cars {
            let x1 = reversed ? front + c * (carPx + gapPx) + carPx : front - c * (carPx + gapPx)
            let x0 = x1 - carPx
            if x1 < -60 || x0 > w + 60 { continue }
            drawCar(g, spec: spec, x0: x0, x1: x1, topY: topY, floorY: floorY,
                    head: !reversed && c == 0, tail: c == cars - 1, day: day, doorAnim: doorAnim,
                    night: day < 0.5, scale: scale, mirrored: reversed, wheelPhase: st.distance)
        }
    }

    private static func noseOutline(_ bodyEnd: Int, _ x1: Int, _ topY: Int, _ floorY: Int,
                                    _ style: NoseStyle) -> [(Int, Int)] {
        let h = Double(floorY - topY)
        let cut: Double
        let power: Double
        switch style {
        case .blunt: cut = h * 0.40; power = 0.75
        case .sharp: cut = h * 0.64; power = 1.7
        case .rounded: cut = h * 0.28; power = 0.5
        }
        var pts: [(Int, Int)] = []
        let n = 8
        for i in 0...n {
            let t = Double(i) / Double(n)
            let x = bodyEnd + Int((Double(x1 - bodyEnd) * t).rounded())
            let y = topY + Int((cut * pow(t, power)).rounded())
            pts.append((x, y))
        }
        pts.append((x1, floorY))
        pts.append((bodyEnd, floorY))
        return pts
    }

    private static func drawCar(_ g: Pix, spec: TrainSpec, x0: Int, x1: Int, topY: Int, floorY: Int,
                                head: Bool, tail: Bool, day: Double, doorAnim: Double,
                                night: Bool, scale: Double, mirrored: Bool, wheelPhase: Double) {
        let h = floorY - topY
        let nose = head ? Int(spec.noseLenM * ppm * scale) : 0
        let bodyEnd = x1 - nose
        let dim = max(0.45, day)
        let body = mix(spec.body.shade(-0.55), spec.body, dim)
        let roof = mix(spec.roof.shade(-0.55), spec.roof, dim)
        let main = mix(spec.liveryMain.shade(-0.5), spec.liveryMain, dim)
        let alt = mix(spec.liveryAlt.shade(-0.5), spec.liveryAlt, dim)
        let skirt = mix(spec.skirt.shade(-0.5), spec.skirt, dim)

        g.rect(x0, topY, bodyEnd - x0, h, body)
        g.rect(x0, topY, bodyEnd - x0, 3, roof)

        switch spec.id {
        case "lastochka":
            g.rect(x0, floorY - h / 4, bodyEnd - x0, h / 4, main)
            g.poly([(bodyEnd - 46, floorY - h / 4), (bodyEnd, floorY - h * 3 / 4),
                    (bodyEnd, floorY - h / 4)], main)
            g.rect(x0, floorY - 5, bodyEnd - x0, 5, skirt)
        case "sapsan":
            g.rect(x0, topY + h * 55 / 100, bodyEnd - x0, 3, main)
            g.rect(x0, floorY - h * 22 / 100, bodyEnd - x0, h * 22 / 100, mix(spec.bodyShade.shade(-0.5), spec.bodyShade, dim))
            g.rect(x0, floorY - 6, bodyEnd - x0, 6, skirt)
            g.rect(x0, floorY - h * 22 / 100, bodyEnd - x0, 1, alt)
        default:
            g.rect(x0, floorY - h * 30 / 100, bodyEnd - x0, h * 30 / 100, main)
            g.rect(x0, floorY - h * 30 / 100 - 3, bodyEnd - x0, 3, alt)
            g.rect(x0, floorY - 5, bodyEnd - x0, 5, skirt)
        }

        if head && nose > 0 {
            let outline = noseOutline(bodyEnd, x1 - 1, topY, floorY, spec.nose)
            g.poly(outline, body)
            switch spec.id {
            case "lastochka":
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 2), (x1 - 1, topY + h * 40 / 100),
                        (x1 - 1, topY + h * 52 / 100), (bodyEnd, topY + h * 16 / 100)], body)
            case "sapsan":
                g.poly([(x1 - nose / 3, topY + h * 46 / 100), (x1 - 1, topY + h * 64 / 100),
                        (x1 - 1, floorY), (x1 - nose / 3, floorY)], alt)
                g.poly([(bodyEnd, topY + h * 55 / 100), (x1 - nose / 3, topY + h * 66 / 100),
                        (x1 - nose / 3, topY + h * 72 / 100), (bodyEnd, topY + h * 61 / 100)], main)
            default:
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 3), (x1 - 1, topY + h * 26 / 100),
                        (x1 - 1, topY + h * 44 / 100), (bodyEnd, topY + h * 22 / 100)], body)
            }
            g.line(bodyEnd, topY, x1 - 1, topY + Int(Double(h) * (spec.nose == .sharp ? 0.30 : 0.20)), roof, 2)
        }

        let glass = night ? UIColor.rgb(0xF2D98A) : mix(spec.glass.shade(-0.3), spec.glass, dim)
        let winTop = topY + h * 18 / 100
        let wh = max(4, h * 30 / 100)
        let ww: Int
        let stepW: Int
        switch spec.id {
        case "sapsan": ww = 10; stepW = 18
        case "ivolga": ww = 18; stepW = 26
        default: ww = 14; stepW = 22
        }
        var wx = x0 + 6
        let winEnd = head ? bodyEnd - 6 : x1 - 6
        while wx + ww < winEnd {
            g.rect(wx, winTop, ww, wh, glass)
            g.rect(wx, winTop, ww, 1, glass.shade(0.25))
            wx += stepW
        }

        if head {
            let cabW = max(12, Int(28 * scale))
            g.rect(bodyEnd - cabW, topY + 4, cabW, h * 34 / 100, mix(.rgb(0x0E1620), spec.glass, dim))
            g.rect(bodyEnd - cabW, topY + 4, cabW, 2, mix(.rgb(0x25303C), spec.glass.shade(0.3), dim))
        }

        let doorW = max(6, Int(12 * scale))
        let open = Int(Double(doorW / 2) * doorAnim)
        for frac in [0.34, 0.74] {
            let dx = x1 - Int(Double(x1 - x0) * frac) - doorW / 2
            if dx < x0 + 3 || dx + doorW > bodyEnd - 3 { continue }
            let dh = h * 78 / 100
            g.rect(dx, floorY - dh, doorW, dh, .rgb(0x12161C))
            let dcol = mix(spec.doorColor.shade(-0.5), spec.doorColor, dim)
            g.rect(dx - open, floorY - dh, doorW / 2, dh, dcol)
            g.rect(dx + doorW / 2 + open, floorY - dh, doorW / 2, dh, dcol)
            g.rect(dx - open, floorY - dh, doorW / 2, 1, dcol.shade(0.25))
            g.rect(dx + doorW / 2 + open, floorY - dh, doorW / 2, 1, dcol.shade(0.25))
        }

        if head {
            let lx = x1 - max(4, Int(7 * scale))
            let ly = floorY - max(6, Int(9 * scale))
            g.rect(lx, ly, 5, 3, night ? .rgb(0xFFF9D0) : .rgb(0xD8DCE0))
            if night {
                g.rect(lx + 5, ly, 14, 1, .rgb(0xFFF3B0))
                g.rect(lx + 5, ly + 1, 8, 1, .rgb(0xFFE890))
            }
            g.rect(lx, ly + 5, 4, 2, .rgb(0xC02020))
        }

        let bogieY = floorY + max(2, Int(2 * scale))
        for bf in [0.22, 0.78] {
            let bx = x1 - Int(Double(x1 - x0) * bf)
            g.rect(bx - 11, bogieY, 22, 4, skirt)
            wheel(g, bx - 6, base: floorY + Int(11 * scale) - Int(4 * scale), r: max(2, Int(4 * scale)), phase: wheelPhase)
            wheel(g, bx + 6, base: floorY + Int(11 * scale) - Int(4 * scale), r: max(2, Int(4 * scale)), phase: wheelPhase)
        }

        if !head && !tail {
            let px = x0 + (x1 - x0) / 2
            g.rect(px - 9, topY - 2, 18, 2, mix(.rgb(0x2E343A), .rgb(0x5A626A), dim))
            g.line(px - 7, topY - 2, px + 2, topY - 11, .rgb(0x8A9098))
            g.line(px + 2, topY - 11, px + 9, topY - 5, .rgb(0x8A9098))
            g.rect(px + 1, topY - 13, 12, 2, .rgb(0xB6BCC2))
        } else {
            g.rect(x0 + (x1 - x0) / 3, topY - 2, 14, 2, mix(.rgb(0x2E343A), .rgb(0x6E767E), dim))
        }
    }

    private static func wheel(_ g: Pix, _ cx: Int, base: Int, r: Int, phase: Double) {
        g.circle(cx, base, r, .rgb(0x24282E))
        if r > 2 {
            g.circle(cx, base, r - 1, .rgb(0x6E767E))
            let a = phase * 2.2
            let (x1, y1) = g.polar(cx, base, Double(r - 1), a)
            g.rect(x1, y1, 1, 1, .rgb(0x24282E))
        }
    }
}
