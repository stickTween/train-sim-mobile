import UIKit

enum WorldRenderer {

    static let ppm: Double = 13
    static let horizonY = 109
    static let railY = 128
    static let farRailY = 104
    static let winH = 157

    static func frontX(_ w: Int) -> Int { w - 96 }

    static func sx(_ pos: Double, _ st: GameState, _ w: Int) -> Int {
        Int(((pos - st.distance - st.camOffset) * ppm).rounded()) + frontX(w)
    }

    static func mix(_ a: UIColor, _ b: UIColor, _ t: Double) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        a.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        b.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        let f = CGFloat(max(0, min(1, t)))
        return UIColor(red: r1 + (r2 - r1) * f, green: g1 + (g2 - g1) * f,
                       blue: b1 + (b2 - b1) * f, alpha: 1)
    }

    static func draw(_ g: Pix, _ st: GameState) {
        let w = g.width
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))

        let day = st.dayPhase
        sky(g, st, w, day)
        hills(g, st, w, day)
        river(g, st, w, day)
        props(g, st, w, day)
        farTrack(g, st, w, day)
        canopy(g, st, w, day)
        ground(g, st, w, day)
        bridge(g, st, w, day)
        signals(g, st, w, day)
        headlightCone(g, st, w, day)
        trains(g, st, w, day)
        platform(g, st, w, day)
        people(g, st, w, day)
        stationSigns(g, st, w)
        weather(g, st, w, day)

        g.ctx.restoreGState()
        g.rect(0, winH - 2, w, 2, .rgb(0x10141A))
    }

    private static func sky(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        var top = mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day)
        var bot = mix(.rgb(0x203050), .rgb(0xC6DCEE), day)
        if day > 0.02 && day < 0.98 {
            top = mix(top, .rgb(0x8E4A6E), 0.30)
            bot = mix(bot, .rgb(0xE8A060), 0.40)
        }
        if st.weather == 1 { top = mix(top, .rgb(0x6E7885), 0.45); bot = mix(bot, .rgb(0x9AA4B0), 0.45) }
        if st.weather == 2 { top = mix(top, .rgb(0x3A4450), 0.60); bot = mix(bot, .rgb(0x6E7A88), 0.55) }
        if st.weather == 3 { top = mix(top, .rgb(0x8E98A6), 0.55); bot = mix(bot, .rgb(0xB8C0CA), 0.60) }
        g.gradientV(0, 0, w, horizonY, top, bot, steps: 20)

        if day < 0.45 && st.weather < 2 {
            for i in 0..<36 {
                let x = Int(World.rnd(i, 61) * Double(w))
                let y = Int(World.rnd(i, 67) * Double(horizonY - 30))
                g.rect(x, y, 1, 1, World.rnd(i, 71) > 0.6 ? .rgb(0xFFFFFF) : .rgb(0xB6C4E0))
            }
        }
        if st.weather < 2 {
            let cx = 80
            if day > 0.35 {
                g.circle(cx, 26, 12, .rgb(0xFFEFB0))
                g.circle(cx, 26, 9, .rgb(0xFFFBE0))
            } else {
                g.circle(cx, 26, 9, .rgb(0xE6ECF6))
                g.circle(cx + 4, 23, 8, mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day))
            }
        }
        let drift = Int((st.distance + st.camOffset) * 0.5) % (w + 320)
        for i in 0..<5 {
            let x = (i * 190 + 40 - drift + 1600) % (w + 320) - 160
            cloud(g, x, 14 + (i % 3) * 16, 2 + i % 2, day, st.weather)
        }
    }

    private static func cloud(_ g: Pix, _ x: Int, _ y: Int, _ size: Int, _ day: Double, _ wx: Int) {
        var c = mix(.rgb(0x36405C), .rgb(0xFFFFFF), day)
        var s = mix(.rgb(0x28304A), .rgb(0xD4E4F2), day)
        if wx >= 1 { c = mix(c, .rgb(0x8A93A0), 0.5); s = mix(s, .rgb(0x6E7784), 0.5) }
        let k = size
        g.rect(x, y + 3 * k, 22 * k, 3 * k, s)
        g.rect(x + 2 * k, y + k, 16 * k, 3 * k, c)
        g.rect(x + 6 * k, y, 9 * k, 3 * k, c)
        g.rect(x + 2 * k, y + 3 * k, 18 * k, 2 * k, c)
    }

    private static func hills(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        var far = mix(.rgb(0x1C2740), .rgb(0x7C97B4), day)
        var near = mix(.rgb(0x16251C), .rgb(0x5E7F5A), day)
        if st.weather >= 2 { far = mix(far, .rgb(0x8E98A4), 0.4); near = mix(near, .rgb(0x7A8480), 0.3) }
        let base = st.distance + st.camOffset
        var x = 0
        while x < w {
            let t = (Double(x) + base * ppm * 0.16) * 0.008
            let h = 22 + sin(t) * 8 + sin(t * 2.3) * 5
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, far)
            x += 2
        }
        x = 0
        while x < w {
            let t = (Double(x) + base * ppm * 0.34) * 0.013
            let h = 13 + sin(t * 1.4 + 1.2) * 7 + sin(t * 3.1) * 3
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, near)
            x += 2
        }
    }

    private static func river(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for r in World.rivers {
            let x0 = sx(r - World.bridgeHalf - 30, st, w)
            let x1 = sx(r + World.bridgeHalf + 30, st, w)
            if x1 < 0 || x0 > w { continue }
            let water = mix(.rgb(0x142236), .rgb(0x3E7096), day)
            let hi = mix(.rgb(0x1E3448), .rgb(0x6EA8CC), day)
            g.rect(x0, horizonY - 2, x1 - x0, winH - horizonY + 2, water)
            var yy = horizonY + 4
            while yy < winH {
                var xx = x0 + (yy % 7) * 3
                while xx < x1 {
                    g.rect(xx, yy, 6, 1, hi)
                    xx += 26
                }
                yy += 9
            }
        }
    }

    private static func ground(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        var grass = mix(.rgb(0x1E3020), .rgb(0x5F8544), day)
        var grass2 = mix(.rgb(0x17251A), .rgb(0x4F7038), day)
        let ballast = mix(.rgb(0x2A2A2E), .rgb(0x8A8377), day)
        if st.weather == 4 { grass = mix(grass, .white, 0.7); grass2 = mix(grass2, .white, 0.7) }

        let center = st.distance + st.camOffset
        var x = 0
        while x < w {
            let pos = center + Double(x - frontX(w)) / ppm
            if World.bridgeAt(pos) == nil {
                g.rect(x, horizonY, 4, railY - horizonY + 2, grass)
                g.rect(x, railY + 2, 4, 10, ballast)
                g.rect(x, railY + 12, 4, winH - railY - 12, grass2)
            }
            x += 4
        }

        let shift = Int(((st.distance + st.camOffset) * ppm).rounded()) % 8
        var sxp = -shift
        while sxp < w {
            g.rect(sxp, railY + 3, 4, 8, mix(.rgb(0x1E1A16), .rgb(0x5A4A38), day))
            sxp += 8
        }
        g.rect(0, railY, w, 3, mix(.rgb(0x555C64), .rgb(0xB9BEC4), day))
    }

    private static func bridge(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for r in World.rivers {
            let x0 = sx(r - World.bridgeHalf, st, w)
            let x1 = sx(r + World.bridgeHalf, st, w)
            if x1 < -40 || x0 > w + 40 { continue }
            let steel = mix(.rgb(0x2A3038), .rgb(0x7E8892), day)
            let deck = mix(.rgb(0x22262C), .rgb(0x5A6068), day)
            g.rect(x0, railY + 2, x1 - x0, 10, deck)
            g.rect(x0, railY + 12, x1 - x0, 4, steel)
            var px = x0
            while px <= x1 {
                g.rect(px, railY + 14, 4, winH - railY - 14, steel)
                px += 34
            }
            var tx = x0
            var up = true
            while tx < x1 {
                let a = (tx, railY - 4)
                let b = (min(x1, tx + 30), railY - 34)
                if up { g.line(a.0, a.1, b.0, b.1, steel, 2) } else { g.line(a.0, b.1, b.0, a.1, steel, 2) }
                up = !up
                tx += 30
            }
            g.rect(x0, railY - 36, x1 - x0, 3, steel)
            g.rect(x0, railY - 6, x1 - x0, 3, steel)
        }
    }

    private static func farTrack(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        g.rect(0, farRailY + 2, w, 6, mix(.rgb(0x26262A), .rgb(0x7E7870), day))
        g.rect(0, farRailY, w, 2, mix(.rgb(0x4A5058), .rgb(0xA6ACB2), day))
        for t in st.traffic where t.active && !t.sameTrack {
            drawConsist(g, st, spec: TrainSpec.by(t.specId), cars: t.cars, front: t.pos,
                        base: farRailY, w: w, day: day, doorAnim: 0, scale: 0.78, mirrored: true, cabin: true)
        }
    }

    private static func props(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let center = st.distance + st.camOffset
        let from = center - Double(frontX(w)) / ppm - 24
        let to = center + 44
        for p in World.props(from: from, to: to) {
            let x = sx(p.pos, st, w)
            if x < -110 || x > w + 110 { continue }
            switch p.kind {
            case 0: tree(g, x, farRailY + 2, 28 + p.seed % 26, p.seed, day, st.weather)
            case 1: bush(g, x, farRailY + 5, p.seed, day)
            case 2: building(g, x, farRailY - 2, p.seed, day)
            case 3: house(g, x, farRailY, p.seed, day)
            case 4: catenary(g, x, day)
            case 5: warehouse(g, x, farRailY, p.seed, day)
            case 6: industry(g, x, farRailY, p.seed, day)
            case 7: haystack(g, x, farRailY + 4, p.seed, day)
            default: break
            }
        }
    }

    private static func tree(_ g: Pix, _ x: Int, _ baseY: Int, _ h: Int, _ seed: Int, _ day: Double, _ wx: Int) {
        let trunkH = h / 3
        g.rect(x + 2, baseY - trunkH, 4, trunkH, mix(.rgb(0x1A1410), .rgb(0x4A3524), day))
        let greens: [UIColor] = [.rgb(0x2F6B34), .rgb(0x3B7C39), .rgb(0x28602E), .rgb(0x477F3C)]
        var c = mix(.rgb(0x14241A), greens[seed % greens.count], day)
        if wx == 4 { c = mix(c, .white, 0.45) }
        var y = baseY - trunkH
        for lay in 0..<3 {
            let ww = h / 2 - lay * 3
            g.rect(x + 4 - ww / 2, y - h / 4, ww, h / 4 + 3, c)
            g.rect(x + 4 - ww / 2, y - h / 4, ww, 2, c.shade(0.12))
            y -= h / 5
        }
    }

    private static func bush(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let c = mix(.rgb(0x16281A), seed % 2 == 0 ? .rgb(0x3E7A3A) : .rgb(0x4C8A42), day)
        g.rect(x, baseY - 7, 12, 7, c)
        g.rect(x + 2, baseY - 10, 8, 4, c.shade(0.1))
    }

    private static func haystack(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let c = mix(.rgb(0x3A3020), .rgb(0xC8A854), day)
        g.circle(x + 7, baseY - 6, 7, c)
        g.rect(x, baseY - 4, 15, 4, c.shade(-0.15))
    }

    private static func house(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let hw = 24 + seed % 16
        let hh = 17 + seed % 10
        let walls: [UIColor] = [.rgb(0xD8C7A8), .rgb(0xC9B79B), .rgb(0xB6C2CC), .rgb(0xD9C0B0)]
        let roofs: [UIColor] = [.rgb(0x8A3B32), .rgb(0x5A6470), .rgb(0x7A5236)]
        g.rect(x, baseY - hh, hw, hh, mix(.rgb(0x2A2A30), walls[seed % walls.count], day))
        g.poly([(x - 3, baseY - hh), (x + hw / 2, baseY - hh - 10), (x + hw + 3, baseY - hh)],
               mix(.rgb(0x1E1E24), roofs[seed % roofs.count], day))
        var wx = x + 4
        var i = 0
        while wx < x + hw - 6 {
            let lit = day < 0.5 && (seed + i) % 3 != 0
            g.rect(wx, baseY - hh + 6, 6, 6, lit ? .rgb(0xFFE9A0) : mix(.rgb(0x181C24), .rgb(0x3A4E60), day))
            g.frame(wx, baseY - hh + 6, 6, 6, mix(.rgb(0x101418), .rgb(0x8A7E6E), day))
            wx += 11
            i += 1
        }
        g.rect(x + hw / 2 - 3, baseY - 9, 7, 9, mix(.rgb(0x201810), .rgb(0x5A4430), day))
    }

    private static func building(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let bw = 20 + seed % 20
        let bh = 34 + seed % 52
        g.rect(x, baseY - bh, bw, bh, mix(.rgb(0x232833), .rgb(0x9AA6B2), day))
        g.rect(x, baseY - bh, bw, 3, mix(.rgb(0x2C323E), .rgb(0xB2BCC6), day))
        g.rect(x + bw - 3, baseY - bh, 3, bh, mix(.rgb(0x1B1F27), .rgb(0x7E8A96), day))
        var wy = baseY - bh + 7
        var row = 0
        while wy < baseY - 6 {
            var wx = x + 3
            var col = 0
            while wx < x + bw - 4 {
                let lit = day < 0.5 && ((seed + row * 7 + col * 3) % 5 < 2)
                g.rect(wx, wy, 3, 4, lit ? .rgb(0xFFE08A) : mix(.rgb(0x141820), .rgb(0x54606C), day))
                wx += 6
                col += 1
            }
            wy += 8
            row += 1
        }
        if seed % 3 == 0 {
            g.rect(x + bw / 2 - 1, baseY - bh - 12, 2, 12, mix(.rgb(0x2A2F36), .rgb(0x8A9098), day))
            g.rect(x + bw / 2 - 2, baseY - bh - 14, 4, 3, .rgb(0xE04030))
        }
    }

    private static func warehouse(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let bw = 40 + seed % 26
        let bh = 20 + seed % 10
        g.rect(x, baseY - bh, bw, bh, mix(.rgb(0x2A2E34), .rgb(0x93A0A8), day))
        g.rect(x, baseY - bh - 4, bw, 4, mix(.rgb(0x1E2228), .rgb(0x5E6A72), day))
        var sxx = x + 4
        while sxx < x + bw - 6 {
            g.rect(sxx, baseY - bh + 4, 2, bh - 8, mix(.rgb(0x20242A), .rgb(0x7A868E), day))
            sxx += 8
        }
        g.rect(x + bw / 2 - 8, baseY - 12, 16, 12, mix(.rgb(0x181C20), .rgb(0x46505A), day))
    }

    private static func industry(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        if seed % 2 == 0 {
            let h = 40 + seed % 24
            g.rect(x + 4, baseY - h, 8, h, mix(.rgb(0x2E3238), .rgb(0xB0A89C), day))
            g.rect(x + 3, baseY - h, 10, 4, mix(.rgb(0x24282C), .rgb(0x8A8278), day))
            g.rect(x + 4, baseY - h + 12, 8, 3, .rgb(0xB04030))
        } else {
            g.circle(x + 12, baseY - 14, 13, mix(.rgb(0x2A3038), .rgb(0xA8B0B8), day))
            g.rect(x - 1, baseY - 14, 26, 14, mix(.rgb(0x2A3038), .rgb(0xA8B0B8), day))
            g.rect(x - 1, baseY - 16, 26, 3, mix(.rgb(0x1E2228), .rgb(0x78828A), day))
        }
    }

    private static func catenary(_ g: Pix, _ x: Int, _ day: Double) {
        let c = mix(.rgb(0x3A4048), .rgb(0x8A9098), day)
        g.rect(x, railY - 60, 4, 60, c)
        g.rect(x - 32, railY - 60, 34, 3, c)
        g.rect(x - 29, railY - 57, 3, 7, c)
        g.rect(x - 4, railY - 4, 12, 4, mix(.rgb(0x24282E), .rgb(0x5A6068), day))
    }

    private static func signals(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        g.rect(0, railY - 52, w, 2, mix(.rgb(0x22262C), .rgb(0x3A4048), day))
        g.rect(0, railY - 43, w, 1, mix(.rgb(0x2A2E34), .rgb(0x4A5058), day))
        let step: Double = 700
        let center = st.distance + st.camOffset
        var i = Int((center - Double(w) / ppm) / step) - 1
        while Double(i) * step < center + 60 {
            let pos = Double(i) * step
            i += 1
            if pos < 0 { continue }
            let x = sx(pos, st, w)
            if x < -24 || x > w + 24 { continue }
            g.rect(x, railY - 46, 4, 46, .rgb(0x6E747A))
            g.rect(x - 4, railY - 64, 12, 19, .rgb(0x22262C))
            g.frame(x - 4, railY - 64, 12, 19, .rgb(0x12161A))
            let green = st.signalGreen(at: pos)
            g.circle(x + 2, railY - 58, 3, green ? .rgb(0x30E070) : .rgb(0x1E3A28))
            g.circle(x + 2, railY - 50, 3, green ? .rgb(0x3A2018) : .rgb(0xF04030))
        }
    }

    private static func headlightCone(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        guard st.headlights, day < 0.55 else { return }
        let x = sx(st.distance, st, w)
        let y = railY - 20
        let reach = 190
        let alpha = CGFloat((0.55 - day) / 0.55) * 0.55
        g.ctx.saveGState()
        g.ctx.setAlpha(alpha)
        g.poly([(x, y - 3), (x + reach, y - 26), (x + reach, y + 22), (x, y + 3)], .rgb(0xFFF3C0))
        g.ctx.setAlpha(alpha * 0.7)
        g.poly([(x, y - 2), (x + reach * 3 / 4, y - 14), (x + reach * 3 / 4, y + 13), (x, y + 2)], .rgb(0xFFF8DC))
        g.ctx.restoreGState()
    }

    private static func canopy(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for s in World.stations {
            let x0 = sx(s.platformStart, st, w)
            let ww = Int(s.platformLen * ppm)
            if x0 + ww < -60 || x0 > w + 60 { continue }
            var px = x0 + 26
            while px < x0 + ww - 26 {
                g.rect(px, railY - 76, 4, 18, mix(.rgb(0x3A4048), .rgb(0x9AA4AE), day))
                px += 78
            }
            g.rect(x0, railY - 84, ww, 8, mix(.rgb(0x14283A), .rgb(0x2E5F86), day))
            g.rect(x0, railY - 84, ww, 3, mix(.rgb(0x1C3A50), .rgb(0x3F7AA8), day))
            var lx = x0 + 40
            while lx < x0 + ww - 40 {
                g.rect(lx, railY - 75, 13, 3, day < 0.5 ? .rgb(0xFFF0C0) : .rgb(0xD8DCE0))
                lx += 78
            }
        }
    }

    private static func platform(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let surf = railY - 14
        for s in World.stations {
            let x0 = sx(s.platformStart, st, w)
            let ww = Int(s.platformLen * ppm)
            if x0 + ww < -60 || x0 > w + 60 { continue }
            g.rect(x0, surf, ww, winH - surf, mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day))
            g.rect(x0, surf, ww, 4, mix(.rgb(0x44444A), .rgb(0xC6C0B6), day))
            g.rect(x0, surf, ww, 2, .rgb(0xE8C93E))
            var tx = x0
            while tx < x0 + ww {
                g.rect(tx, surf + 7, 4, 2, mix(.rgb(0x34343A), .rgb(0x9E988E), day))
                tx += 9
            }
            var bx = x0 + 110
            while bx < x0 + ww - 110 {
                g.rect(bx, surf - 6, 28, 4, .rgb(0x2E86C1))
                g.rect(bx, surf - 12, 28, 4, .rgb(0x2E86C1))
                g.rect(bx + 1, surf - 2, 3, 4, .rgb(0x3A4048))
                g.rect(bx + 24, surf - 2, 3, 4, .rgb(0x3A4048))
                bx += 270
            }
            let mx = sx(s.pos, st, w)
            if mx > -30 && mx < w + 30 {
                g.rect(mx, surf - 26, 3, 26, .rgb(0x2E353D))
                g.rect(mx - 8, surf - 38, 19, 13, .rgb(0xF0F3F6))
                g.frame(mx - 8, surf - 38, 19, 13, .rgb(0x2E353D))
                g.rect(mx - 5, surf - 34, 13, 5, .rgb(0xC02020))
            }
        }
    }

    private static func stationSigns(_ g: Pix, _ st: GameState, _ w: Int) {
        for s in World.stations {
            let cx = sx(s.platformStart + s.platformLen / 2, st, w)
            if cx < -140 || cx > w + 140 { continue }
            let label = s.name(st.lang)
            let tw = g.textWidth(label, size: 10) + 16
            g.rect(cx - tw / 2, railY - 104, tw, 15, .rgb(0x123C6E))
            g.frame(cx - tw / 2, railY - 104, tw, 15, .rgb(0x3C7ACE))
            g.text(label, cx, railY - 103, size: 10, color: .white, align: .center)
        }
    }

    private static func weather(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        if st.weather == 3 {
            g.ctx.saveGState()
            g.ctx.setAlpha(0.30)
            g.rect(0, horizonY - 30, w, winH - horizonY + 30, .rgb(0xC6CED8))
            g.ctx.restoreGState()
        }
        guard st.weather == 2 || st.weather == 4 else { return }
        let snow = st.weather == 4
        let n = snow ? 70 : 110
        let t = st.time
        for i in 0..<n {
            let sp = snow ? 26.0 : 190.0
            let baseX = World.rnd(i, 81) * Double(w + 120) - 60
            let drift = snow ? sin(t * 1.2 + Double(i)) * 9 : -Double(st.speed) * 0.7
            let x = Int(baseX + drift - t * (snow ? 8 : 40)) % (w + 120) - 20
            let y = Int((World.rnd(i, 83) * Double(winH) + t * sp).truncatingRemainder(dividingBy: Double(winH)))
            if snow {
                g.rect(x, y, 2, 2, .rgb(0xF0F4FA))
            } else {
                g.rect(x, y, 1, 7, .rgb(0x9FC0DC))
            }
        }
    }

    private static func people(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let center = st.distance + st.camOffset
        for s in World.stations {
            if s.pos < center - 460 || s.platformStart > center + 120 { continue }
            for p in st.passengersFor(s.index) where !p.done {
                let x = sx(p.pos, st, w)
                if x < -30 || x > w + 30 { continue }
                Characters.draw(g, x: x, base: railY - 14, kind: p.kind, coat: p.coat,
                                phase: p.phase, running: p.running, facing: p.facing, day: day)
            }
        }
    }

    private static func trains(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for t in st.traffic where t.active && t.sameTrack {
            drawConsist(g, st, spec: TrainSpec.by(t.specId), cars: t.cars, front: t.pos,
                        base: railY, w: w, day: day, doorAnim: 0, scale: 1, mirrored: false, cabin: true)
        }
        drawConsist(g, st, spec: st.spec, cars: st.cars, front: st.distance,
                    base: railY, w: w, day: day, doorAnim: st.doorAnim, scale: 1,
                    mirrored: false, cabin: st.cabinLight)
    }

    static func drawConsist(_ g: Pix, _ st: GameState, spec: TrainSpec, cars: Int, front: Double,
                            base: Int, w: Int, day: Double, doorAnim: Double,
                            scale: Double, mirrored: Bool, cabin: Bool) {
        let carPx = Int(spec.carLengthM * ppm * scale)
        let gapPx = max(4, Int(8 * scale))
        let bodyH = Int(spec.carHeightM * ppm * scale)
        let floorY = base - Int(14 * scale)
        let topY = floorY - bodyH
        let fx = sx(front, st, w)
        for c in 0..<cars {
            let x1 = mirrored ? fx + (c + 1) * carPx + c * gapPx : fx - c * (carPx + gapPx)
            let x0 = x1 - carPx
            if x1 < -80 || x0 > w + 80 { continue }
            if c > 0 {
                let gx = mirrored ? x0 - gapPx : x1
                g.rect(gx, topY + bodyH / 4, gapPx, bodyH / 2, mix(.rgb(0x0C0F13), .rgb(0x24282E), day))
            }
            TrainArt.car(g, spec: spec, x0: x0, x1: x1, topY: topY, floorY: floorY, base: base,
                         head: !mirrored && c == 0, tail: c == cars - 1, day: day,
                         doorAnim: doorAnim, scale: scale, wheelPhase: st.distance, cabin: cabin)
        }
    }
}
