import UIKit

enum WorldRenderer {

    static let ppm: Double = 10
    static let horizonY = 82
    static let railY = 96
    static let farRailY = 78
    static let winH = 118

    static func frontX(_ w: Int) -> Int { w - 74 }

    static func sx(_ pos: Double, _ st: GameState, _ w: Int) -> Int {
        Int(((pos - st.distance - st.camOffset) * ppm).rounded()) + frontX(w)
    }

    private static func mix(_ a: UIColor, _ b: UIColor, _ t: Double) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        a.getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        b.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        let f = CGFloat(max(0, min(1, t)))
        return UIColor(red: r1 + (r2 - r1) * f, green: g1 + (g2 - g1) * f,
                       blue: b1 + (b2 - b1) * f, alpha: 1)
    }

    static func draw(_ g: Pix, _ st: GameState) {
        let w = g.width
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(winH)))

        let day = st.dayPhase
        sky(g, st, w, day)
        hills(g, st, w, day)
        props(g, st, w, day)
        farTrack(g, st, w, day)
        canopy(g, st, w, day)
        ground(g, st, w, day)
        signals(g, st, w, day)
        trains(g, st, w, day)
        platform(g, st, w, day)
        passengers(g, st, w, day)
        stationSigns(g, st, w)

        g.ctx.restoreGState()
        g.rect(0, winH - 2, w, 2, .rgb(0x10141A))
    }

    private static func sky(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        var top = mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day)
        var bot = mix(.rgb(0x203050), .rgb(0xC6DCEE), day)
        if day > 0.02 && day < 0.98 {
            top = mix(top, .rgb(0x8E4A6E), 0.30)
            bot = mix(bot, .rgb(0xE8A060), 0.40)
        }
        g.gradientV(0, 0, w, horizonY, top, bot, steps: 16)

        if day < 0.45 {
            for i in 0..<30 {
                let x = Int(World.rnd(i, 61) * Double(w))
                let y = Int(World.rnd(i, 67) * Double(horizonY - 24))
                g.rect(x, y, 1, 1, World.rnd(i, 71) > 0.6 ? .rgb(0xFFFFFF) : .rgb(0xB6C4E0))
            }
        }

        let cx = 62
        if day > 0.35 {
            g.circle(cx, 20, 9, .rgb(0xFFEFB0))
            g.circle(cx, 20, 7, .rgb(0xFFFBE0))
        } else {
            g.circle(cx, 20, 7, .rgb(0xE6ECF6))
            g.circle(cx + 3, 18, 6, mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day))
        }

        let drift = Int((st.distance + st.camOffset) * 0.5) % (w + 260)
        for i in 0..<4 {
            let x = (i * 170 + 30 - drift + 1040) % (w + 260) - 130
            cloud(g, x, 12 + (i % 3) * 13, 1 + i % 2, day)
        }
    }

    private static func cloud(_ g: Pix, _ x: Int, _ y: Int, _ size: Int, _ day: Double) {
        let c = mix(.rgb(0x36405C), .rgb(0xFFFFFF), day)
        let s = mix(.rgb(0x28304A), .rgb(0xD4E4F2), day)
        let k = size + 1
        g.rect(x, y + 3 * k, 22 * k, 3 * k, s)
        g.rect(x + 2 * k, y + k, 16 * k, 3 * k, c)
        g.rect(x + 6 * k, y, 9 * k, 3 * k, c)
        g.rect(x + 2 * k, y + 3 * k, 18 * k, 2 * k, c)
    }

    private static func hills(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let far = mix(.rgb(0x1C2740), .rgb(0x7C97B4), day)
        let near = mix(.rgb(0x16251C), .rgb(0x5E7F5A), day)
        let base = st.distance + st.camOffset
        var x = 0
        while x < w {
            let t = (Double(x) + base * ppm * 0.16) * 0.010
            let h = 16 + sin(t) * 6 + sin(t * 2.3) * 3.5
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, far)
            x += 2
        }
        x = 0
        while x < w {
            let t = (Double(x) + base * ppm * 0.34) * 0.016
            let h = 10 + sin(t * 1.4 + 1.2) * 5 + sin(t * 3.1) * 2.5
            g.rect(x, horizonY - Int(h), 2, Int(h) + 2, near)
            x += 2
        }
    }

    private static func ground(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let grass = mix(.rgb(0x1E3020), .rgb(0x5F8544), day)
        let grass2 = mix(.rgb(0x17251A), .rgb(0x4F7038), day)
        let ballast = mix(.rgb(0x2A2A2E), .rgb(0x8A8377), day)
        g.rect(0, horizonY, w, railY - horizonY + 2, grass)
        g.rect(0, railY + 2, w, 8, ballast)
        g.rect(0, railY + 10, w, winH - railY - 10, grass2)

        let shift = Int(((st.distance + st.camOffset) * ppm).rounded()) % 6
        var x = -shift
        while x < w {
            g.rect(x, railY + 3, 3, 6, mix(.rgb(0x1E1A16), .rgb(0x5A4A38), day))
            x += 6
        }
        g.rect(0, railY, w, 2, mix(.rgb(0x555C64), .rgb(0xB9BEC4), day))
    }

    private static func farTrack(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        g.rect(0, farRailY + 2, w, 5, mix(.rgb(0x26262A), .rgb(0x7E7870), day))
        g.rect(0, farRailY, w, 2, mix(.rgb(0x4A5058), .rgb(0xA6ACB2), day))
        for t in st.traffic where t.active && !t.sameTrack {
            drawConsist(g, st, spec: TrainSpec.by(t.specId), cars: t.cars, front: t.pos,
                        base: farRailY, w: w, day: day, doorAnim: 0, scale: 0.8, mirrored: true)
        }
    }

    private static func props(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let center = st.distance + st.camOffset
        let from = center - Double(frontX(w)) / ppm - 20
        let to = center + 40
        for p in World.props(from: from, to: to) {
            let x = sx(p.pos, st, w)
            if x < -80 || x > w + 80 { continue }
            switch p.kind {
            case 0: tree(g, x, farRailY + 2, 22 + p.seed % 20, p.seed, day)
            case 1: bush(g, x, farRailY + 4, p.seed, day)
            case 2: building(g, x, farRailY - 2, p.seed, day)
            case 3: house(g, x, farRailY, p.seed, day)
            case 4: catenary(g, x, day)
            default: break
            }
        }
    }

    private static func tree(_ g: Pix, _ x: Int, _ baseY: Int, _ h: Int, _ seed: Int, _ day: Double) {
        let trunkH = h / 3
        g.rect(x + 2, baseY - trunkH, 3, trunkH, mix(.rgb(0x1A1410), .rgb(0x4A3524), day))
        let greens: [UIColor] = [.rgb(0x2F6B34), .rgb(0x3B7C39), .rgb(0x28602E), .rgb(0x477F3C)]
        let c = mix(.rgb(0x14241A), greens[seed % greens.count], day)
        var y = baseY - trunkH
        for lay in 0..<3 {
            let ww = h / 2 - lay * 2
            g.rect(x + 3 - ww / 2, y - h / 4, ww, h / 4 + 2, c)
            y -= h / 5
        }
    }

    private static func bush(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let c = mix(.rgb(0x16281A), seed % 2 == 0 ? .rgb(0x3E7A3A) : .rgb(0x4C8A42), day)
        g.rect(x, baseY - 5, 9, 5, c)
        g.rect(x + 1, baseY - 7, 7, 3, c)
    }

    private static func house(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let hw = 18 + seed % 12
        let hh = 13 + seed % 8
        let walls: [UIColor] = [.rgb(0xD8C7A8), .rgb(0xC9B79B), .rgb(0xB6C2CC), .rgb(0xD9C0B0)]
        let roofs: [UIColor] = [.rgb(0x8A3B32), .rgb(0x5A6470), .rgb(0x7A5236)]
        g.rect(x, baseY - hh, hw, hh, mix(.rgb(0x2A2A30), walls[seed % walls.count], day))
        g.rect(x - 2, baseY - hh - 4, hw + 4, 4, mix(.rgb(0x1E1E24), roofs[seed % roofs.count], day))
        var wx = x + 3
        var i = 0
        while wx < x + hw - 4 {
            let lit = day < 0.5 && (seed + i) % 3 != 0
            g.rect(wx, baseY - hh + 5, 4, 4, lit ? .rgb(0xFFE9A0) : mix(.rgb(0x181C24), .rgb(0x3A4E60), day))
            wx += 8
            i += 1
        }
    }

    private static func building(_ g: Pix, _ x: Int, _ baseY: Int, _ seed: Int, _ day: Double) {
        let bw = 14 + seed % 14
        let bh = 22 + seed % 34
        g.rect(x, baseY - bh, bw, bh, mix(.rgb(0x232833), .rgb(0x9AA6B2), day))
        g.rect(x, baseY - bh, bw, 2, mix(.rgb(0x2C323E), .rgb(0xB2BCC6), day))
        var wy = baseY - bh + 5
        var row = 0
        while wy < baseY - 4 {
            var wx = x + 2
            var col = 0
            while wx < x + bw - 3 {
                let lit = day < 0.5 && ((seed + row * 7 + col * 3) % 5 < 2)
                g.rect(wx, wy, 2, 3, lit ? .rgb(0xFFE08A) : mix(.rgb(0x141820), .rgb(0x54606C), day))
                wx += 4
                col += 1
            }
            wy += 6
            row += 1
        }
    }

    private static func catenary(_ g: Pix, _ x: Int, _ day: Double) {
        let c = mix(.rgb(0x3A4048), .rgb(0x8A9098), day)
        g.rect(x, railY - 46, 3, 46, c)
        g.rect(x - 24, railY - 46, 26, 2, c)
        g.rect(x - 22, railY - 44, 2, 5, c)
    }

    private static func signals(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        g.rect(0, railY - 40, w, 1, mix(.rgb(0x22262C), .rgb(0x3A4048), day))
        g.rect(0, railY - 33, w, 1, mix(.rgb(0x2A2E34), .rgb(0x4A5058), day))
        let step: Double = 700
        let center = st.distance + st.camOffset
        var i = Int((center - Double(w) / ppm) / step) - 1
        while Double(i) * step < center + 60 {
            let pos = Double(i) * step
            i += 1
            if pos < 0 { continue }
            let x = sx(pos, st, w)
            if x < -20 || x > w + 20 { continue }
            g.rect(x, railY - 34, 3, 34, .rgb(0x6E747A))
            g.rect(x - 3, railY - 47, 9, 14, .rgb(0x22262C))
            g.frame(x - 3, railY - 47, 9, 14, .rgb(0x12161A))
            let green = st.signalGreen(at: pos)
            g.circle(x + 1, railY - 43, 2, green ? .rgb(0x30E070) : .rgb(0x1E3A28))
            g.circle(x + 1, railY - 37, 2, green ? .rgb(0x3A2018) : .rgb(0xF04030))
        }
    }

    private static func canopy(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for s in World.stations {
            let x0 = sx(s.platformStart, st, w)
            let ww = Int(s.platformLen * ppm)
            if x0 + ww < -40 || x0 > w + 40 { continue }
            var px = x0 + 20
            while px < x0 + ww - 20 {
                g.rect(px, railY - 58, 3, 14, mix(.rgb(0x3A4048), .rgb(0x9AA4AE), day))
                px += 60
            }
            g.rect(x0, railY - 64, ww, 6, mix(.rgb(0x14283A), .rgb(0x2E5F86), day))
            g.rect(x0, railY - 64, ww, 2, mix(.rgb(0x1C3A50), .rgb(0x3F7AA8), day))
            var lx = x0 + 30
            while lx < x0 + ww - 30 {
                g.rect(lx, railY - 57, 10, 2, day < 0.5 ? .rgb(0xFFF0C0) : .rgb(0xD8DCE0))
                lx += 60
            }
        }
    }

    private static func platform(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let surf = railY - 11
        for s in World.stations {
            let x0 = sx(s.platformStart, st, w)
            let ww = Int(s.platformLen * ppm)
            if x0 + ww < -40 || x0 > w + 40 { continue }
            g.rect(x0, surf, ww, winH - surf, mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day))
            g.rect(x0, surf, ww, 3, mix(.rgb(0x44444A), .rgb(0xC6C0B6), day))
            g.rect(x0, surf, ww, 1, .rgb(0xE8C93E))
            var tx = x0
            while tx < x0 + ww {
                g.rect(tx, surf + 5, 3, 2, mix(.rgb(0x34343A), .rgb(0x9E988E), day))
                tx += 7
            }
            var bx = x0 + 80
            while bx < x0 + ww - 80 {
                g.rect(bx, surf - 4, 22, 3, .rgb(0x2E86C1))
                g.rect(bx, surf - 9, 22, 3, .rgb(0x2E86C1))
                g.rect(bx + 1, surf - 1, 2, 3, .rgb(0x3A4048))
                g.rect(bx + 19, surf - 1, 2, 3, .rgb(0x3A4048))
                bx += 210
            }
            let mx = sx(s.pos, st, w)
            if mx > -20 && mx < w + 20 {
                g.rect(mx, surf - 20, 2, 20, .rgb(0x2E353D))
                g.rect(mx - 6, surf - 28, 14, 9, .rgb(0xF0F3F6))
                g.frame(mx - 6, surf - 28, 14, 9, .rgb(0x2E353D))
                g.rect(mx - 3, surf - 25, 8, 3, .rgb(0xC02020))
            }
        }
    }

    private static func stationSigns(_ g: Pix, _ st: GameState, _ w: Int) {
        for s in World.stations {
            let cx = sx(s.platformStart + s.platformLen / 2, st, w)
            if cx < -100 || cx > w + 100 { continue }
            let label = s.name(st.lang)
            let tw = g.textWidth(label, size: 8) + 12
            g.rect(cx - tw / 2, railY - 80, tw, 12, .rgb(0x123C6E))
            g.frame(cx - tw / 2, railY - 80, tw, 12, .rgb(0x3C7ACE))
            g.text(label, cx, railY - 79, size: 8, color: .white, align: .center)
        }
    }

    private static func passengers(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        let coats: [UIColor] = [.rgb(0xC0392B), .rgb(0x2C6DBE), .rgb(0x2FA35A), .rgb(0xE8B33C),
                                .rgb(0x8E44AD), .rgb(0xE67E22), .rgb(0x34495E)]
        let center = st.distance + st.camOffset
        for s in World.stations {
            if s.pos < center - 400 || s.platformStart > center + 100 { continue }
            for p in st.passengersFor(s.index) where !p.done {
                let x = sx(p.pos, st, w)
                if x < -12 || x > w + 12 { continue }
                let base = railY - 11
                let c = coats[p.coat % coats.count]
                let coat = mix(c.shade(-0.45), c, max(0.35, day))
                let step = p.boarding ? Int(sin(p.phase) * 2) : 0
                g.rect(x - 1, base - 5, 2, 5, .rgb(0x2A2F36))
                g.rect(x + 1, base - 5, 2, 5, .rgb(0x2A2F36))
                if p.boarding {
                    g.rect(x - 1 - step, base - 2, 2, 2, .rgb(0x22262C))
                    g.rect(x + 1 + step, base - 2, 2, 2, .rgb(0x22262C))
                }
                g.rect(x - 2, base - 13, 6, 8, coat)
                g.rect(x - 2, base - 13, 6, 1, coat.shade(0.2))
                g.rect(x - 1, base - 17, 4, 4, mix(.rgb(0x6A5340), .rgb(0xD6A57E), max(0.4, day)))
                g.rect(x - 1, base - 18, 4, 2, .rgb(0x3A2A1E))
            }
        }
    }

    private static func trains(_ g: Pix, _ st: GameState, _ w: Int, _ day: Double) {
        for t in st.traffic where t.active && t.sameTrack {
            drawConsist(g, st, spec: TrainSpec.by(t.specId), cars: t.cars, front: t.pos,
                        base: railY, w: w, day: day, doorAnim: 0, scale: 1, mirrored: false)
        }
        drawConsist(g, st, spec: st.spec, cars: st.cars, front: st.distance,
                    base: railY, w: w, day: day, doorAnim: st.doorAnim, scale: 1, mirrored: false)
    }

    static func drawConsist(_ g: Pix, _ st: GameState, spec: TrainSpec, cars: Int, front: Double,
                            base: Int, w: Int, day: Double, doorAnim: Double,
                            scale: Double, mirrored: Bool) {
        let carPx = Int(spec.carLengthM * ppm * scale)
        let gapPx = max(3, Int(6 * scale))
        let bodyH = Int(spec.carHeightM * ppm * scale)
        let floorY = base - Int(11 * scale)
        let topY = floorY - bodyH
        let fx = sx(front, st, w)

        for c in 0..<cars {
            let x1 = mirrored ? fx + (c + 1) * carPx + c * gapPx : fx - c * (carPx + gapPx)
            let x0 = x1 - carPx
            if x1 < -70 || x0 > w + 70 { continue }
            if c > 0 {
                let gx = mirrored ? x0 - gapPx : x1
                g.rect(gx, topY + bodyH / 4, gapPx, bodyH / 2, mix(.rgb(0x0C0F13), .rgb(0x24282E), day))
            }
            car(g, spec: spec, x0: x0, x1: x1, topY: topY, floorY: floorY, base: base,
                head: !mirrored && c == 0, tail: c == cars - 1,
                day: day, doorAnim: doorAnim, scale: scale, wheelPhase: st.distance)
        }
    }

    private static func noseOutline(_ a: Int, _ b: Int, _ topY: Int, _ floorY: Int,
                                    _ style: NoseStyle) -> [(Int, Int)] {
        let h = Double(floorY - topY)
        let cut: Double
        let power: Double
        switch style {
        case .blunt: cut = h * 0.42; power = 0.72
        case .sharp: cut = h * 0.66; power = 1.75
        case .rounded: cut = h * 0.30; power = 0.48
        }
        var pts: [(Int, Int)] = []
        for i in 0...10 {
            let t = Double(i) / 10
            pts.append((a + Int((Double(b - a) * t).rounded()),
                        topY + Int((cut * pow(t, power)).rounded())))
        }
        pts.append((b, floorY))
        pts.append((a, floorY))
        return pts
    }

    private static func car(_ g: Pix, spec: TrainSpec, x0: Int, x1: Int, topY: Int, floorY: Int,
                            base: Int, head: Bool, tail: Bool, day: Double,
                            doorAnim: Double, scale: Double, wheelPhase: Double) {
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: CGFloat(x0 - 2), y: CGFloat(topY - 16),
                              width: CGFloat(x1 - x0 + 4), height: CGFloat(base - topY + 22)))

        let h = floorY - topY
        let nose = head ? Int(spec.noseLenM * ppm * scale) : 0
        let bodyEnd = x1 - nose
        let dim = max(0.42, day)
        let body = mix(spec.body.shade(-0.58), spec.body, dim)
        let shade = mix(spec.bodyShade.shade(-0.58), spec.bodyShade, dim)
        let roof = mix(spec.roof.shade(-0.58), spec.roof, dim)
        let main = mix(spec.liveryMain.shade(-0.52), spec.liveryMain, dim)
        let alt = mix(spec.liveryAlt.shade(-0.52), spec.liveryAlt, dim)
        let skirt = mix(spec.skirt.shade(-0.55), spec.skirt, dim)
        let night = day < 0.5

        g.rect(x0, topY, bodyEnd - x0, h, body)
        g.rect(x0, topY, bodyEnd - x0, 3, roof)
        g.rect(x0, topY + 3, bodyEnd - x0, 1, roof.shade(-0.2))

        let bandTop = topY + h * 20 / 100
        let bandH = max(6, h * 30 / 100)

        switch spec.id {
        case "lastochka":
            g.rect(x0, floorY - h * 26 / 100, bodyEnd - x0, h * 26 / 100, main)
            g.rect(x0, floorY - h * 26 / 100 - 2, bodyEnd - x0, 2, main.shade(0.18))
            g.poly([(bodyEnd - 70, floorY - h * 26 / 100), (bodyEnd, floorY - h * 82 / 100),
                    (bodyEnd, floorY - h * 26 / 100)], main)
            g.rect(x0, bandTop - 3, bodyEnd - x0, bandH + 6, mix(.rgb(0x161C24), .rgb(0x2A323C), dim))
        case "sapsan":
            g.rect(x0, bandTop - 2, bodyEnd - x0, bandH + 4, mix(.rgb(0x121A22), .rgb(0x1E2833), dim))
            g.rect(x0, topY + h * 56 / 100, bodyEnd - x0, 3, main)
            g.rect(x0, floorY - h * 20 / 100, bodyEnd - x0, h * 20 / 100, shade)
            g.rect(x0, floorY - h * 20 / 100, bodyEnd - x0, 1, alt)
        default:
            g.rect(x0, bandTop - 3, bodyEnd - x0, bandH + 6, mix(.rgb(0x161C24), .rgb(0x27313C), dim))
            g.rect(x0, floorY - h * 30 / 100, bodyEnd - x0, h * 30 / 100, main)
            g.rect(x0, floorY - h * 30 / 100 - 3, bodyEnd - x0, 3, alt)
        }

        g.rect(x0, floorY - 5, bodyEnd - x0, 5, skirt)

        if head && nose > 0 {
            let outline = noseOutline(bodyEnd, x1 - 1, topY, floorY, spec.nose)
            g.poly(outline, body)
            switch spec.id {
            case "lastochka":
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 3), (x1 - 1, topY + h * 42 / 100),
                        (x1 - 1, topY + h * 56 / 100), (bodyEnd, topY + h * 17 / 100)],
                       mix(.rgb(0x141A22), .rgb(0x22303C), dim))
            case "sapsan":
                g.poly([(x1 - nose * 4 / 10, topY + h * 50 / 100), (x1 - 1, topY + h * 66 / 100),
                        (x1 - 1, floorY), (x1 - nose * 4 / 10, floorY)], alt)
                g.poly([(bodyEnd, topY + h * 56 / 100), (x1 - nose * 4 / 10, topY + h * 64 / 100),
                        (x1 - nose * 4 / 10, topY + h * 70 / 100), (bodyEnd, topY + h * 62 / 100)], main)
                g.poly([(bodyEnd, topY + 4), (x1 - nose / 2, topY + h * 40 / 100),
                        (x1 - nose / 2, topY + h * 54 / 100), (bodyEnd, topY + h * 18 / 100)],
                       mix(.rgb(0x0E141C), .rgb(0x1C2836), dim))
            default:
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 4), (x1 - 1, topY + h * 27 / 100),
                        (x1 - 1, topY + h * 47 / 100), (bodyEnd, topY + h * 22 / 100)],
                       mix(.rgb(0x141A22), .rgb(0x22303C), dim))
                g.rect(x1 - nose, floorY - 6, nose, 6, alt)
            }
        }

        let glass = night ? UIColor.rgb(0xEFD79A) : mix(spec.glass.shade(-0.25), spec.glass, dim)
        let winTop = bandTop + 2
        let winH2 = max(4, bandH - 4)
        let ww: Int
        let stepW: Int
        switch spec.id {
        case "sapsan": ww = 11; stepW = 17
        case "ivolga": ww = 20; stepW = 27
        default: ww = 15; stepW = 22
        }
        let doorFrac: [Double] = [0.30, 0.72]
        var doorRanges: [(Int, Int)] = []
        let doorW = max(8, Int(14 * scale))
        for f in doorFrac {
            let dx = x1 - Int(Double(x1 - x0) * f) - doorW / 2
            if dx > x0 + 4 && dx + doorW < bodyEnd - 4 {
                doorRanges.append((dx - 2, dx + doorW + 2))
            }
        }

        var wx = x0 + 5
        let winEnd = head ? bodyEnd - 8 : x1 - 5
        while wx + ww < winEnd {
            let overlaps = doorRanges.contains { wx < $0.1 && wx + ww > $0.0 }
            if !overlaps {
                g.rect(wx, winTop, ww, winH2, glass)
                g.rect(wx, winTop, ww, 1, glass.shade(0.3))
                g.rect(wx, winTop + winH2 - 1, ww, 1, glass.shade(-0.35))
            }
            wx += stepW
        }

        for r in doorRanges {
            let dx = r.0 + 2
            let dh = h * 74 / 100
            let dTop = floorY - dh
            g.rect(dx - 2, dTop - 2, doorW + 4, dh + 2, mix(.rgb(0x10151B), .rgb(0x1E242C), dim))
            g.rect(dx, dTop, doorW, dh, .rgb(0x0C1016))
            let open = Int(Double(doorW / 2) * doorAnim)
            let leaf = doorW / 2
            let dcol = mix(spec.doorColor.shade(-0.5), spec.doorColor, dim)
            for side in 0..<2 {
                let lx = side == 0 ? dx - open : dx + leaf + open
                g.rect(lx, dTop, leaf, dh, dcol)
                g.rect(lx, dTop, leaf, 1, dcol.shade(0.28))
                g.rect(lx, dTop + dh - 2, leaf, 2, .rgb(0xE8C93E))
                g.rect(lx + 1, dTop + 3, leaf - 2, dh * 45 / 100, glass)
                g.rect(lx + 1, dTop + 3, leaf - 2, 1, glass.shade(0.3))
            }
        }

        if head {
            let cabW = max(14, Int(30 * scale))
            let cx0 = bodyEnd - cabW
            g.rect(cx0, topY + 4, cabW, h * 36 / 100, mix(.rgb(0x0A1119), spec.glass, dim))
            g.rect(cx0, topY + 4, cabW, 2, mix(.rgb(0x24303E), spec.glass.shade(0.35), dim))
            g.rect(cx0 - 1, topY + 4, 1, h * 36 / 100, roof.shade(-0.25))
            let lx = x1 - max(5, Int(8 * scale))
            let ly = floorY - max(7, Int(10 * scale))
            g.rect(lx, ly, 5, 3, night ? .rgb(0xFFF9D0) : .rgb(0xD8DCE0))
            if night {
                g.rect(lx + 5, ly, 16, 1, .rgb(0xFFF3B0))
                g.rect(lx + 5, ly + 1, 9, 1, .rgb(0xFFE890))
            }
            g.rect(lx, ly + 5, 4, 2, .rgb(0xC02020))
        }

        let ubY = floorY + 1
        for k in 0..<3 {
            let bx = x0 + 12 + k * ((x1 - x0) / 3)
            if bx + 18 < bodyEnd {
                g.rect(bx, ubY, 18, max(2, Int(4 * scale)), mix(.rgb(0x14181C), .rgb(0x30363E), dim))
            }
        }

        for bf in [0.22, 0.78] {
            let bx = x1 - Int(Double(x1 - x0) * bf)
            if bx > bodyEnd - 4 { continue }
            g.rect(bx - 12, floorY + 2, 24, max(3, Int(5 * scale)), skirt.shade(-0.2))
            wheel(g, bx - 6, base, max(2, Int(4 * scale)), wheelPhase)
            wheel(g, bx + 6, base, max(2, Int(4 * scale)), wheelPhase)
        }

        if !head && !tail {
            let px = x0 + (x1 - x0) / 2
            g.rect(px - 9, topY - 2, 18, 2, mix(.rgb(0x2E343A), .rgb(0x5A626A), dim))
            g.line(px - 7, topY - 2, px + 2, topY - 12, .rgb(0x8A9098))
            g.line(px + 2, topY - 12, px + 9, topY - 6, .rgb(0x8A9098))
            g.rect(px + 1, topY - 14, 12, 2, .rgb(0xB6BCC2))
        } else if !head {
            g.rect(x0 + (x1 - x0) / 3, topY - 2, 14, 2, mix(.rgb(0x2E343A), .rgb(0x6E767E), dim))
        }

        g.ctx.restoreGState()
    }

    private static func wheel(_ g: Pix, _ cx: Int, _ base: Int, _ r: Int, _ phase: Double) {
        let cy = base - r
        g.circle(cx, cy, r, .rgb(0x24282E))
        if r > 2 {
            g.circle(cx, cy, r - 1, .rgb(0x6E767E))
            let (x1, y1) = g.polar(cx, cy, Double(r - 1), phase * 2.2)
            g.rect(x1, y1, 1, 1, .rgb(0x24282E))
        }
    }
}
