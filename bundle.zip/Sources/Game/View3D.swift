import UIKit

struct V3 {
    var x: Double
    var y: Double
    var z: Double
}

private struct Face {
    var pts: [(Int, Int)]
    var depth: Double
    var color: UIColor
}

enum View3D {

    static func draw(_ g: Pix, _ st: GameState) {
        let w = g.width
        let h = WorldRenderer.winH
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(h)))

        let day = st.dayPhase
        let mix = WorldRenderer.mix
        var top = mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day)
        var bot = mix(.rgb(0x203050), .rgb(0xC6DCEE), day)
        if st.weather >= 1 { top = mix(top, .rgb(0x6E7885), 0.45); bot = mix(bot, .rgb(0x9AA4B0), 0.45) }
        g.gradientV(0, 0, w, h, top, bot, steps: 18)

        let center = st.distance - st.consistLength / 2
        let yaw = st.camYaw
        let pitch = max(0.08, min(1.25, st.camPitch))
        let dist = st.consistLength * 0.62 + 26
        let ex = center - sin(yaw) * dist * cos(pitch)
        let ez = cos(yaw) * dist * cos(pitch)
        let ey = 3.0 + sin(pitch) * dist
        let eye = V3(x: ex, y: ey, z: ez)
        let target = V3(x: center, y: 3.0, z: 0)

        var fx = target.x - eye.x, fy = target.y - eye.y, fz = target.z - eye.z
        let fl = max(0.001, (fx * fx + fy * fy + fz * fz).squareRoot())
        fx /= fl; fy /= fl; fz /= fl
        var rx = fz, ry = 0.0, rz = -fx
        let rl = max(0.001, (rx * rx + rz * rz).squareRoot())
        rx /= rl; ry /= rl; rz /= rl
        let ux = ry * fz - rz * fy
        let uy = rz * fx - rx * fz
        let uz = rx * fy - ry * fx
        let focal = Double(w) * 0.85

        func project(_ p: V3) -> (Double, Double, Double) {
            let vx = p.x - eye.x, vy = p.y - eye.y, vz = p.z - eye.z
            let cx = vx * rx + vy * ry + vz * rz
            let cy = vx * ux + vy * uy + vz * uz
            let cz = vx * fx + vy * fy + vz * fz
            return (cx, cy, cz)
        }

        var faces: [Face] = []

        func quad(_ a: V3, _ b: V3, _ c: V3, _ d: V3, _ color: UIColor) {
            let ps = [project(a), project(b), project(c), project(d)]
            var depth = 0.0
            for p in ps {
                if p.2 < 1.0 { return }
                depth += p.2
            }
            depth /= 4
            var pts: [(Int, Int)] = []
            for p in ps {
                pts.append((Int((Double(w) / 2 + p.0 / p.2 * focal).rounded()),
                            Int((Double(h) * 0.62 - p.1 / p.2 * focal).rounded())))
            }
            faces.append(Face(pts: pts, depth: depth, color: color))
        }

        func box(_ cx: Double, _ y0: Double, _ y1: Double, _ len: Double, _ halfW: Double,
                 top c1: UIColor, side c2: UIColor, end c3: UIColor) {
            let a = cx - len / 2, b = cx + len / 2
            quad(V3(x: a, y: y1, z: -halfW), V3(x: b, y: y1, z: -halfW),
                 V3(x: b, y: y1, z: halfW), V3(x: a, y: y1, z: halfW), c1)
            quad(V3(x: a, y: y0, z: halfW), V3(x: b, y: y0, z: halfW),
                 V3(x: b, y: y1, z: halfW), V3(x: a, y: y1, z: halfW), c2)
            quad(V3(x: a, y: y0, z: -halfW), V3(x: b, y: y0, z: -halfW),
                 V3(x: b, y: y1, z: -halfW), V3(x: a, y: y1, z: -halfW), c2.shade(-0.18))
            quad(V3(x: b, y: y0, z: -halfW), V3(x: b, y: y0, z: halfW),
                 V3(x: b, y: y1, z: halfW), V3(x: b, y: y1, z: -halfW), c3)
            quad(V3(x: a, y: y0, z: -halfW), V3(x: a, y: y0, z: halfW),
                 V3(x: a, y: y1, z: halfW), V3(x: a, y: y1, z: -halfW), c3.shade(-0.1))
        }

        let grass = mix(.rgb(0x1E3020), .rgb(0x5C8442), day)
        let ballast = mix(.rgb(0x2A2A2E), .rgb(0x8A8377), day)
        quad(V3(x: center - 320, y: 0, z: -140), V3(x: center + 320, y: 0, z: -140),
             V3(x: center + 320, y: 0, z: 140), V3(x: center - 320, y: 0, z: 140), grass)
        quad(V3(x: center - 320, y: 0.16, z: -4.2), V3(x: center + 320, y: 0.16, z: -4.2),
             V3(x: center + 320, y: 0.16, z: 4.2), V3(x: center - 320, y: 0.16, z: 4.2), ballast)

        let railC = mix(.rgb(0x555C64), .rgb(0xB9BEC4), day)
        for zz in [-0.72, 0.72] {
            quad(V3(x: center - 300, y: 0.3, z: zz - 0.09), V3(x: center + 300, y: 0.3, z: zz - 0.09),
                 V3(x: center + 300, y: 0.3, z: zz + 0.09), V3(x: center - 300, y: 0.3, z: zz + 0.09), railC)
        }
        let sleep = mix(.rgb(0x1E1A16), .rgb(0x5A4A38), day)
        var sp = (center / 3).rounded() * 3 - 90
        while sp < center + 90 {
            quad(V3(x: sp - 0.6, y: 0.2, z: -1.4), V3(x: sp + 0.6, y: 0.2, z: -1.4),
                 V3(x: sp + 0.6, y: 0.2, z: 1.4), V3(x: sp - 0.6, y: 0.2, z: 1.4), sleep)
            sp += 3
        }

        for s in World.stations {
            if abs(s.pos - center) > 260 { continue }
            let mid = s.platformStart + s.platformLen / 2
            let side: Double = s.side == .right ? 1 : -1
            box(mid, 0, 1.1, s.platformLen, 0.1,
                top: mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day),
                side: mix(.rgb(0x303034), .rgb(0x9A948A), day),
                end: mix(.rgb(0x2A2A2E), .rgb(0x8A857C), day))
            let a = mid - s.platformLen / 2, b = mid + s.platformLen / 2
            quad(V3(x: a, y: 1.1, z: side * 2.1), V3(x: b, y: 1.1, z: side * 2.1),
                 V3(x: b, y: 1.1, z: side * 8.5), V3(x: a, y: 1.1, z: side * 8.5),
                 mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day))
            quad(V3(x: a, y: 0, z: side * 2.1), V3(x: b, y: 0, z: side * 2.1),
                 V3(x: b, y: 1.1, z: side * 2.1), V3(x: a, y: 1.1, z: side * 2.1),
                 mix(.rgb(0x2E2E32), .rgb(0x8E887E), day))
            quad(V3(x: a, y: 5.4, z: side * 2.4), V3(x: b, y: 5.4, z: side * 2.4),
                 V3(x: b, y: 5.4, z: side * 8.2), V3(x: a, y: 5.4, z: side * 8.2),
                 mix(.rgb(0x14283A), .rgb(0x2E5F86), day))
        }

        var px = (center / 42).rounded() * 42 - 84
        while px < center + 84 {
            box(px, 0, 8.6, 0.35, 0.35,
                top: mix(.rgb(0x3A4048), .rgb(0x9AA0A8), day),
                side: mix(.rgb(0x3A4048), .rgb(0x8A9098), day),
                end: mix(.rgb(0x30363C), .rgb(0x7E848C), day))
            px += 42
        }

        for t in st.traffic where t.active {
            if abs(t.pos - center) > 320 { continue }
            drawTrain3D(TrainSpec.by(t.specId), cars: t.cars, front: t.pos, day: day,
                        cabin: true, lateral: t.sameTrack ? 0 : -9, quad: quad)
        }
        drawTrain3D(st.spec, cars: st.cars, front: st.distance, day: day,
                    cabin: st.cabinLight, lateral: 0, quad: quad)

        faces.sort { $0.depth > $1.depth }
        for f in faces {
            g.poly(f.pts, f.color)
        }

        g.ctx.restoreGState()
        g.rect(0, h - 2, w, 2, .rgb(0x10141A))
    }

    private static func drawTrain3D(_ spec: TrainSpec, cars: Int, front: Double, day: Double,
                                    cabin: Bool, lateral: Double,
                                    quad: (V3, V3, V3, V3, UIColor) -> Void) {
        func solid(_ cx: Double, _ y0: Double, _ y1: Double, _ len: Double, _ halfW: Double,
                   _ c1: UIColor, _ c2: UIColor, _ c3: UIColor) {
            let a = cx - len / 2, b = cx + len / 2
            let zn = lateral - halfW, zp = lateral + halfW
            quad(V3(x: a, y: y1, z: zn), V3(x: b, y: y1, z: zn),
                 V3(x: b, y: y1, z: zp), V3(x: a, y: y1, z: zp), c1)
            quad(V3(x: a, y: y0, z: zp), V3(x: b, y: y0, z: zp),
                 V3(x: b, y: y1, z: zp), V3(x: a, y: y1, z: zp), c2)
            quad(V3(x: a, y: y0, z: zn), V3(x: b, y: y0, z: zn),
                 V3(x: b, y: y1, z: zn), V3(x: a, y: y1, z: zn), c2.shade(-0.18))
            quad(V3(x: b, y: y0, z: zn), V3(x: b, y: y0, z: zp),
                 V3(x: b, y: y1, z: zp), V3(x: b, y: y1, z: zn), c3)
            quad(V3(x: a, y: y0, z: zn), V3(x: a, y: y0, z: zp),
                 V3(x: a, y: y1, z: zp), V3(x: a, y: y1, z: zn), c3.shade(-0.1))
        }
        let mix = WorldRenderer.mix
        let dim = max(0.42, day)
        let body = mix(spec.body.shade(-0.55), spec.body, dim)
        let roof = mix(spec.roof.shade(-0.55), spec.roof, dim)
        let main = mix(spec.liveryMain.shade(-0.5), spec.liveryMain, dim)
        let glass: UIColor = cabin ? .rgb(0xF2DC9C) : mix(spec.glass.shade(-0.3), spec.glass, dim)
        let hw = 1.6
        let y0 = 1.1
        let y1 = 1.1 + spec.carHeightM

        for c in 0..<cars {
            let cx = front - Double(c) * (spec.carLengthM + 0.6) - spec.carLengthM / 2
            solid(cx, y0, y1, spec.carLengthM - 0.4, hw, roof, body, c == 0 ? main : body.shade(-0.12))
            let a = cx - spec.carLengthM / 2 + 1.2
            let b = cx + spec.carLengthM / 2 - 1.2
            let wy0 = y0 + spec.carHeightM * 0.42
            let wy1 = y0 + spec.carHeightM * 0.72
            for sgn in [-1.0, 1.0] {
                let z = lateral + sgn * (hw + 0.02)
                quad(V3(x: a, y: wy0, z: z), V3(x: b, y: wy0, z: z),
                     V3(x: b, y: wy1, z: z), V3(x: a, y: wy1, z: z), glass)
                let sy0 = y0 + 0.1
                let sy1 = y0 + spec.carHeightM * 0.30
                quad(V3(x: a - 0.8, y: sy0, z: z), V3(x: b + 0.8, y: sy0, z: z),
                     V3(x: b + 0.8, y: sy1, z: z), V3(x: a - 0.8, y: sy1, z: z), main)
            }
            solid(cx, 0.35, 1.05, spec.carLengthM * 0.62, hw - 0.35,
                  mix(.rgb(0x22262C), .rgb(0x3A414A), dim),
                  mix(.rgb(0x1E2228), .rgb(0x333A42), dim),
                  mix(.rgb(0x1A1E24), .rgb(0x2E353D), dim))
        }
    }
}
