import UIKit

struct V3 {
    var x: Double
    var y: Double
    var z: Double
}

private struct Face {
    var pts: [(Int, Int)]
    var depth: Double
    var color: UIColor
}

enum View3D {

    static func draw(_ g: Pix, _ st: GameState) {
        let w = g.width
        let h = WorldRenderer.winH
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(h)))

        let day = st.dayPhase
        let mix = WorldRenderer.mix
        var top = mix(.rgb(0x0A1024), .rgb(0x3E7CC0), day)
        var bot = mix(.rgb(0x24303E), .rgb(0xBFD4E6), day)
        if st.weather >= 1 { top = mix(top, .rgb(0x6E7885), 0.4); bot = mix(bot, .rgb(0x9AA4B0), 0.4) }
        g.gradientV(0, 0, w, h * 6 / 10, top, bot, steps: 16)
        let groundBase = mix(.rgb(0x18281A), .rgb(0x527A3E), day)
        g.rect(0, h * 6 / 10, w, h - h * 6 / 10, groundBase)

        // ---- camera: orbit the geometric centre of the consist ----
        let center = st.distance - st.consistLength / 2
        let yaw = st.camYaw
        let pitch = max(0.12, min(1.15, st.camPitch))
        let radius = st.consistLength * 0.75 + 34
        let eye = V3(x: center - sin(yaw) * radius * cos(pitch),
                     y: sin(pitch) * radius + 4,
                     z: cos(yaw) * radius * cos(pitch))
        let target = V3(x: center, y: 3.2, z: 0)

        var fx = target.x - eye.x, fy = target.y - eye.y, fz = target.z - eye.z
        let fl = max(1e-6, (fx * fx + fy * fy + fz * fz).squareRoot())
        fx /= fl; fy /= fl; fz /= fl
        // right = normalize(cross(worldUp, forward))
        var rx = fz, rz = -fx
        let rl = max(1e-6, (rx * rx + rz * rz).squareRoot())
        rx /= rl; rz /= rl
        let ry = 0.0
        // up = cross(forward, right)
        let ux = fy * rz - fz * ry
        let uy = fz * rx - fx * rz
        let uz = fx * ry - fy * rx
        let focal = Double(w) * 0.9
        let cxp = Double(w) / 2
        let cyp = Double(h) * 0.60

        var faces: [Face] = []

        func quad(_ a: V3, _ b: V3, _ c: V3, _ d: V3, _ color: UIColor) {
            let corners = [a, b, c, d]
            var scr: [(Int, Int)] = []
            var depth = 0.0
            for p in corners {
                let vx = p.x - eye.x, vy = p.y - eye.y, vz = p.z - eye.z
                let cz = vx * fx + vy * fy + vz * fz
                if cz < 0.8 { return }
                let sxv = vx * rx + vy * ry + vz * rz
                let syv = vx * ux + vy * uy + vz * uz
                scr.append((Int((cxp + sxv / cz * focal).rounded()),
                            Int((cyp - syv / cz * focal).rounded())))
                depth += cz
            }
            faces.append(Face(pts: scr, depth: depth / 4, color: color))
        }

        func box(_ cx: Double, _ z0: Double, _ y0: Double, _ y1: Double,
                 _ len: Double, _ halfW: Double,
                 _ cTop: UIColor, _ cSide: UIColor, _ cEnd: UIColor) {
            let a = cx - len / 2, b = cx + len / 2
            let zn = z0 - halfW, zp = z0 + halfW
            quad(V3(x: a, y: y1, z: zn), V3(x: b, y: y1, z: zn),
                 V3(x: b, y: y1, z: zp), V3(x: a, y: y1, z: zp), cTop)
            quad(V3(x: a, y: y0, z: zp), V3(x: b, y: y0, z: zp),
                 V3(x: b, y: y1, z: zp), V3(x: a, y: y1, z: zp), cSide)
            quad(V3(x: a, y: y0, z: zn), V3(x: b, y: y0, z: zn),
                 V3(x: b, y: y1, z: zn), V3(x: a, y: y1, z: zn), cSide.shade(-0.18))
            quad(V3(x: b, y: y0, z: zn), V3(x: b, y: y0, z: zp),
                 V3(x: b, y: y1, z: zp), V3(x: b, y: y1, z: zn), cEnd)
            quad(V3(x: a, y: y0, z: zn), V3(x: a, y: y0, z: zp),
                 V3(x: a, y: y1, z: zp), V3(x: a, y: y1, z: zn), cEnd.shade(-0.1))
        }

        // ground strips
        let grass = mix(.rgb(0x1E3020), .rgb(0x5C8442), day)
        let ballast = mix(.rgb(0x2A2A2E), .rgb(0x8A8377), day)
        quad(V3(x: center - 340, y: 0, z: -160), V3(x: center + 340, y: 0, z: -160),
             V3(x: center + 340, y: 0, z: 160), V3(x: center - 340, y: 0, z: 160), grass)
        quad(V3(x: center - 340, y: 0.15, z: -4.4), V3(x: center + 340, y: 0.15, z: -4.4),
             V3(x: center + 340, y: 0.15, z: 4.4), V3(x: center - 340, y: 0.15, z: 4.4), ballast)

        // rails + sleepers
        let railC = mix(.rgb(0x555C64), .rgb(0xB9BEC4), day)
        for zz in [-0.75, 0.75] {
            quad(V3(x: center - 320, y: 0.3, z: zz - 0.1), V3(x: center + 320, y: 0.3, z: zz - 0.1),
                 V3(x: center + 320, y: 0.3, z: zz + 0.1), V3(x: center - 320, y: 0.3, z: zz + 0.1), railC)
        }
        let sleep = mix(.rgb(0x1E1A16), .rgb(0x5A4A38), day)
        var sp = (center / 3).rounded() * 3 - 96
        while sp < center + 96 {
            quad(V3(x: sp - 0.7, y: 0.18, z: -1.5), V3(x: sp + 0.7, y: 0.18, z: -1.5),
                 V3(x: sp + 0.7, y: 0.18, z: 1.5), V3(x: sp - 0.7, y: 0.18, z: 1.5), sleep)
            sp += 3
        }

        // platforms near the camera
        for s in World.stations {
            if abs(s.pos - center) > 280 { continue }
            let mid = s.platformStart + s.platformLen / 2
            let side: Double = s.side == .right ? 1 : -1
            let a = mid - s.platformLen / 2, b = mid + s.platformLen / 2
            box(mid, side * 5.3, 0, 1.15, s.platformLen, 3.0,
                mix(.rgb(0x3A3A3E), .rgb(0xB4AEA4), day),
                mix(.rgb(0x303034), .rgb(0x9A948A), day),
                mix(.rgb(0x2A2A2E), .rgb(0x8A857C), day))
            // stop marker
            quad(V3(x: s.pos, y: 1.15, z: side * 2.4), V3(x: s.pos + 0.4, y: 1.15, z: side * 2.4),
                 V3(x: s.pos + 0.4, y: 3.2, z: side * 2.4), V3(x: s.pos, y: 3.2, z: side * 2.4),
                 .rgb(0xC02020))
        }

        // catenary poles
        var px = (center / 42).rounded() * 42 - 84
        while px < center + 84 {
            box(px, -2.5, 0, 8.6, 0.4, 0.4,
                mix(.rgb(0x3A4048), .rgb(0x9AA0A8), day),
                mix(.rgb(0x3A4048), .rgb(0x8A9098), day),
                mix(.rgb(0x30363C), .rgb(0x7E848C), day))
            px += 42
        }

        // oncoming trains on far track first, then our train
        for t in st.traffic where t.active {
            if abs(t.pos - center) > 340 { continue }
            let lateral: Double = t.sameTrack ? 0 : -9
            drawTrain(TrainSpec.by(t.specId), cars: t.cars, front: t.pos, day: day,
                      cabin: true, lateral: lateral, box: box, quad: quad)
        }
        drawTrain(st.spec, cars: st.cars, front: st.distance, day: day,
                  cabin: st.cabinLight, lateral: 0, box: box, quad: quad)

        faces.sort { $0.depth > $1.depth }
        for f in faces { g.poly(f.pts, f.color) }

        g.ctx.restoreGState()
        g.rect(0, h - 2, w, 2, .rgb(0x10141A))
    }

    private static func drawTrain(_ spec: TrainSpec, cars: Int, front: Double, day: Double,
                                  cabin: Bool, lateral: Double,
                                  box: (Double, Double, Double, Double, Double, Double, UIColor, UIColor, UIColor) -> Void,
                                  quad: (V3, V3, V3, V3, UIColor) -> Void) {
        let mix = WorldRenderer.mix
        let dim = max(0.42, day)
        let body = mix(spec.body.shade(-0.55), spec.body, dim)
        let roof = mix(spec.roof.shade(-0.55), spec.roof, dim)
        let main = mix(spec.liveryMain.shade(-0.5), spec.liveryMain, dim)
        let glass: UIColor = cabin ? .rgb(0xF2DC9C) : mix(spec.glass.shade(-0.3), spec.glass, dim)
        let hw = 1.55
        let y0 = 1.15
        let y1 = 1.15 + spec.carHeightM

        for c in 0..<cars {
            let cx = front - Double(c) * (spec.carLengthM + 0.6) - spec.carLengthM / 2
            box(cx, lateral, y0, y1, spec.carLengthM - 0.4, hw,
                roof, body, c == 0 ? main : body.shade(-0.1))
            let a = cx - spec.carLengthM / 2 + 1.4
            let b = cx + spec.carLengthM / 2 - 1.4
            let wy0 = y0 + spec.carHeightM * 0.42
            let wy1 = y0 + spec.carHeightM * 0.70
            for sgn in [-1.0, 1.0] {
                let z = lateral + sgn * (hw + 0.03)
                quad(V3(x: a, y: wy0, z: z), V3(x: b, y: wy0, z: z),
                     V3(x: b, y: wy1, z: z), V3(x: a, y: wy1, z: z), glass)
                let sy0 = y0 + 0.15
                let sy1 = y0 + spec.carHeightM * 0.30
                quad(V3(x: a - 1.0, y: sy0, z: z), V3(x: b + 1.0, y: sy0, z: z),
                     V3(x: b + 1.0, y: sy1, z: z), V3(x: a - 1.0, y: sy1, z: z), main)
            }
            // bogies
            box(cx, lateral, 0.35, 1.1, spec.carLengthM * 0.6, hw - 0.3,
                mix(.rgb(0x22262C), .rgb(0x3A414A), dim),
                mix(.rgb(0x1E2228), .rgb(0x333A42), dim),
                mix(.rgb(0x1A1E24), .rgb(0x2E353D), dim))
        }
    }
}
