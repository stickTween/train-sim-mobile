import UIKit

final class GameCanvasView: UIView {

    private let state: GameState
    private var buffer: PixelBuffer?
    private var layout: PanelLayout
    private var link: CADisplayLink?
    private var lastTime: CFTimeInterval = 0
    private static let canvasH = 270
    private static let baseW = 480
    private var canvasW = GameCanvasView.baseW
    private var pressedId: String?
    private var draggingLever = false

    init(spec: TrainSpec, lang: Lang) {
        state = GameState(spec: spec, lang: lang)
        layout = PanelLayout(w: GameCanvasView.baseW, h: GameCanvasView.canvasH)
        super.init(frame: .zero)
        backgroundColor = .black
        isOpaque = true
        isMultipleTouchEnabled = true
        layer.magnificationFilter = .nearest
        layer.minificationFilter = .nearest
        layer.contentsGravity = .resizeAspect
        layer.isOpaque = true
    }

    required init?(coder: NSCoder) { fatalError() }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil {
            if link == nil {
                let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
                l.add(to: .main, forMode: .common)
                link = l
            }
        } else {
            link?.invalidate()
            link = nil
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.width > 0, bounds.height > 0 else { return }
        let aspect = bounds.width / bounds.height
        var wpx = Int((CGFloat(GameCanvasView.canvasH) * aspect).rounded())
        wpx = max(440, min(680, wpx))
        if wpx % 2 == 1 { wpx += 1 }
        if wpx != canvasW || buffer == nil {
            canvasW = wpx
            buffer = PixelBuffer(width: canvasW, height: GameCanvasView.canvasH)
            layout = PanelLayout(w: canvasW, h: GameCanvasView.canvasH)
        }
    }

    @objc private func tick(_ link: CADisplayLink) {
        let now = link.timestamp
        if lastTime == 0 { lastTime = now }
        let dt = min(0.05, now - lastTime)
        lastTime = now
        state.update(dt)
        render()
    }

    private func render() {
        guard let buf = buffer else { return }
        buf.begin()
        let g = Pix(ctx: buf.ctx, width: buf.width, height: buf.height)
        g.fill(.rgb(0x0A0C10))
        let flipped = state.currentStation?.side == .left
        WorldRenderer.draw(g, state, flipped: flipped)
        PanelRenderer.draw(g, state, layout, pressed: pressedId)
        PanelRenderer.overlay(g, state)
        if let img = buf.end() {
            layer.contents = img
        }
    }

    private func canvasPoint(_ p: CGPoint) -> (Int, Int)? {
        guard bounds.width > 0, bounds.height > 0 else { return nil }
        let scale = min(bounds.width / CGFloat(canvasW), bounds.height / CGFloat(GameCanvasView.canvasH))
        guard scale > 0 else { return nil }
        let dw = CGFloat(canvasW) * scale
        let dh = CGFloat(GameCanvasView.canvasH) * scale
        let ox = (bounds.width - dw) / 2
        let oy = (bounds.height - dh) / 2
        return (Int(((p.x - ox) / scale).rounded(.down)), Int(((p.y - oy) / scale).rounded(.down)))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            guard let (x, y) = canvasPoint(t.location(in: self)) else { continue }
            if layout.hitLever(x, y) {
                draggingLever = true
                state.controller = snap(layout.leverValue(y))
                continue
            }
            if layout.hitEmergency(x, y) {
                pressedId = "emergency"
                state.emergency.toggle()
                if state.emergency {
                    state.controller = -1
                    state.setMessage(Loc.s("emergencyOn", state.lang), 2.4)
                } else {
                    state.setMessage(Loc.s("emergencyOff", state.lang), 1.8)
                }
                continue
            }
            for b in layout.buttons(state.lang) where b.contains(x, y) {
                pressedId = b.id
                act(b.id)
            }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard draggingLever else { return }
        for t in touches {
            guard let (_, y) = canvasPoint(t.location(in: self)) else { continue }
            state.controller = snap(layout.leverValue(y))
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        draggingLever = false
        pressedId = nil
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        draggingLever = false
        pressedId = nil
    }

    private func snap(_ v: Double) -> Double {
        let s = (v * 8).rounded() / 8
        return abs(s) < 0.06 ? 0 : s
    }

    private func act(_ id: String) {
        switch id {
        case "doorsLeft": state.pressDoors(.left)
        case "doorsRight": state.pressDoors(.right)
        case "closeDoors": state.closeDoors()
        case "autostop":
            state.autoStop.toggle()
            state.setMessage(Loc.s(state.autoStop ? "autoOn" : "autoOff", state.lang), 1.8)
        case "headlights":
            state.headlights.toggle()
        case "cabin":
            state.cabinLight.toggle()
        case "sand":
            state.sand.toggle()
            state.setMessage(Loc.s(state.sand ? "sandOn" : "sandOff", state.lang), 1.6)
        case "horn":
            state.horn = 0.7
            state.setMessage(Loc.s("hornMsg", state.lang), 1.2)
        case "announce":
            if let s = state.currentStation {
                state.setMessage(String(format: Loc.s("annMsg", state.lang), s.name(state.lang)), 3.0)
            }
        case "als":
            state.setMessage(String(format: Loc.s("alsMsg", state.lang), Int(state.speedLimit)), 2.2)
        case "reset":
            state.emergency = false
            state.setMessage(Loc.s("resetMsg", state.lang), 1.6)
        default: break
        }
    }
}
