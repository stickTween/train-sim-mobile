import UIKit

final class GameCanvasView: UIView {

    let state: GameState
    var onExit: (() -> Void)?

    private let audio = AudioEngine()
    private var buffer: PixelBuffer?
    private var layout: PanelLayout
    private var link: CADisplayLink?
    private var lastTime: CFTimeInterval = 0
    private static let canvasH = 270
    private static let baseW = 480
    private var canvasW = GameCanvasView.baseW
    private var pressedId: String?
    private var draggingLever = false
    private var draggingCam = false
    private var camAnchor: CGFloat = 0
    private var camStart: Double = 0
    private var holdTimer: Timer?
    private var holdCandidate: String?

    init(spec: TrainSpec, route: RouteDef, lang: Lang) {
        state = GameState(spec: spec, route: route, lang: lang)
        layout = PanelLayout(w: GameCanvasView.baseW, h: GameCanvasView.canvasH)
        super.init(frame: .zero)
        backgroundColor = .black
        isOpaque = true
        isMultipleTouchEnabled = true
        layer.magnificationFilter = .nearest
        layer.minificationFilter = .nearest
        layer.contentsGravity = .resizeAspect
        layer.isOpaque = true
    }

    required init?(coder: NSCoder) { fatalError() }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil {
            if link == nil {
                let l = CADisplayLink(target: self, selector: #selector(tick(_:)))
                l.add(to: .main, forMode: .common)
                link = l
            }
            audio.start()
        } else {
            link?.invalidate()
            link = nil
            audio.stop()
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds.width > 0, bounds.height > 0 else { return }
        var wpx = Int((CGFloat(GameCanvasView.canvasH) * bounds.width / bounds.height).rounded())
        wpx = max(440, min(680, wpx))
        if wpx % 2 == 1 { wpx += 1 }
        if wpx != canvasW || buffer == nil {
            canvasW = wpx
            buffer = PixelBuffer(width: canvasW, height: GameCanvasView.canvasH)
            layout = PanelLayout(w: canvasW, h: GameCanvasView.canvasH)
        }
    }

    @objc private func tick(_ link: CADisplayLink) {
        let now = link.timestamp
        if lastTime == 0 { lastTime = now }
        let dt = min(0.05, now - lastTime)
        lastTime = now
        state.update(dt)
        pumpAudio()
        render()
    }

    private func pumpAudio() {
        audio.speed = state.speed
        audio.tractionLevel = max(0, state.controller)
        audio.brakeLevel = max(0, -state.controller)
        audio.master = (state.paused || state.phase == .finished) ? 0.15 : 1.0
        if state.pendingClack { state.pendingClack = false; audio.clack() }
        if state.pendingHiss { state.pendingHiss = false; audio.hiss() }
        if state.pendingChime { state.pendingChime = false; audio.chime() }
        if state.pendingDoor { state.pendingDoor = false; audio.doorMotor() }
        if state.horn > 0.65 { audio.horn() }
    }

    private func render() {
        guard let buf = buffer else { return }
        buf.begin()
        let g = Pix(ctx: buf.ctx, width: buf.width, height: buf.height)
        g.fill(.rgb(0x080A0E))
        WorldRenderer.draw(g, state)
        PanelRenderer.draw(g, state, layout, pressed: pressedId)
        if let id = state.tooltipID { OverlayRenderer.tooltip(g, state, layout, id) }
        if state.phase == .crashed { OverlayRenderer.crash(g, state) }
        if state.phase == .finished { OverlayRenderer.finish(g, state) }
        else if state.paused { OverlayRenderer.pauseMenu(g, state) }
        else if state.countdown > 0 { OverlayRenderer.countdown(g, state) }
        if let img = buf.end() { layer.contents = img }
    }

    private func canvasPoint(_ p: CGPoint) -> (Int, Int)? {
        guard bounds.width > 0, bounds.height > 0 else { return nil }
        let scale = min(bounds.width / CGFloat(canvasW), bounds.height / CGFloat(GameCanvasView.canvasH))
        guard scale > 0 else { return nil }
        let ox = (bounds.width - CGFloat(canvasW) * scale) / 2
        let oy = (bounds.height - CGFloat(GameCanvasView.canvasH) * scale) / 2
        return (Int(((p.x - ox) / scale).rounded(.down)), Int(((p.y - oy) / scale).rounded(.down)))
    }

    private func canvasScale() -> CGFloat {
        max(0.001, min(bounds.width / CGFloat(canvasW), bounds.height / CGFloat(GameCanvasView.canvasH)))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let loc = t.location(in: self)
            guard let (x, y) = canvasPoint(loc) else { continue }

            if let id = state.tooltipID {
                if let r = OverlayRenderer.tipRect(canvasW, state, layout, id) {
                    let c = OverlayRenderer.tipCloseRect(r)
                    if OverlayRects.hit(c, x, y) || !OverlayRects.hit(r, x, y) {
                        state.tooltipID = nil
                    }
                } else {
                    state.tooltipID = nil
                }
                continue
            }

            if state.phase == .finished {
                if OverlayRects.hit(OverlayRects.make(canvasW, GameCanvasView.canvasH).exit, x, y) { onExit?() }
                continue
            }
            if state.paused {
                let r = OverlayRects.make(canvasW, GameCanvasView.canvasH)
                if OverlayRects.hit(r.resume, x, y) {
                    state.paused = false
                    state.countdown = 3.0
                } else if OverlayRects.hit(r.exit, x, y) {
                    onExit?()
                }
                continue
            }
            if state.countdown > 0 { continue }

            if layout.hitPause(x, y) {
                state.paused = true
                continue
            }
            if y < WorldRenderer.winH {
                draggingCam = true
                state.camDragging = true
                camAnchor = loc.x
                camStart = state.camOffset
                continue
            }
            if layout.hitLever(x, y) {
                draggingLever = true
                state.controller = snap(layout.leverValue(y))
                continue
            }
            if layout.hitEmergency(x, y) {
                pressedId = "emergency"
                state.emergency.toggle()
                state.toast(Loc.s(state.emergency ? "eEmergency" : "mEmergencyOff", state.lang),
                            bad: state.emergency, seconds: 2.4)
                continue
            }
            for b in layout.buttons(state.lang) where b.contains(x, y) {
                pressedId = b.id
                startHold(b.id)
                act(b.id)
            }
        }
    }

    private func startHold(_ id: String) {
        holdCandidate = id
        holdTimer?.invalidate()
        holdTimer = Timer.scheduledTimer(withTimeInterval: 0.55, repeats: false) { [weak self] _ in
            guard let self = self, self.holdCandidate == id else { return }
            self.state.tooltipID = id
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !state.paused, state.countdown <= 0 else { return }
        for t in touches {
            let loc = t.location(in: self)
            if draggingCam {
                let dx = (loc.x - camAnchor) / canvasScale()
                var v = camStart - Double(dx) / WorldRenderer.ppm
                let back = -(state.consistLength + 40)
                v = max(back, min(70, v))
                state.camOffset = v
                if abs(dx) > 6 { holdTimer?.invalidate(); holdCandidate = nil }
            } else if draggingLever {
                if let (_, y) = canvasPoint(loc) {
                    state.controller = snap(layout.leverValue(y))
                }
                holdTimer?.invalidate()
                holdCandidate = nil
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        endTouch()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        endTouch()
    }

    private func endTouch() {
        draggingLever = false
        draggingCam = false
        state.camDragging = false
        pressedId = nil
        holdTimer?.invalidate()
        holdTimer = nil
        holdCandidate = nil
    }

    private func snap(_ v: Double) -> Double {
        let s = (v * 8).rounded() / 8
        return abs(s) < 0.06 ? 0 : s
    }

    private func act(_ id: String) {
        switch id {
        case "doorsLeft": state.pressDoors(.left)
        case "doorsRight": state.pressDoors(.right)
        case "closeDoors": state.closeDoors()
        case "autostop":
            state.autoStop.toggle()
            state.toast(Loc.s(state.autoStop ? "mAutoOn" : "mAutoOff", state.lang), bad: false, seconds: 1.8)
        case "headlights":
            state.headlights.toggle()
            state.toast(Loc.s(state.headlights ? "mLampOn" : "mLampOff", state.lang), bad: false, seconds: 1.6)
        case "cabin":
            state.cabinLight.toggle()
            state.toast(Loc.s(state.cabinLight ? "mCabinOn" : "mCabinOff", state.lang), bad: false, seconds: 1.6)
        case "sand":
            state.sand.toggle()
            state.toast(Loc.s(state.sand ? "mSandOn" : "mSandOff", state.lang), bad: false, seconds: 1.6)
        case "horn":
            state.horn = 0.7
            audio.horn()
        case "announce":
            if let s = state.currentStop {
                state.toast(String(format: Loc.s("mAnnounce", state.lang), s.name(state.lang)), bad: false, seconds: 2.6)
                audio.chime()
            } else {
                state.toast(Loc.s("eNoStop", state.lang))
            }
        case "als":
            state.toast(String(format: Loc.s("mAls", state.lang), Int(state.speedLimit)), bad: false, seconds: 2.0)
        case "cam":
            state.camOffset = abs(state.camOffset) > 1 ? 0 : -(state.consistLength * 0.6)
        default: break
        }
    }
}
