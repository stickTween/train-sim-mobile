import UIKit
import SceneKit

extension UIColor {
    static func hex(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 255) / 255,
                green: CGFloat((v >> 8) & 255) / 255,
                blue: CGFloat(v & 255) / 255, alpha: 1)
    }
}

enum Mat {
    static func pbr(_ color: UIColor, metal: CGFloat = 0.0, rough: CGFloat = 0.6, both: Bool = false) -> SCNMaterial {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = color
        m.metalness.contents = metal
        m.roughness.contents = rough
        m.isDoubleSided = both
        return m
    }

    static func glass() -> SCNMaterial {
        pbr(.hex(0x0B1016), metal: 0.9, rough: 0.05)
    }

    static func glow(_ color: UIColor) -> SCNMaterial {
        let m = pbr(color, rough: 0.3)
        m.emission.contents = color
        return m
    }

    static func box(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ color: UIColor,
                    chamfer: CGFloat = 0.02, metal: CGFloat = 0, rough: CGFloat = 0.6, both: Bool = false) -> SCNNode {
        let g = SCNBox(width: w, height: h, length: l, chamferRadius: chamfer)
        g.firstMaterial = pbr(color, metal: metal, rough: rough, both: both)
        return SCNNode(geometry: g)
    }

    static func textImage(_ text: String, size: CGSize, bg: UIColor, fg: UIColor, font: CGFloat) -> UIImage {
        UIGraphicsImageRenderer(size: size).image { ctx in
            bg.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            let p = NSMutableParagraphStyle()
            p.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: font, weight: .bold),
                .foregroundColor: fg,
                .paragraphStyle: p
            ]
            let s = NSString(string: text)
            let r = s.boundingRect(with: CGSize(width: size.width - 12, height: size.height),
                                   options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
            s.draw(with: CGRect(x: 6, y: max(0, (size.height - r.height) / 2), width: size.width - 12, height: r.height),
                   options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
        }
    }

    static func label(_ t: String, w: CGFloat, h: CGFloat, bg: UIColor, fg: UIColor, font: CGFloat, both: Bool = true) -> SCNNode {
        let plane = SCNPlane(width: w, height: h)
        let m = SCNMaterial()
        m.lightingModel = .lambert
        m.diffuse.contents = textImage(t, size: CGSize(width: 512, height: 512 * h / w), bg: bg, fg: fg, font: font)
        m.isDoubleSided = both
        plane.firstMaterial = m
        return SCNNode(geometry: plane)
    }

    static func dial(_ maxSpeed: Int) -> UIImage {
        let size = CGSize(width: 512, height: 512)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x0E1218).setFill()
            c.fillEllipse(in: CGRect(x: 4, y: 4, width: 504, height: 504))
            UIColor.hex(0x2C3644).setStroke()
            c.setLineWidth(10)
            c.strokeEllipse(in: CGRect(x: 10, y: 10, width: 492, height: 492))
            let center = CGPoint(x: 256, y: 256)
            for i in 0...10 {
                let deg = -120.0 + 240.0 * Double(i) / 10.0
                let a = CGFloat(deg) * .pi / 180
                let outer = CGPoint(x: center.x + 212 * sin(a), y: center.y - 212 * cos(a))
                let inner = CGPoint(x: center.x + 176 * sin(a), y: center.y - 176 * cos(a))
                (i >= 8 ? UIColor.hex(0xE04141) : UIColor.hex(0xD8E4F0)).setStroke()
                c.setLineWidth(8)
                c.move(to: inner); c.addLine(to: outer); c.strokePath()
                let val = maxSpeed * i / 10
                let s = NSString(string: "\(val)")
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 34, weight: .bold),
                    .foregroundColor: UIColor.hex(0xD8E4F0)
                ]
                let tp = CGPoint(x: center.x + 140 * sin(a), y: center.y - 140 * cos(a))
                let sz = s.size(withAttributes: attrs)
                s.draw(at: CGPoint(x: tp.x - sz.width / 2, y: tp.y - sz.height / 2), withAttributes: attrs)
            }
            let t = NSString(string: "km/h")
            let a2: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 30, weight: .semibold),
                .foregroundColor: UIColor.hex(0x7C8DA0)
            ]
            let sz2 = t.size(withAttributes: a2)
            t.draw(at: CGPoint(x: 256 - sz2.width / 2, y: 330), withAttributes: a2)
        }
    }
}
