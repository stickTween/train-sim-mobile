import UIKit
import SceneKit

extension UIColor {
    static func hex(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 255) / 255,
                green: CGFloat((v >> 8) & 255) / 255,
                blue: CGFloat(v & 255) / 255, alpha: 1)
    }
}

enum Mat {

    static func r(_ x: CGFloat, _ y: CGFloat, _ w: CGFloat, _ h: CGFloat) -> CGRect {
        CGRect(x: x, y: y, width: w, height: h)
    }

    static func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
        CGPoint(x: x, y: y)
    }

    static func pbr(_ color: UIColor, metal: CGFloat = 0.0, rough: CGFloat = 0.6, both: Bool = false) -> SCNMaterial {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = color
        m.metalness.contents = metal
        m.roughness.contents = rough
        m.isDoubleSided = both
        return m
    }

    static func glow(_ color: UIColor, strength: CGFloat = 1.0) -> SCNMaterial {
        let m = pbr(color, rough: 0.35)
        m.emission.contents = color
        m.emission.intensity = strength
        return m
    }

    static func box(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ color: UIColor,
                    chamfer: CGFloat = 0.02, metal: CGFloat = 0, rough: CGFloat = 0.6, both: Bool = false) -> SCNNode {
        let g = SCNBox(width: w, height: h, length: l, chamferRadius: chamfer)
        g.firstMaterial = pbr(color, metal: metal, rough: rough, both: both)
        return SCNNode(geometry: g)
    }

    static func tiled(_ img: UIImage, _ sx: Float, _ sy: Float,
                      metal: CGFloat = 0, rough: CGFloat = 0.9, both: Bool = false) -> SCNMaterial {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = img
        m.diffuse.wrapS = .repeat
        m.diffuse.wrapT = .repeat
        m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1)
        m.metalness.contents = metal
        m.roughness.contents = rough
        m.isDoubleSided = both
        return m
    }

    static func outwardGlass(_ tint: UIColor, alpha: CGFloat) -> SCNMaterial {
        let m = pbr(tint, metal: 0.55, rough: 0.06)
        m.transparency = alpha
        m.isDoubleSided = false
        m.writesToDepthBuffer = false
        return m
    }

    static func noise(_ base: UIColor, _ dark: UIColor, _ light: UIColor, dots: Int, size: CGFloat = 256) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { ctx in
            let c = ctx.cgContext
            base.setFill()
            c.fill(r(0, 0, size, size))
            var rng = SystemRandomNumberGenerator()
            for i in 0..<dots {
                (i % 2 == 0 ? dark : light).setFill()
                let x = CGFloat.random(in: 0...size, using: &rng)
                let y = CGFloat.random(in: 0...size, using: &rng)
                let s = CGFloat.random(in: 1.0...4.5, using: &rng)
                c.fillEllipse(in: r(x, y, s, s))
            }
        }
    }

    static func concrete(_ base: UIColor, line: UIColor, step: CGFloat) -> UIImage {
        let size: CGFloat = 256
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { ctx in
            let c = ctx.cgContext
            base.setFill()
            c.fill(r(0, 0, size, size))
            var rng = SystemRandomNumberGenerator()
            for i in 0..<900 {
                (i % 2 == 0 ? UIColor.black.withAlphaComponent(0.05) : UIColor.white.withAlphaComponent(0.05)).setFill()
                let x = CGFloat.random(in: 0...size, using: &rng)
                let y = CGFloat.random(in: 0...size, using: &rng)
                c.fillEllipse(in: r(x, y, 3, 3))
            }
            line.setStroke()
            c.setLineWidth(2)
            var v: CGFloat = 0
            while v < size {
                c.beginPath()
                c.move(to: p(v, 0)); c.addLine(to: p(v, size))
                c.move(to: p(0, v)); c.addLine(to: p(size, v))
                c.strokePath()
                v += step
            }
        }
    }

    static func ribbed(_ base: UIColor, groove: UIColor) -> UIImage {
        let size: CGFloat = 256
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size)).image { ctx in
            let c = ctx.cgContext
            base.setFill()
            c.fill(r(0, 0, size, size))
            groove.setFill()
            var x: CGFloat = 0
            while x < size {
                c.fill(r(x, 0, 6, size))
                x += 18
            }
        }
    }

    static func skyCube() -> [UIImage] {
        let sz = CGSize(width: 256, height: 256)
        func grad(_ colors: [UIColor], _ locs: [CGFloat]) -> UIImage {
            UIGraphicsImageRenderer(size: sz).image { ctx in
                let c = ctx.cgContext
                let space = CGColorSpaceCreateDeviceRGB()
                guard let g = CGGradient(colorsSpace: space,
                                         colors: colors.map { $0.cgColor } as CFArray,
                                         locations: locs) else { return }
                c.drawLinearGradient(g, start: p(0, 0), end: p(0, 256), options: [])
            }
        }
        let side = grad([.hex(0x3C79C4), .hex(0x7FB0DE), .hex(0xC6DCEA), .hex(0xB6C8A6), .hex(0x63834A)],
                        [0.0, 0.34, 0.49, 0.53, 1.0])
        let up = grad([.hex(0x2F63AE), .hex(0x4E8AC9)], [0, 1])
        let down = grad([.hex(0x5C7A44), .hex(0x6B8A50)], [0, 1])
        return [side, side, up, down, side, side]
    }

    static func textImage(_ text: String, size: CGSize, bg: UIColor, fg: UIColor, font: CGFloat) -> UIImage {
        UIGraphicsImageRenderer(size: size).image { ctx in
            bg.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            let par = NSMutableParagraphStyle()
            par.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: font, weight: .bold),
                .foregroundColor: fg,
                .paragraphStyle: par
            ]
            let s = NSString(string: text)
            let box = s.boundingRect(with: CGSize(width: size.width - 12, height: size.height),
                                     options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
            s.draw(with: r(6, max(0, (size.height - box.height) / 2), size.width - 12, box.height),
                   options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
        }
    }

    static func label(_ t: String, w: CGFloat, h: CGFloat, bg: UIColor, fg: UIColor, font: CGFloat, both: Bool = true) -> SCNNode {
        let plane = SCNPlane(width: w, height: h)
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.roughness.contents = 0.7
        m.diffuse.contents = textImage(t, size: CGSize(width: 512, height: 512 * h / w), bg: bg, fg: fg, font: font)
        m.isDoubleSided = both
        plane.firstMaterial = m
        return SCNNode(geometry: plane)
    }

    static func sign(_ t: String, w: CGFloat, h: CGFloat, bg: UIColor, fg: UIColor, font: CGFloat) -> SCNNode {
        let n = label(t, w: w, h: h, bg: bg, fg: fg, font: font, both: false)
        return n
    }

    static func hmi(_ title: String, accent: UIColor, kind: Int) -> UIImage {
        let size = CGSize(width: 512, height: 320)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x061019).setFill()
            c.fill(r(0, 0, 512, 320))
            accent.setFill()
            c.fill(r(0, 0, 512, 44))
            let head: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24, weight: .heavy),
                .foregroundColor: UIColor.white
            ]
            NSString(string: title).draw(at: p(14, 9), withAttributes: head)

            switch kind {
            case 0:
                let cols: [UIColor] = [.hex(0x46C8F5), .hex(0x5BE08C), .hex(0xF5C542), .hex(0x46C8F5), .hex(0x5BE08C)]
                for i in 0..<6 {
                    let y = CGFloat(58 + i * 42)
                    UIColor.hex(0x0E2436).setFill()
                    c.fill(r(14, y, 484, 32))
                    cols[i % cols.count].setFill()
                    c.fill(r(18, y + 4, CGFloat(90 + (i * 71) % 360), 24))
                    UIColor.hex(0x9FC4DC).setFill()
                    c.fill(r(440, y + 10, 46, 12))
                }
            case 1:
                c.setLineWidth(18)
                c.beginPath()
                UIColor.hex(0x123246).setStroke()
                c.addArc(center: p(256, 205), radius: 88, startAngle: .pi * 0.78, endAngle: .pi * 2.22, clockwise: false)
                c.strokePath()
                c.beginPath()
                UIColor.hex(0x3BE07A).setStroke()
                c.addArc(center: p(256, 205), radius: 88, startAngle: .pi * 0.78, endAngle: .pi * 1.62, clockwise: false)
                c.strokePath()
                let big: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 46, weight: .heavy),
                    .foregroundColor: UIColor.hex(0xE6F2FA)
                ]
                NSString(string: "3.0 kV").draw(at: p(180, 180), withAttributes: big)
                let sub: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 20, weight: .semibold),
                    .foregroundColor: UIColor.hex(0x7FA7C2)
                ]
                NSString(string: "CONTACT LINE").draw(at: p(178, 236), withAttributes: sub)
            case 2:
                let states: [UIColor] = [.hex(0x2FA35A), .hex(0x2FA35A), .hex(0xF5C542), .hex(0x2FA35A),
                                         .hex(0x2FA35A), .hex(0x2FA35A), .hex(0xC0392B), .hex(0x2FA35A),
                                         .hex(0x2FA35A), .hex(0x2FA35A)]
                for i in 0..<10 {
                    let x = CGFloat(16 + (i % 5) * 98)
                    let y = CGFloat(70 + (i / 5) * 110)
                    UIColor.hex(0x0E2233).setFill()
                    c.fill(r(x, y, 88, 92))
                    states[i].setFill()
                    c.fill(r(x + 8, y + 8, 72, 14))
                    UIColor.hex(0x2A4F68).setFill()
                    c.fill(r(x + 8, y + 34, 72, 10))
                    c.fill(r(x + 8, y + 52, 52, 10))
                }
            default:
                c.setLineWidth(3)
                UIColor.hex(0x143349).setStroke()
                for i in 0..<5 {
                    let y = CGFloat(80 + CGFloat(i) * 46)
                    c.beginPath()
                    c.move(to: p(16, y)); c.addLine(to: p(496, y))
                    c.strokePath()
                }
                c.setLineWidth(5)
                UIColor.hex(0x3BE07A).setStroke()
                c.beginPath()
                c.move(to: p(20, 280))
                for i in 1...20 {
                    c.addLine(to: p(20 + CGFloat(i) * 23, 275 - CGFloat((i * 43) % 170)))
                }
                c.strokePath()
                UIColor.hex(0xF5C542).setFill()
                c.fill(r(400, 60, 90, 26))
            }
        }
    }

    static func stationScreen(_ name: String, dist: Int, speed: Int, limit: Int, accent: UIColor, caption: String) -> UIImage {
        let size = CGSize(width: 512, height: 320)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x04120C).setFill()
            c.fill(r(0, 0, 512, 320))
            accent.setFill()
            c.fill(r(0, 0, 512, 44))
            let head: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 24, weight: .heavy),
                .foregroundColor: UIColor.white
            ]
            NSString(string: caption).draw(at: p(14, 9), withAttributes: head)

            let nameAttr: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 44, weight: .heavy),
                .foregroundColor: UIColor.hex(0x63F09A)
            ]
            NSString(string: name).draw(at: p(20, 66), withAttributes: nameAttr)

            let distAttr: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 60, weight: .heavy),
                .foregroundColor: UIColor.hex(0xE8FFF2)
            ]
            NSString(string: "\(dist) m").draw(at: p(20, 128), withAttributes: distAttr)

            UIColor.hex(0x123322).setFill()
            c.fill(r(20, 210, 472, 26))
            let frac = max(0, min(1, 1 - CGFloat(dist) / 1600))
            UIColor.hex(0x3BE07A).setFill()
            c.fill(r(20, 210, 472 * frac, 26))

            let small: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 26, weight: .bold),
                .foregroundColor: UIColor.hex(0x8FD9AE)
            ]
            NSString(string: "V \(speed)").draw(at: p(20, 254), withAttributes: small)
            NSString(string: "LIM \(limit)").draw(at: p(330, 254), withAttributes: small)
        }
    }

    static func dial(_ maxSpeed: Int) -> UIImage {
        let size = CGSize(width: 512, height: 512)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x0B1017).setFill()
            c.fillEllipse(in: r(4, 4, 504, 504))
            UIColor.hex(0x1A2430).setFill()
            c.fillEllipse(in: r(26, 26, 460, 460))
            UIColor.hex(0x0B1017).setFill()
            c.fillEllipse(in: r(34, 34, 444, 444))

            let center = p(256, 256)
            for i in 0...20 {
                let major = i % 2 == 0
                let deg = -120.0 + 240.0 * Double(i) / 20.0
                let a = CGFloat(deg) * .pi / 180
                let outer = p(center.x + 214 * sin(a), center.y - 214 * cos(a))
                let inner = p(center.x + (major ? 176 : 194) * sin(a), center.y - (major ? 176 : 194) * cos(a))
                (i >= 16 ? UIColor.hex(0xE04141) : UIColor.hex(0xD8E4F0)).setStroke()
                c.setLineWidth(major ? 8 : 4)
                c.beginPath()
                c.move(to: inner); c.addLine(to: outer)
                c.strokePath()
                if major {
                    let val = maxSpeed * i / 20
                    let s = NSString(string: "\(val)")
                    let attrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 32, weight: .bold),
                        .foregroundColor: UIColor.hex(0xD8E4F0)
                    ]
                    let tp = p(center.x + 142 * sin(a), center.y - 142 * cos(a))
                    let sz = s.size(withAttributes: attrs)
                    s.draw(at: p(tp.x - sz.width / 2, tp.y - sz.height / 2), withAttributes: attrs)
                }
            }
            let t = NSString(string: "km/h")
            let a2: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 28, weight: .semibold),
                .foregroundColor: UIColor.hex(0x7C8DA0)
            ]
            let sz2 = t.size(withAttributes: a2)
            t.draw(at: p(256 - sz2.width / 2, 336), withAttributes: a2)
        }
    }
}
