import UIKit
import SceneKit

extension UIColor {
    static func hex(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 255) / 255,
                green: CGFloat((v >> 8) & 255) / 255,
                blue: CGFloat(v & 255) / 255, alpha: 1)
    }
}

enum Mat {
    static func pbr(_ color: UIColor, metal: CGFloat = 0.0, rough: CGFloat = 0.6, both: Bool = false) -> SCNMaterial {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = color
        m.metalness.contents = metal
        m.roughness.contents = rough
        m.isDoubleSided = both
        return m
    }

    static func glass() -> SCNMaterial {
        pbr(.hex(0x0B1016), metal: 0.9, rough: 0.05)
    }

    static func clearGlass() -> SCNMaterial {
        let m = pbr(.hex(0x1C2A38), metal: 0.6, rough: 0.05)
        m.transparency = 0.28
        m.writesToDepthBuffer = false
        return m
    }

    static func glow(_ color: UIColor) -> SCNMaterial {
        let m = pbr(color, rough: 0.3)
        m.emission.contents = color
        return m
    }

    static func box(_ w: CGFloat, _ h: CGFloat, _ l: CGFloat, _ color: UIColor,
                    chamfer: CGFloat = 0.02, metal: CGFloat = 0, rough: CGFloat = 0.6, both: Bool = false) -> SCNNode {
        let g = SCNBox(width: w, height: h, length: l, chamferRadius: chamfer)
        g.firstMaterial = pbr(color, metal: metal, rough: rough, both: both)
        return SCNNode(geometry: g)
    }

    static func textImage(_ text: String, size: CGSize, bg: UIColor, fg: UIColor, font: CGFloat) -> UIImage {
        UIGraphicsImageRenderer(size: size).image { ctx in
            bg.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            let p = NSMutableParagraphStyle()
            p.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: font, weight: .bold),
                .foregroundColor: fg,
                .paragraphStyle: p
            ]
            let s = NSString(string: text)
            let r = s.boundingRect(with: CGSize(width: size.width - 12, height: size.height),
                                   options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
            s.draw(with: CGRect(x: 6, y: max(0, (size.height - r.height) / 2), width: size.width - 12, height: r.height),
                   options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
        }
    }

    static func label(_ t: String, w: CGFloat, h: CGFloat, bg: UIColor, fg: UIColor, font: CGFloat, both: Bool = true) -> SCNNode {
        let plane = SCNPlane(width: w, height: h)
        let m = SCNMaterial()
        m.lightingModel = .lambert
        m.diffuse.contents = textImage(t, size: CGSize(width: 512, height: 512 * h / w), bg: bg, fg: fg, font: font)
        m.isDoubleSided = both
        plane.firstMaterial = m
        return SCNNode(geometry: plane)
    }

    static func hmi(_ title: String, accent: UIColor, kind: Int) -> UIImage {
        let size = CGSize(width: 512, height: 320)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x07111A).setFill()
            c.fill(CGRect(origin: .zero, size: size))
            accent.setFill()
            c.fill(CGRect(x: 0, y: 0, width: 512, height: 46))
            let a: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 26, weight: .bold),
                .foregroundColor: UIColor.white
            ]
            NSString(string: title).draw(at: CGPoint(x: 16, y: 9), withAttributes: a)
            switch kind {
            case 0:
                for i in 0..<7 {
                    UIColor.hex(0x102A3D).setFill()
                    c.fill(CGRect(x: 16, y: 62 + i * 35, width: 480, height: 26))
                    UIColor.hex(0x46C8F5).setFill()
                    c.fill(CGRect(x: 20, y: 66 + i * 35, width: CGFloat(70 + (i * 61) % 380), height: 18))
                }
            case 1:
                c.setLineWidth(16)
                c.beginPath()
                UIColor.hex(0x14344B).setStroke()
                c.addArc(center: CGPoint(x: 256, y: 205), radius: 95,
                         startAngle: .pi * 0.75, endAngle: .pi * 2.25, clockwise: false)
                c.strokePath()
                c.beginPath()
                UIColor.hex(0x3BE07A).setStroke()
                c.addArc(center: CGPoint(x: 256, y: 205), radius: 95,
                         startAngle: .pi * 0.75, endAngle: .pi * 1.55, clockwise: false)
                c.strokePath()
                let b: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 52, weight: .heavy),
                    .foregroundColor: UIColor.hex(0xDCEBF5)
                ]
                NSString(string: "3.0 kV").draw(at: CGPoint(x: 186, y: 178), withAttributes: b)
            case 2:
                for r in 0..<5 {
                    for col in 0..<6 {
                        UIColor.hex(0x0E2233).setFill()
                        c.fill(CGRect(x: 16 + col * 82, y: 62 + r * 50, width: 74, height: 42))
                        UIColor.hex(0x2E86AB).setFill()
                        c.fill(CGRect(x: 22 + col * 82, y: 68 + r * 50, width: 30, height: 8))
                    }
                }
            default:
                c.setLineWidth(5)
                UIColor.hex(0x1B3B55).setStroke()
                for i in 0..<5 {
                    c.beginPath()
                    c.move(to: CGPoint(x: 16, y: 90 + CGFloat(i) * 46))
                    c.addLine(to: CGPoint(x: 496, y: 90 + CGFloat(i) * 46))
                    c.strokePath()
                }
                UIColor.hex(0x3BE07A).setStroke()
                c.beginPath()
                c.move(to: CGPoint(x: 20, y: 285))
                for i in 1...20 {
                    c.addLine(to: CGPoint(x: 20 + CGFloat(i) * 23, y: 275 - CGFloat((i * 43) % 170)))
                }
                c.strokePath()
            }
        }
    }

    static func dial(_ maxSpeed: Int) -> UIImage {
        let size = CGSize(width: 512, height: 512)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let c = ctx.cgContext
            UIColor.hex(0x0E1218).setFill()
            c.fillEllipse(in: CGRect(x: 4, y: 4, width: 504, height: 504))
            UIColor.hex(0x2C3644).setStroke()
            c.setLineWidth(10)
            c.strokeEllipse(in: CGRect(x: 10, y: 10, width: 492, height: 492))
            let center = CGPoint(x: 256, y: 256)
            for i in 0...10 {
                let deg = -120.0 + 240.0 * Double(i) / 10.0
                let a = CGFloat(deg) * .pi / 180
                let outer = CGPoint(x: center.x + 212 * sin(a), y: center.y - 212 * cos(a))
                let inner = CGPoint(x: center.x + 176 * sin(a), y: center.y - 176 * cos(a))
                (i >= 8 ? UIColor.hex(0xE04141) : UIColor.hex(0xD8E4F0)).setStroke()
                c.setLineWidth(8)
                c.move(to: inner); c.addLine(to: outer); c.strokePath()
                let val = maxSpeed * i / 10
                let s = NSString(string: "\(val)")
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 34, weight: .bold),
                    .foregroundColor: UIColor.hex(0xD8E4F0)
                ]
                let tp = CGPoint(x: center.x + 140 * sin(a), y: center.y - 140 * cos(a))
                let sz = s.size(withAttributes: attrs)
                s.draw(at: CGPoint(x: tp.x - sz.width / 2, y: tp.y - sz.height / 2), withAttributes: attrs)
            }
            let t = NSString(string: "km/h")
            let a2: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 30, weight: .semibold),
                .foregroundColor: UIColor.hex(0x7C8DA0)
            ]
            let sz2 = t.size(withAttributes: a2)
            t.draw(at: CGPoint(x: 256 - sz2.width / 2, y: 330), withAttributes: a2)
        }
    }
}
