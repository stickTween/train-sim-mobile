import UIKit

struct TrainSpec: Identifiable {
    let id: String
    let ru: String
    let en: String

    let body: UIColor
    let bodyShade: UIColor
    let stripe: UIColor
    let accent: UIColor
    let roof: UIColor
    let skirt: UIColor
    let doorColor: UIColor
    let glass: UIColor

    let panelFace: UIColor
    let panelDark: UIColor
    let panelLight: UIColor
    let lcd: UIColor
    let lcdInk: UIColor

    let carLengthM: Double
    let carHeightM: Double
    let cars: Int
    let maxSpeed: Double
    let traction: Double
    let braking: Double
    let noseSlopeM: Double

    func name(_ l: Lang) -> String { l == .ru ? ru : en }

    static let all: [TrainSpec] = [lastochka, sapsan, ivolga]

    static let lastochka = TrainSpec(
        id: "lastochka", ru: "Ласточка", en: "Lastochka",
        body: .rgb(0xE8EEF4), bodyShade: .rgb(0xC2CCD6), stripe: .rgb(0x0B5FA8),
        accent: .rgb(0xD8322C), roof: .rgb(0x8D98A4), skirt: .rgb(0x39414A),
        doorColor: .rgb(0x0B5FA8), glass: .rgb(0x1E3348),
        panelFace: .rgb(0x6E7780), panelDark: .rgb(0x2A3038), panelLight: .rgb(0x99A3AD),
        lcd: .rgb(0x9BD832), lcdInk: .rgb(0x1E3308),
        carLengthM: 25, carHeightM: 3.4, cars: 4,
        maxSpeed: 160, traction: 1.35, braking: 1.30, noseSlopeM: 3.2)

    static let sapsan = TrainSpec(
        id: "sapsan", ru: "Сапсан", en: "Sapsan",
        body: .rgb(0xE2E8EE), bodyShade: .rgb(0xB8C0C9), stripe: .rgb(0xC8102E),
        accent: .rgb(0x1B4D8F), roof: .rgb(0x808A96), skirt: .rgb(0x2C333A),
        doorColor: .rgb(0xC8102E), glass: .rgb(0x1A2C3E),
        panelFace: .rgb(0x545C65), panelDark: .rgb(0x20252B), panelLight: .rgb(0x828C96),
        lcd: .rgb(0x7FD0E8), lcdInk: .rgb(0x0A2430),
        carLengthM: 26, carHeightM: 3.5, cars: 5,
        maxSpeed: 250, traction: 1.55, braking: 1.15, noseSlopeM: 6.0)

    static let ivolga = TrainSpec(
        id: "ivolga", ru: "Иволга", en: "Ivolga",
        body: .rgb(0xF2F4F2), bodyShade: .rgb(0xCFD4D8), stripe: .rgb(0xE0242B),
        accent: .rgb(0x1D3F8C), roof: .rgb(0xA8AEB4), skirt: .rgb(0x424952),
        doorColor: .rgb(0xE0242B), glass: .rgb(0x22384C),
        panelFace: .rgb(0x8C939B), panelDark: .rgb(0x30363E), panelLight: .rgb(0xB6BDC4),
        lcd: .rgb(0xE8B33C), lcdInk: .rgb(0x32200A),
        carLengthM: 23, carHeightM: 3.4, cars: 4,
        maxSpeed: 120, traction: 1.45, braking: 1.45, noseSlopeM: 2.2)
}
