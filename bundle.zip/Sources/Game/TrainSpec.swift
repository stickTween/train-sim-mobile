import UIKit

struct TrainSpec: Identifiable {
    let id: String
    let ru: String
    let en: String
    let body: UIColor
    let stripe: UIColor
    let accent: UIColor
    let roof: UIColor
    let panel: UIColor
    let wall: UIColor
    let seat: UIColor
    let cars: Int
    let length: CGFloat
    let width: CGFloat
    let height: CGFloat
    let nose: CGFloat
    let maxSpeed: Double
    let power: Double
    let brakePower: Double

    func name(_ l: Lang) -> String { l == .ru ? ru : en }
    var maxSpeedMS: Double { maxSpeed / 3.6 }

    static let all: [TrainSpec] = [lastochka, sapsan, ivolga]

    static let lastochka = TrainSpec(
        id: "lastochka", ru: "Ласточка", en: "Lastochka",
        body: .hex(0xF2F5F8), stripe: .hex(0x0B5FA5), accent: .hex(0xD32B2B),
        roof: .hex(0x98A3AE), panel: .hex(0x2A3038), wall: .hex(0xC6D0D8), seat: .hex(0x1E4C7A),
        cars: 3, length: 25, width: 3.4, height: 3.3, nose: 4.6,
        maxSpeed: 160, power: 0.78, brakePower: 1.20)

    static let sapsan = TrainSpec(
        id: "sapsan", ru: "Сапсан", en: "Sapsan",
        body: .hex(0xE9EDF2), stripe: .hex(0xC8102E), accent: .hex(0x1B4D8F),
        roof: .hex(0x8B96A3), panel: .hex(0x23272D), wall: .hex(0xD4DAE1), seat: .hex(0x7A1524),
        cars: 4, length: 26, width: 3.3, height: 3.4, nose: 7.2,
        maxSpeed: 250, power: 0.88, brakePower: 1.05)

    static let ivolga = TrainSpec(
        id: "ivolga", ru: "Иволга", en: "Ivolga",
        body: .hex(0xF8F8F6), stripe: .hex(0xE0242B), accent: .hex(0x1D3F8C),
        roof: .hex(0xB6BBC1), panel: .hex(0x30343A), wall: .hex(0xDCE1E5), seat: .hex(0x24356B),
        cars: 3, length: 23, width: 3.5, height: 3.3, nose: 3.4,
        maxSpeed: 120, power: 0.82, brakePower: 1.30)
}
