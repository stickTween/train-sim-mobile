import UIKit

enum NoseStyle {
    case blunt
    case sharp
    case rounded
}

struct TrainSpec: Identifiable {
    let id: String
    let ru: String
    let en: String
    let nose: NoseStyle

    let body: UIColor
    let bodyShade: UIColor
    let liveryMain: UIColor
    let liveryAlt: UIColor
    let roof: UIColor
    let skirt: UIColor
    let doorColor: UIColor
    let glass: UIColor
    let noseCap: UIColor

    let panelFace: UIColor
    let panelDark: UIColor
    let panelLight: UIColor
    let lcd: UIColor
    let lcdInk: UIColor

    let carLengthM: Double
    let carHeightM: Double
    let baseCars: Int
    let maxSpeed: Double
    let baseTraction: Double
    let baseBraking: Double
    let noseLenM: Double
    let express: Bool
    let costFactor: Double

    func name(_ l: Lang) -> String { l == .ru ? ru : en }

    func cost(_ u: Upgrade) -> Int {
        Int((Double(u.baseCost) * costFactor / 10).rounded()) * 10
    }

    func cars() -> Int {
        baseCars + (Save.owns(id, .pair) ? baseCars : 0)
    }

    func traction() -> Double {
        baseTraction * (Save.owns(id, .power) ? 1.25 : 1.0)
    }

    func braking() -> Double {
        baseBraking * (Save.owns(id, .brakes) ? 1.25 : 1.0)
    }

    static let all: [TrainSpec] = [lastochka, sapsan, ivolga]

    static func by(_ id: String) -> TrainSpec {
        all.first { $0.id == id } ?? lastochka
    }

    static let lastochka = TrainSpec(
        id: "lastochka", ru: "Ласточка", en: "Lastochka", nose: .blunt,
        body: .rgb(0xF2F4F6), bodyShade: .rgb(0xD2D8DE),
        liveryMain: .rgb(0xE23127), liveryAlt: .rgb(0xC01F17),
        roof: .rgb(0x9AA3AC), skirt: .rgb(0x3A4149),
        doorColor: .rgb(0xE8EAEC), glass: .rgb(0x1B2A38), noseCap: .rgb(0xE23127),
        panelFace: .rgb(0x6E7780), panelDark: .rgb(0x2A3038), panelLight: .rgb(0x99A3AD),
        lcd: .rgb(0x9BD832), lcdInk: .rgb(0x1E3308),
        carLengthM: 25, carHeightM: 3.5, baseCars: 5,
        maxSpeed: 160, baseTraction: 1.25, baseBraking: 3.2, noseLenM: 2.6,
        express: false, costFactor: 1.0)

    static let sapsan = TrainSpec(
        id: "sapsan", ru: "Сапсан", en: "Sapsan", nose: .sharp,
        body: .rgb(0xF4F6F8), bodyShade: .rgb(0xCED6DE),
        liveryMain: .rgb(0xD01B2E), liveryAlt: .rgb(0x2E4A72),
        roof: .rgb(0xB0B8C0), skirt: .rgb(0x596672),
        doorColor: .rgb(0xE4E8EC), glass: .rgb(0x16232F), noseCap: .rgb(0xE8EBEE),
        panelFace: .rgb(0x545C65), panelDark: .rgb(0x20252B), panelLight: .rgb(0x828C96),
        lcd: .rgb(0x7FD0E8), lcdInk: .rgb(0x08222E),
        carLengthM: 26, carHeightM: 3.6, baseCars: 6,
        maxSpeed: 250, baseTraction: 1.7, baseBraking: 2.9, noseLenM: 7.0,
        express: true, costFactor: 2.2)

    static let ivolga = TrainSpec(
        id: "ivolga", ru: "Иволга", en: "Ivolga", nose: .rounded,
        body: .rgb(0xF6F7F5), bodyShade: .rgb(0xD6DAD8),
        liveryMain: .rgb(0xF25C18), liveryAlt: .rgb(0x1D3F8C),
        roof: .rgb(0xB6BCC2), skirt: .rgb(0x434A52),
        doorColor: .rgb(0xF25C18), glass: .rgb(0x1E3244), noseCap: .rgb(0xF25C18),
        panelFace: .rgb(0x8C939B), panelDark: .rgb(0x30363E), panelLight: .rgb(0xB6BDC4),
        lcd: .rgb(0xE8B33C), lcdInk: .rgb(0x32200A),
        carLengthM: 23, carHeightM: 3.5, baseCars: 5,
        maxSpeed: 120, baseTraction: 1.35, baseBraking: 3.6, noseLenM: 2.2,
        express: false, costFactor: 1.5)
}
