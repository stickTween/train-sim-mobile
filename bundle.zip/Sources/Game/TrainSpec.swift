import UIKit

enum CabLayout {
    case lastochka
    case sapsan
    case ivolga
}

struct TrainSpec: Identifiable {
    let id: String
    let ru: String
    let en: String
    let layout: CabLayout

    let body: UIColor
    let stripe: UIColor
    let accent: UIColor
    let roof: UIColor
    let skirt: UIColor
    let doorColor: UIColor

    let wall: UIColor
    let wallLower: UIColor
    let ceiling: UIColor
    let trim: UIColor
    let deskTop: UIColor
    let deskBody: UIColor
    let cabAccent: UIColor
    let seat: UIColor
    let floorMat: UIColor

    let cars: Int
    let length: CGFloat
    let width: CGFloat
    let height: CGFloat
    let nose: CGFloat
    let maxSpeed: Double
    let power: Double
    let brakePower: Double

    func name(_ l: Lang) -> String { l == .ru ? ru : en }
    var maxSpeedMS: Double { maxSpeed / 3.6 }

    static let all: [TrainSpec] = [lastochka, sapsan, ivolga]

    static let lastochka = TrainSpec(
        id: "lastochka", ru: "Ласточка", en: "Lastochka", layout: .lastochka,
        body: .hex(0xEEF3F7), stripe: .hex(0x0A5CA8), accent: .hex(0xD32B2B),
        roof: .hex(0x93A0AC), skirt: .hex(0x333A42), doorColor: .hex(0x0A5CA8),
        wall: .hex(0xB6C3CE), wallLower: .hex(0x1B5FA8), ceiling: .hex(0xD6DDE3),
        trim: .hex(0x262C33), deskTop: .hex(0x99A3AD), deskBody: .hex(0x2E343B),
        cabAccent: .hex(0x1B5FA8), seat: .hex(0x2E86C1), floorMat: .hex(0x252A31),
        cars: 3, length: 25, width: 3.4, height: 3.3, nose: 4.6,
        maxSpeed: 160, power: 0.78, brakePower: 1.20)

    static let sapsan = TrainSpec(
        id: "sapsan", ru: "Сапсан", en: "Sapsan", layout: .sapsan,
        body: .hex(0xE6EBF0), stripe: .hex(0xC8102E), accent: .hex(0x1B4D8F),
        roof: .hex(0x87929F), skirt: .hex(0x2B3138), doorColor: .hex(0xC8102E),
        wall: .hex(0xA6ADB6), wallLower: .hex(0x8E2433), ceiling: .hex(0xC6CBD2),
        trim: .hex(0x1B1F24), deskTop: .hex(0x4C535C), deskBody: .hex(0x23262B),
        cabAccent: .hex(0xC8102E), seat: .hex(0x8E2433), floorMat: .hex(0x1E2227),
        cars: 4, length: 26, width: 3.3, height: 3.4, nose: 7.2,
        maxSpeed: 250, power: 0.88, brakePower: 1.05)

    static let ivolga = TrainSpec(
        id: "ivolga", ru: "Иволга", en: "Ivolga", layout: .ivolga,
        body: .hex(0xF7F8F6), stripe: .hex(0xE0242B), accent: .hex(0x1D3F8C),
        roof: .hex(0xB2B8BE), skirt: .hex(0x3B4149), doorColor: .hex(0xE0242B),
        wall: .hex(0xE0E5EA), wallLower: .hex(0x1D3F8C), ceiling: .hex(0xF1F3F5),
        trim: .hex(0x2A3038), deskTop: .hex(0xC2C8CE), deskBody: .hex(0x3A4048),
        cabAccent: .hex(0xE0242B), seat: .hex(0x27407A), floorMat: .hex(0x30363D),
        cars: 3, length: 23, width: 3.5, height: 3.3, nose: 3.4,
        maxSpeed: 120, power: 0.82, brakePower: 1.30)
}
