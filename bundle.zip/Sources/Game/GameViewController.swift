import UIKit
import SceneKit
import simd

final class GameViewController: UIViewController, SCNSceneRendererDelegate {

    private let model: GameModel
    private let spec: TrainSpec
    private let lang: Lang
    private let sceneView = SCNView()
    private let scene = SCNScene()

    private let trainNode = SCNNode()
    private var cabNode = SCNNode()
    private let cabYaw = SCNNode()
    private let cabPitch = SCNNode()
    private let cabShake = SCNNode()
    private let cabCam = SCNNode()
    private let walkRoot = SCNNode()
    private let walkYawNode = SCNNode()
    private let walkPitchNode = SCNNode()
    private let walkCam = SCNNode()

    private var throttleLever: SCNNode?
    private var brakeLever: SCNNode?
    private var needleNode: SCNNode?
    private var screenMat: SCNMaterial?
    private var doorNodes: [SCNNode] = []
    private var doorBaseZ: [Float] = []
    private var headlights: [SCNNode] = []

    private var distance: Double = 60
    private var speed: Double = 0
    private var throttle: Double = 0
    private var manualBrake: Double = 1
    private var autoBrake: Double = 0
    private var autoStop = true
    private var doorsOpen = false
    private var lightsOn = false
    private var stIdx = 0
    private var atStation = false

    private var yaw: Float = 0
    private var pitch: Float = -0.07
    private var wYaw: Float = .pi / 2
    private var wPitch: Float = 0
    private var walkPos = SIMD3<Float>(0, 0, 0)
    private var walkBob: Double = 0
    private var lastTime: TimeInterval = 0
    private var clock: Double = 0
    private var hudAcc: Double = 0
    private var dragLever: String?
    private var dragStart: Double = 0
    private var hintTimer: Double = 0

    init(model: GameModel) {
        self.model = model
        self.spec = model.spec
        self.lang = model.lang
        super.init(nibName: nil, bundle: nil)
        model.controller = self
    }

    required init?(coder: NSCoder) { fatalError() }

    override func loadView() { view = sceneView }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.scene = scene
        sceneView.delegate = self
        sceneView.isPlaying = true
        sceneView.antialiasingMode = .multisampling2X
        sceneView.preferredFramesPerSecond = 60
        sceneView.autoenablesDefaultLighting = false

        buildWorld()
        buildTrain()
        buildCameras()
        addGestures()
        applyLevers()
        updateAutoLamp()
        showHint(Loc.s("startHint", lang), seconds: 8)
    }

    private func buildWorld() {
        let sky = Mat.skyCube()
        scene.background.contents = sky
        scene.lightingEnvironment.contents = sky
        scene.lightingEnvironment.intensity = 1.7

        let parked = TrainSpec.all.first { $0.id != spec.id } ?? spec
        scene.rootNode.addChildNode(WorldBuilder.build(lang, parked: parked))

        let amb = SCNNode()
        amb.light = SCNLight()
        amb.light?.type = .ambient
        amb.light?.intensity = 90
        amb.light?.color = UIColor.hex(0x8FB4D8)
        scene.rootNode.addChildNode(amb)

        scene.fogStartDistance = 260
        scene.fogEndDistance = 1150
        scene.fogColor = UIColor.hex(0xBBD2E4)
        scene.fogDensityExponent = 1.6
    }

    private func buildTrain() {
        trainNode.addChildNode(TrainBuilder.build(spec, playerCab: true))

        cabNode = CabBuilder.build(spec, lang)
        cabNode.position = SCNVector3(0, 1.15, -Float(spec.length) + Float(spec.nose) + 2.6)
        trainNode.addChildNode(cabNode)

        let sun = SCNNode()
        sun.light = SCNLight()
        sun.light?.type = .directional
        sun.light?.intensity = 1150
        sun.light?.color = UIColor.hex(0xFFF4E2)
        sun.light?.castsShadow = true
        sun.light?.shadowMode = .deferred
        sun.light?.shadowRadius = 6
        sun.light?.shadowSampleCount = 12
        sun.light?.shadowColor = UIColor(white: 0, alpha: 0.45)
        sun.light?.maximumShadowDistance = 160
        sun.light?.orthographicScale = 45
        sun.eulerAngles = SCNVector3(-0.95, 0.75, 0)
        sun.position = SCNVector3(28, 60, -12)
        trainNode.addChildNode(sun)

        scene.rootNode.addChildNode(trainNode)

        throttleLever = cabNode.childNode(withName: "lever_throttle", recursively: true)
        brakeLever = cabNode.childNode(withName: "lever_brake", recursively: true)
        needleNode = cabNode.childNode(withName: "needle", recursively: true)
        screenMat = cabNode.childNode(withName: "screen_main", recursively: true)?.geometry?.firstMaterial

        doorNodes = trainNode.childNodes(passingTest: { n, _ in (n.name ?? "").hasPrefix("door") })
        doorBaseZ = doorNodes.map { $0.position.z }
        headlights = trainNode.childNodes(passingTest: { n, _ in n.name == "headlight" })
    }

    private func makeCamera() -> SCNCamera {
        let cam = SCNCamera()
        cam.fieldOfView = 58
        cam.projectionDirection = .vertical
        cam.zNear = 0.04
        cam.zFar = 1600
        cam.wantsHDR = true
        cam.wantsExposureAdaptation = false
        cam.exposureOffset = -0.15
        cam.bloomIntensity = 0.4
        cam.bloomThreshold = 0.82
        cam.bloomBlurRadius = 10
        cam.saturation = 1.18
        cam.contrast = 0.1
        return cam
    }

    private func buildCameras() {
        cabCam.camera = makeCamera()
        cabShake.addChildNode(cabCam)
        cabPitch.addChildNode(cabShake)
        cabYaw.addChildNode(cabPitch)
        cabYaw.position = SCNVector3(0, CabBuilder.eyeHeight, CabBuilder.eyeZ)
        cabNode.addChildNode(cabYaw)
        cabPitch.eulerAngles.x = pitch

        walkCam.camera = makeCamera()
        walkCam.camera?.fieldOfView = 64
        walkPitchNode.addChildNode(walkCam)
        walkYawNode.addChildNode(walkPitchNode)
        walkRoot.addChildNode(walkYawNode)
        scene.rootNode.addChildNode(walkRoot)

        sceneView.pointOfView = cabCam
    }

    private func addGestures() {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        sceneView.addGestureRecognizer(pan)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        sceneView.addGestureRecognizer(tap)
    }

    @objc private func onPan(_ g: UIPanGestureRecognizer) {
        let point = g.location(in: sceneView)
        switch g.state {
        case .began:
            dragLever = nil
            if model.mode == .cab, let name = hitName(point, prefix: "lever_") {
                dragLever = name
                dragStart = name == "lever_throttle" ? throttle : manualBrake
            }
            g.setTranslation(.zero, in: sceneView)
        case .changed:
            let t = g.translation(in: sceneView)
            if let lever = dragLever {
                let v = min(1, max(0, dragStart - Double(t.y) / 170))
                if lever == "lever_throttle" {
                    throttle = v
                    if v > 0.12 {
                        manualBrake = 0
                        departIfStopped()
                    }
                } else {
                    manualBrake = v
                    if v > 0.05 { throttle = 0 }
                }
                applyLevers()
            } else {
                if model.mode == .cab {
                    yaw -= Float(t.x) * 0.0042
                    pitch -= Float(t.y) * 0.0042
                    yaw = min(2.3, max(-2.3, yaw))
                    pitch = min(0.95, max(-0.95, pitch))
                    cabYaw.eulerAngles.y = yaw
                    cabPitch.eulerAngles.x = pitch
                } else {
                    wYaw -= Float(t.x) * 0.0042
                    wPitch -= Float(t.y) * 0.0042
                    wPitch = min(0.9, max(-0.9, wPitch))
                    walkYawNode.eulerAngles.y = wYaw
                    walkPitchNode.eulerAngles.x = wPitch
                }
                g.setTranslation(.zero, in: sceneView)
            }
        default:
            dragLever = nil
        }
    }

    @objc private func onTap(_ g: UITapGestureRecognizer) {
        guard model.mode == .cab else { return }
        let point = g.location(in: sceneView)
        let hits = sceneView.hitTest(point, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
        for h in hits {
            if let n = ancestor(h.node, prefix: "btn_") {
                press(n)
                return
            }
            if let n = ancestor(h.node, prefix: "lever_"), let name = n.name {
                if name == "lever_throttle" {
                    manualBrake = 0
                    throttle = throttle >= 0.99 ? 0 : min(1, throttle + 0.25)
                    departIfStopped()
                } else {
                    manualBrake = manualBrake > 0.5 ? 0 : 1
                    if manualBrake > 0.5 { throttle = 0 }
                }
                applyLevers()
                return
            }
        }
    }

    private func departIfStopped() {
        if atStation {
            stIdx = min(stIdx + 1, WorldBuilder.stations.count)
            atStation = false
        }
    }

    private func hitName(_ point: CGPoint, prefix: String) -> String? {
        let hits = sceneView.hitTest(point, options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
        for h in hits {
            if let n = ancestor(h.node, prefix: prefix) { return n.name }
        }
        return nil
    }

    private func ancestor(_ n: SCNNode, prefix: String) -> SCNNode? {
        var cur: SCNNode? = n
        while let c = cur {
            if let name = c.name, name.hasPrefix(prefix), !name.hasSuffix("_cap"), !name.hasSuffix("_lamp") { return c }
            cur = c.parent
        }
        return nil
    }

    private func press(_ n: SCNNode) {
        let down = SCNAction.moveBy(x: 0, y: 0, z: -0.014, duration: 0.06)
        n.runAction(SCNAction.sequence([down, down.reversed()]))
        switch n.name {
        case "btn_autostop":
            autoStop.toggle()
            updateAutoLamp()
            showHint(Loc.s(autoStop ? "autoOn" : "autoOff", lang))
        case "btn_doors":
            if speed < 0.2 {
                doorsOpen.toggle()
                animateDoors()
                setLamp(n, on: doorsOpen)
            } else {
                showHint(Loc.s("closed", lang))
            }
        case "btn_lights":
            lightsOn.toggle()
            for h in headlights {
                h.geometry?.firstMaterial = lightsOn
                    ? Mat.glow(.hex(0xFFF6DC), strength: 1.6)
                    : Mat.pbr(.hex(0xF3F4E8), rough: 0.08)
            }
            setLamp(n, on: lightsOn)
        case "btn_horn":
            showHint(Loc.s("hornSound", lang))
        default:
            break
        }
    }

    private func setLamp(_ holder: SCNNode, on: Bool) {
        guard let name = holder.name,
              let lamp = cabNode.childNode(withName: name + "_lamp", recursively: true) else { return }
        lamp.geometry?.firstMaterial = on
            ? Mat.glow(.hex(0x54F09A), strength: 1.2)
            : Mat.pbr(.hex(0x2E353D), rough: 0.4)
    }

    private func updateAutoLamp() {
        if let b = cabNode.childNode(withName: "btn_autostop", recursively: true) {
            setLamp(b, on: autoStop)
        }
    }

    private func animateDoors() {
        for (i, d) in doorNodes.enumerated() {
            let base = doorBaseZ[i]
            let dir: Float = i % 2 == 0 ? -1 : 1
            let target = doorsOpen ? base + dir * 0.64 : base
            d.runAction(SCNAction.move(to: SCNVector3(d.position.x, d.position.y, target), duration: 0.8))
        }
    }

    private func applyLevers() {
        throttleLever?.eulerAngles.x = Float(0.5 - throttle * 1.05)
        brakeLever?.eulerAngles.x = Float(0.5 - max(manualBrake, autoBrake) * 1.05)
    }

    func toggleExit() {
        if model.mode == .cab {
            guard speed < 0.15, doorsOpen else { return }
            let doorZ = -Float(distance) - Float(spec.length * 0.45)
            let onPlatform = nearStation() != nil
            walkPos = SIMD3<Float>(3.4, onPlatform ? 1.0 : 0, doorZ)
            wYaw = .pi / 2
            wPitch = 0
            walkYawNode.eulerAngles.y = wYaw
            walkPitchNode.eulerAngles.x = 0
            walkRoot.position = SCNVector3(walkPos.x, walkPos.y + 1.68, walkPos.z)
            sceneView.pointOfView = walkCam
            DispatchQueue.main.async { self.model.mode = .walk }
            showHint(Loc.s("walkHint", lang), seconds: 5)
        } else {
            let doorZ = -Float(distance) - Float(spec.length * 0.45)
            let d = simd_length(SIMD2<Float>(walkPos.x - 2.0, walkPos.z - doorZ))
            guard d < 4.5 else { return }
            sceneView.pointOfView = cabCam
            DispatchQueue.main.async { self.model.mode = .cab }
        }
    }

    private func nearStation() -> Station? {
        WorldBuilder.stations.first { abs($0.pos - distance) < 62 }
    }

    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if lastTime == 0 { lastTime = time }
        let dt = min(0.05, time - lastTime)
        lastTime = time
        clock += dt
        step(dt)
    }

    private func step(_ dt: Double) {
        if model.mode == .walk {
            throttle = 0
            manualBrake = 1
            updateWalk(dt)
        }

        autoBrake = 0
        if stIdx < WorldBuilder.stations.count {
            let st = WorldBuilder.stations[stIdx]
            let d = st.pos - distance
            if d < -30 {
                stIdx += 1
            } else if autoStop && d > 0 {
                let need = speed * speed / (2 * max(d - 1.5, 0.4))
                if need > spec.brakePower * 0.28 {
                    autoBrake = min(1, need / spec.brakePower)
                    throttle = 0
                }
                if d < 22 && speed < 0.4 { autoBrake = 1 }
            }
            atStation = abs(d) < 28 && speed < 0.3
        }

        let brake = max(manualBrake, autoBrake)
        let ratio = speed / max(spec.maxSpeedMS, 1)
        var a = throttle * spec.power * max(0.15, 1 - ratio * 0.85)
        a -= brake * spec.brakePower
        a -= 0.03 + speed * 0.0045
        speed = max(0, speed + a * dt)
        if speed < 0.02 { speed = 0 }
        distance += speed * dt
        if distance > WorldBuilder.length - 300 {
            distance = WorldBuilder.length - 300
            speed = 0
        }

        trainNode.position = SCNVector3(0, 0, -Float(distance))
        applyLevers()

        let r = min(1.0, speed * 3.6 / spec.maxSpeed)
        needleNode?.eulerAngles.z = Float(2.0944 - 4.1888 * r)

        let amp = Float(min(1.0, speed / 45)) * 0.0035
        cabShake.position = SCNVector3(sinf(Float(clock) * 17.3) * amp,
                                       cosf(Float(clock) * 23.1) * amp,
                                       0)

        hudAcc += dt
        if hudAcc > 0.12 {
            hudAcc = 0
            updateHUD()
        }
        if hintTimer > 0 {
            hintTimer -= dt
            if hintTimer <= 0 {
                DispatchQueue.main.async { self.model.hint = "" }
            }
        }
    }

    private func updateWalk(_ dt: Double) {
        let v = model.walkVector
        if abs(v.x) > 0.02 || abs(v.y) > 0.02 {
            let fwd = SIMD3<Float>(-sin(wYaw), 0, -cos(wYaw))
            let right = SIMD3<Float>(cos(wYaw), 0, -sin(wYaw))
            var p = walkPos + (fwd * (-v.y) + right * v.x) * (3.3 * Float(dt))
            p.x = min(26, max(-14, p.x))
            let trainZ = -Float(distance)
            p.z = min(trainZ + 130, max(trainZ - 220, p.z))
            let onPlatform = nearStation() != nil && p.x > 1.9 && p.x < 9.7
            p.y = onPlatform ? 1.0 : 0
            walkPos = p
            walkBob += dt * 7
        }
        let bob = Float(sin(walkBob)) * 0.03
        walkRoot.position = SCNVector3(walkPos.x, walkPos.y + 1.68 + bob, walkPos.z)
    }

    private func updateHUD() {
        let st = stIdx < WorldBuilder.stations.count ? WorldBuilder.stations[stIdx] : nil
        let name = st?.name(lang) ?? "—"
        let dist = max(0, (st?.pos ?? distance) - distance)
        let canExit = speed < 0.15 && doorsOpen
        let doorZ = -Float(distance) - Float(spec.length * 0.45)
        let canEnter = simd_length(SIMD2<Float>(walkPos.x - 2.0, walkPos.z - doorZ)) < 4.5

        screenMat?.diffuse.contents = Mat.stationScreen(name,
                                                        dist: Int(dist),
                                                        speed: Int(speed * 3.6),
                                                        limit: Int(spec.maxSpeed),
                                                        accent: spec.cabAccent,
                                                        caption: Loc.s("route", lang))

        DispatchQueue.main.async {
            self.model.speed = self.speed
            self.model.nextStation = name
            self.model.distanceToStation = dist
            self.model.canExit = canExit
            self.model.canEnter = canEnter
            self.model.autoStop = self.autoStop
            self.model.doorsOpen = self.doorsOpen
            self.model.throttle = self.throttle
            self.model.brake = max(self.manualBrake, self.autoBrake)
        }
    }

    private func showHint(_ t: String, seconds: Double = 1.8) {
        hintTimer = seconds
        DispatchQueue.main.async { self.model.hint = t }
    }
}
