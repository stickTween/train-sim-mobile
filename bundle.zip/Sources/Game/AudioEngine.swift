import AVFoundation

final class AudioEngine {

    private let engine = AVAudioEngine()
    private var source: AVAudioSourceNode?
    private let sr: Double = 44100
    private var running = false

    var speed: Double = 0
    var tractionLevel: Double = 0
    var brakeLevel: Double = 0
    var master: Double = 1

    private var sSpeed: Double = 0
    private var sTraction: Double = 0
    private var sBrake: Double = 0
    private var sMaster: Double = 0

    private var p1: Double = 0
    private var p2: Double = 0
    private var p3: Double = 0
    private var thump: Double = 0
    private var hornA: Double = 0
    private var hornB: Double = 0
    private var chimeA: Double = 0
    private var chimeB: Double = 0

    private var clackEnv: Double = 0
    private var hissEnv: Double = 0
    private var hornEnv: Double = 0
    private var hornGate: Double = 0
    private var chimeEnv: Double = 0
    private var doorEnv: Double = 0

    private var lp1: Double = 0
    private var lp2: Double = 0
    private var lp3: Double = 0
    private var hp: Double = 0
    private var dcX: Double = 0
    private var dcY: Double = 0
    private var soft: Double = 0
    private var rng: UInt64 = 0x9E3779B97F4A7C15

    func start() {
        guard !running else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)

        guard let fmt = AVAudioFormat(standardFormatWithSampleRate: sr, channels: 2) else { return }
        let node = AVAudioSourceNode(format: fmt) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            let abl = UnsafeMutableAudioBufferListPointer(audioBufferList)
            for frame in 0..<Int(frameCount) {
                let v = self.nextSample()
                for buffer in abl {
                    guard let data = buffer.mData else { continue }
                    data.assumingMemoryBound(to: Float.self)[frame] = v
                }
            }
            return noErr
        }
        source = node
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: fmt)
        engine.mainMixerNode.outputVolume = 0.55
        do {
            try engine.start()
            running = true
        } catch {
            running = false
        }
    }

    func stop() {
        guard running else { return }
        engine.stop()
        if let s = source { engine.detach(s) }
        source = nil
        running = false
    }

    func clack() { clackEnv = 1 }
    func hiss() { hissEnv = max(hissEnv, 1) }
    func horn() { hornEnv = 1; hornGate = 0 }
    func chime() { chimeEnv = 1 }
    func doorMotor() { doorEnv = 1 }

    private func noise() -> Double {
        rng = rng &* 6364136223846793005 &+ 1442695040888963407
        return Double((rng >> 40) & 0xFFFF) / 32768.0 - 1.0
    }

    private static func sinf2(_ t: Double) -> Double {
        sin(t * 2 * Double.pi)
    }

    private func nextSample() -> Float {
        sSpeed += (speed - sSpeed) * 0.00035
        sTraction += (tractionLevel - sTraction) * 0.00025
        sBrake += (brakeLevel - sBrake) * 0.00025
        sMaster += (master - sMaster) * 0.0006

        let nz = noise()
        lp1 += (nz - lp1) * 0.030
        lp2 += (lp1 - lp2) * 0.024
        lp3 += (lp2 - lp3) * 0.018

        let v = sSpeed
        let rumble = lp3 * min(0.30, v * 0.0125) * 1.6
        let wind = lp1 * min(0.035, max(0, v - 12) * 0.0016)

        let f = 24 + v * 1.85
        p1 += f / sr
        if p1 >= 1 { p1 -= 1 }
        p2 += (f * 2) / sr
        if p2 >= 1 { p2 -= 1 }
        p3 += (f * 3.02) / sr
        if p3 >= 1 { p3 -= 1 }
        let tone = AudioEngine.sinf2(p1) * 0.62
            + AudioEngine.sinf2(p2) * 0.24
            + AudioEngine.sinf2(p3) * 0.10
        let motorGain = 0.050 * (0.22 + 0.78 * sTraction) * min(1, 0.25 + v / 34)
        let motor = tone * motorGain

        var clack = 0.0
        if clackEnv > 0 {
            clackEnv -= 1 / (sr * 0.085)
            thump += 74 / sr
            if thump >= 1 { thump -= 1 }
            let e = max(0, clackEnv)
            let env = e * e
            clack = (lp2 * 0.55 + AudioEngine.sinf2(thump) * 0.45) * env * 0.16 * min(1, v / 9)
        }

        var hissOut = 0.0
        if hissEnv > 0 {
            hissEnv -= 1 / (sr * 0.9)
            hp = lp1 - lp2
            hissOut = hp * max(0, hissEnv) * 0.10
        }

        var horn = 0.0
        if hornEnv > 0 {
            hornEnv -= 1 / (sr * 1.15)
            hornGate = min(1, hornGate + 1 / (sr * 0.06))
            hornA += 277 / sr
            if hornA >= 1 { hornA -= 1 }
            hornB += 370 / sr
            if hornB >= 1 { hornB -= 1 }
            let env = min(hornGate, max(0, hornEnv) * 2.2)
            horn = (AudioEngine.sinf2(hornA) * 0.55 + AudioEngine.sinf2(hornB) * 0.40
                + AudioEngine.sinf2(hornA * 2) * 0.10) * 0.085 * env
        }

        var chime = 0.0
        if chimeEnv > 0 {
            chimeEnv -= 1 / (sr * 1.5)
            chimeA += 784 / sr
            if chimeA >= 1 { chimeA -= 1 }
            chimeB += 1046 / sr
            if chimeB >= 1 { chimeB -= 1 }
            let e = max(0, chimeEnv)
            let env = e * e * e
            chime = (AudioEngine.sinf2(chimeA) * 0.6 + AudioEngine.sinf2(chimeB) * 0.4) * 0.075 * env
        }

        var door = 0.0
        if doorEnv > 0 {
            doorEnv -= 1 / (sr * 1.0)
            door = lp3 * max(0, doorEnv) * 0.075
        }

        var mixv = (rumble + wind + motor + clack + hissOut + horn + chime + door) * sMaster
        soft += (mixv - soft) * 0.55
        mixv = soft
        let sat = mixv / (1 + abs(mixv) * 1.4)
        dcY = sat - dcX + 0.997 * dcY
        dcX = sat
        return Float(max(-0.95, min(0.95, dcY)))
    }
}
