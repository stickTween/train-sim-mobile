import AVFoundation

final class AudioEngine {

    private let engine = AVAudioEngine()
    private var source: AVAudioSourceNode?
    private let sr: Double = 44100
    private var running = false

    var speed: Double = 0
    var tractionLevel: Double = 0
    var brakeLevel: Double = 0
    var master: Double = 1

    private var motorPhase: Double = 0
    private var motorPhase2: Double = 0
    private var clackEnv: Double = 0
    private var hissEnv: Double = 0
    private var hornEnv: Double = 0
    private var hornA: Double = 0
    private var hornB: Double = 0
    private var chimeEnv: Double = 0
    private var chimePhase: Double = 0
    private var doorEnv: Double = 0
    private var rng: UInt64 = 0x9E3779B97F4A7C15
    private var lowpass: Double = 0

    func start() {
        guard !running else { return }
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)

        guard let fmt = AVAudioFormat(standardFormatWithSampleRate: sr, channels: 2) else { return }
        let node = AVAudioSourceNode(format: fmt) { [weak self] _, _, frameCount, audioBufferList -> OSStatus in
            guard let self = self else { return noErr }
            let abl = UnsafeMutableAudioBufferListPointer(audioBufferList)
            let n = Int(frameCount)
            for frame in 0..<n {
                let v = self.nextSample()
                for buffer in abl {
                    guard let data = buffer.mData else { continue }
                    let ptr = data.assumingMemoryBound(to: Float.self)
                    ptr[frame] = v
                }
            }
            return noErr
        }
        source = node
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: fmt)
        engine.mainMixerNode.outputVolume = 0.9
        do {
            try engine.start()
            running = true
        } catch {
            running = false
        }
    }

    func stop() {
        guard running else { return }
        engine.stop()
        if let s = source { engine.detach(s) }
        source = nil
        running = false
    }

    func clack() { clackEnv = 1 }
    func hiss() { hissEnv = max(hissEnv, 1) }
    func horn() { hornEnv = 1 }
    func chime() { chimeEnv = 1 }
    func doorMotor() { doorEnv = 1 }

    private func noise() -> Double {
        rng = rng &* 6364136223846793005 &+ 1442695040888963407
        return Double((rng >> 40) & 0xFFFF) / 32768.0 - 1.0
    }

    private func nextSample() -> Float {
        let v = speed
        let nz = noise()

        lowpass += (nz - lowpass) * 0.18
        let rollAmt = min(0.30, v * 0.0085)
        let rolling = lowpass * rollAmt

        let f1 = 42 + v * 3.6
        motorPhase += f1 / sr
        if motorPhase >= 1 { motorPhase -= 1 }
        motorPhase2 += (f1 * 1.5) / sr
        if motorPhase2 >= 1 { motorPhase2 -= 1 }
        let saw = motorPhase * 2 - 1
        let saw2 = motorPhase2 * 2 - 1
        let motorAmt = 0.09 * tractionLevel * min(1, 0.35 + v / 26)
        let motor = (saw * 0.7 + saw2 * 0.3) * motorAmt

        if clackEnv > 0 { clackEnv -= 1 / (sr * 0.045) }
        let clack = nz * max(0, clackEnv) * max(0, clackEnv) * 0.42 * min(1, v / 8)

        if hissEnv > 0 { hissEnv -= 1 / (sr * 0.7) }
        let hiss = lowpass * max(0, hissEnv) * 0.22

        var horn = 0.0
        if hornEnv > 0 {
            hornEnv -= 1 / (sr * 1.0)
            hornA += 311 / sr
            if hornA >= 1 { hornA -= 1 }
            hornB += 466 / sr
            if hornB >= 1 { hornB -= 1 }
            let env = min(1, max(0, hornEnv) * 3)
            horn = (sin(hornA * 2 * .pi) + sin(hornB * 2 * .pi) * 0.8) * 0.15 * env
        }

        var chime = 0.0
        if chimeEnv > 0 {
            chimeEnv -= 1 / (sr * 0.9)
            let f = chimeEnv > 0.5 ? 880.0 : 660.0
            chimePhase += f / sr
            if chimePhase >= 1 { chimePhase -= 1 }
            chime = sin(chimePhase * 2 * .pi) * 0.12 * max(0, chimeEnv)
        }

        var door = 0.0
        if doorEnv > 0 {
            doorEnv -= 1 / (sr * 0.8)
            door = lowpass * max(0, doorEnv) * 0.10
        }

        let mix = (rolling + motor + clack + hiss + horn + chime + door) * master
        return Float(max(-1, min(1, mix)))
    }
}
