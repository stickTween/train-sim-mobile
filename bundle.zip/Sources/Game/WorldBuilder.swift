import SceneKit
import UIKit

struct Station {
    let ru: String
    let en: String
    let pos: Double
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
}

enum WorldBuilder {
    static let stations: [Station] = [
        Station(ru: "Заречная", en: "Zarechnaya", pos: 950),
        Station(ru: "Северный Парк", en: "North Park", pos: 2500),
        Station(ru: "Лесная", en: "Lesnaya", pos: 4200),
        Station(ru: "Приморская", en: "Primorskaya", pos: 6100)
    ]
    static let length: Double = 7400
    static let platformX: Float = 5.7

    static func build(_ lang: Lang, parked: TrainSpec) -> SCNNode {
        let root = SCNNode()

        let floor = SCNFloor()
        floor.reflectivity = 0
        floor.firstMaterial = Mat.tiled(Mat.noise(.hex(0x5C8443), .hex(0x476933), .hex(0x709A52), dots: 2200),
                                        260, 260, rough: 0.98)
        root.addChildNode(SCNNode(geometry: floor))

        let zStart: CGFloat = 220
        let zEnd: CGFloat = -CGFloat(length)
        let mid = Float((zStart + zEnd) / 2)
        let span = CGFloat(zStart - zEnd)

        let bed = SCNNode(geometry: SCNBox(width: 13, height: 0.5, length: span, chamferRadius: 0))
        bed.geometry?.firstMaterial = Mat.tiled(Mat.noise(.hex(0x6E6A61), .hex(0x504C45), .hex(0x8A857A), dots: 2600),
                                                6, 900, rough: 1.0)
        bed.position = SCNVector3(0, 0.25, mid)
        root.addChildNode(bed)

        let sleepers = SCNNode()
        var z = Float(zStart)
        while z > Float(zEnd) {
            let sl = Mat.box(2.75, 0.17, 0.3, .hex(0x4A4038), chamfer: 0.02, rough: 1)
            sl.position = SCNVector3(0, 0.56, z)
            sleepers.addChildNode(sl)
            let sl2 = sl.clone()
            sl2.position = SCNVector3(-9, 0.56, z)
            sleepers.addChildNode(sl2)
            z -= 4.5
        }
        root.addChildNode(sleepers.flattenedClone())

        for x in [Float(-0.72), Float(0.72), Float(-9.72), Float(-8.28)] {
            let rail = Mat.box(0.15, 0.2, span, .hex(0x9AA0A6), chamfer: 0.02, metal: 0.95, rough: 0.22)
            rail.position = SCNVector3(x, 0.69, mid)
            root.addChildNode(rail)
        }

        let poles = SCNNode()
        var pz = Float(zStart)
        while pz > Float(zEnd) {
            let pole = Mat.box(0.24, 8.6, 0.24, .hex(0x7E848A), chamfer: 0.03, metal: 0.55, rough: 0.45)
            pole.position = SCNVector3(4.7, 4.3, pz)
            poles.addChildNode(pole)
            let arm = Mat.box(4.6, 0.16, 0.16, .hex(0x7E848A), chamfer: 0.03, metal: 0.55, rough: 0.45)
            arm.position = SCNVector3(2.5, 8.3, pz)
            poles.addChildNode(arm)
            let brace = Mat.box(2.4, 0.1, 0.1, .hex(0x7E848A), chamfer: 0.02, metal: 0.55, rough: 0.45)
            brace.eulerAngles.z = 0.5
            brace.position = SCNVector3(3.6, 7.3, pz)
            poles.addChildNode(brace)
            pz -= 52
        }
        root.addChildNode(poles.flattenedClone())

        for x in [Float(0), Float(-9)] {
            let wire = Mat.box(0.05, 0.05, span, .hex(0x3A3F45), chamfer: 0, metal: 0.8, rough: 0.35)
            wire.position = SCNVector3(x, 7.5, mid)
            root.addChildNode(wire)
            let carrier = Mat.box(0.04, 0.04, span, .hex(0x4A5058), chamfer: 0, metal: 0.8, rough: 0.35)
            carrier.position = SCNVector3(x, 8.25, mid)
            root.addChildNode(carrier)
        }

        root.addChildNode(scenery())
        root.addChildNode(signals())
        root.addChildNode(kmPosts())

        for s in stations {
            root.addChildNode(station(s, lang))
        }

        let parkedTrain = TrainBuilder.build(parked)
        parkedTrain.position = SCNVector3(-9, 0, -Float(stations[1].pos) + 30)
        root.addChildNode(parkedTrain)

        return root
    }

    private static func signals() -> SCNNode {
        let group = SCNNode()
        var d: Double = 400
        var i = 0
        while d < length - 300 {
            let sig = SCNNode()
            let mast = Mat.box(0.18, 5.0, 0.18, .hex(0x6E747A), chamfer: 0.03, metal: 0.5, rough: 0.5)
            mast.position = SCNVector3(0, 2.5, 0)
            sig.addChildNode(mast)
            let head = Mat.box(0.42, 1.15, 0.3, .hex(0x22262B), chamfer: 0.07, rough: 0.5)
            head.position = SCNVector3(0, 5.3, 0)
            sig.addChildNode(head)
            let green = i % 4 != 3
            let colors: [UIColor] = [.hex(0xC0392B), .hex(0xE8C13A), .hex(0x2FA35A)]
            let onIndex = green ? 2 : 0
            for (k, c) in colors.enumerated() {
                let lamp = SCNNode(geometry: SCNSphere(radius: 0.11))
                lamp.geometry?.firstMaterial = k == onIndex ? Mat.glow(c, strength: 1.4) : Mat.pbr(.hex(0x14181C), rough: 0.4)
                lamp.position = SCNVector3(0, 5.0 + Float(k) * 0.32, -0.16)
                sig.addChildNode(lamp)
            }
            let ladder = Mat.box(0.05, 4.4, 0.3, .hex(0x8A9098), chamfer: 0.01, metal: 0.5, rough: 0.5)
            ladder.position = SCNVector3(0.16, 2.4, 0.2)
            sig.addChildNode(ladder)
            sig.position = SCNVector3(3.6, 0, -Float(d))
            group.addChildNode(sig)
            d += 520
            i += 1
        }
        return group
    }

    private static func kmPosts() -> SCNNode {
        let group = SCNNode()
        var d: Double = 200
        var km = 1
        while d < length - 200 {
            let post = Mat.box(0.1, 1.3, 0.1, .hex(0xD8DDE2), chamfer: 0.02, rough: 0.6)
            post.position = SCNVector3(0, 0.65, 0)
            let sign = Mat.label("\(km)", w: 0.4, h: 0.3, bg: .hex(0xF0F3F6), fg: .hex(0x1B1F24), font: 150)
            sign.position = SCNVector3(0, 1.4, 0.02)
            let n = SCNNode()
            n.addChildNode(post)
            n.addChildNode(sign)
            n.position = SCNVector3(-2.6, 0.5, -Float(d))
            n.eulerAngles.y = .pi / 2
            group.addChildNode(n)
            d += 500
            km += 1
        }
        return group
    }

    private static func scenery() -> SCNNode {
        let group = SCNNode()
        var rng = SystemRandomNumberGenerator()
        var z: Float = 170
        let greens: [UIColor] = [.hex(0x2E6B34), .hex(0x3B7C39), .hex(0x255A2B), .hex(0x4A8340), .hex(0x1F4D26)]
        let walls: [UIColor] = [.hex(0xD8C7A8), .hex(0xC9B79B), .hex(0xE0D6C2), .hex(0xB6C2CC), .hex(0xD9C0B0)]
        let roofs: [UIColor] = [.hex(0x8A3B32), .hex(0x5A6470), .hex(0x7A5236), .hex(0x3F5A46)]

        while z > -Float(length) {
            let count = Int.random(in: 2...4, using: &rng)
            for _ in 0..<count {
                let side: Float = Bool.random(using: &rng) ? 1 : -1
                let x = side * Float.random(in: 17...78, using: &rng)
                let hgt = CGFloat.random(in: 4.5...11, using: &rng)
                let tree = SCNNode()
                let trunk = Mat.box(0.55, hgt * 0.38, 0.55, .hex(0x533B26), chamfer: 0.06, rough: 1)
                trunk.position = SCNVector3(0, Float(hgt * 0.19), 0)
                tree.addChildNode(trunk)
                let crown = SCNNode(geometry: SCNCone(topRadius: 0, bottomRadius: hgt * 0.34, height: hgt * 0.9))
                crown.geometry?.firstMaterial = Mat.pbr(greens.randomElement(using: &rng) ?? .green, rough: 1)
                crown.position = SCNVector3(0, Float(hgt * 0.38 + hgt * 0.45), 0)
                tree.addChildNode(crown)
                let crown2 = SCNNode(geometry: SCNCone(topRadius: 0, bottomRadius: hgt * 0.24, height: hgt * 0.6))
                crown2.geometry?.firstMaterial = crown.geometry?.firstMaterial
                crown2.position = SCNVector3(0, Float(hgt * 0.38 + hgt * 0.8), 0)
                tree.addChildNode(crown2)
                tree.position = SCNVector3(x, 0, z)
                group.addChildNode(tree)
            }
            if Int.random(in: 0...3, using: &rng) == 0 {
                let bw = CGFloat.random(in: 9...20, using: &rng)
                let bh = CGFloat.random(in: 6...18, using: &rng)
                let side: Float = Bool.random(using: &rng) ? 1 : -1
                let bx = side * Float.random(in: 45...105, using: &rng)
                let b = Mat.box(bw, bh, bw * 0.75, walls.randomElement(using: &rng) ?? .gray, chamfer: 0.1, rough: 0.9)
                b.position = SCNVector3(bx, Float(bh / 2), z)
                group.addChildNode(b)
                let roof = Mat.box(bw + 0.7, 0.55, bw * 0.75 + 0.7, roofs.randomElement(using: &rng) ?? .brown,
                                   chamfer: 0.1, rough: 0.85)
                roof.position = SCNVector3(bx, Float(bh) + 0.28, z)
                group.addChildNode(roof)
                var wy: CGFloat = 1.6
                while wy < bh - 1.2 {
                    let win = Mat.box(bw * 0.82, 0.9, bw * 0.78, .hex(0x2A3A48), chamfer: 0.05, metal: 0.5, rough: 0.2)
                    win.position = SCNVector3(bx, Float(wy), z)
                    group.addChildNode(win)
                    wy += 3.2
                }
            }
            z -= Float.random(in: 16...30, using: &rng)
        }
        return group.flattenedClone()
    }

    private static func person(_ color: UIColor) -> SCNNode {
        let n = SCNNode()
        let legs = Mat.box(0.26, 0.52, 0.2, .hex(0x2A2F36), chamfer: 0.06, rough: 0.95)
        legs.position = SCNVector3(0, 0.26, 0)
        n.addChildNode(legs)
        let body = SCNNode(geometry: SCNCapsule(capRadius: 0.17, height: 0.72))
        body.geometry?.firstMaterial = Mat.pbr(color, rough: 0.95)
        body.position = SCNVector3(0, 0.85, 0)
        n.addChildNode(body)
        let head = SCNNode(geometry: SCNSphere(radius: 0.125))
        head.geometry?.firstMaterial = Mat.pbr(.hex(0xD6A57E), rough: 0.9)
        head.position = SCNVector3(0, 1.32, 0)
        n.addChildNode(head)
        return n
    }

    private static func station(_ s: Station, _ lang: Lang) -> SCNNode {
        let n = SCNNode()

        let plat = SCNNode(geometry: SCNBox(width: 8.4, height: 1.0, length: 132, chamferRadius: 0.04))
        plat.geometry?.firstMaterial = Mat.tiled(Mat.concrete(.hex(0xC2BCB2), line: .hex(0xA8A296), step: 64),
                                                 3, 46, rough: 0.9)
        plat.position = SCNVector3(platformX, 0.5, 0)
        n.addChildNode(plat)

        let edge = Mat.box(0.6, 0.15, 132, .hex(0xEFC93E), chamfer: 0.02, rough: 0.6)
        edge.position = SCNVector3(1.95, 1.03, 0)
        n.addChildNode(edge)

        let tactile = Mat.box(0.35, 0.03, 132, .hex(0x5A5F66), chamfer: 0.01, rough: 0.9)
        tactile.position = SCNVector3(2.55, 1.03, 0)
        n.addChildNode(tactile)

        let canopy = Mat.box(7.8, 0.28, 98, .hex(0x2E5F86), chamfer: 0.1, metal: 0.3, rough: 0.45)
        canopy.position = SCNVector3(6.1, 4.5, 0)
        n.addChildNode(canopy)
        let canopyEdge = Mat.box(8.0, 0.14, 99, .hex(0xE8EDF2), chamfer: 0.05, rough: 0.5)
        canopyEdge.position = SCNVector3(6.1, 4.32, 0)
        n.addChildNode(canopyEdge)

        var z: Float = -46
        while z <= 46 {
            let p = SCNNode(geometry: SCNCylinder(radius: 0.13, height: 3.6))
            p.geometry?.firstMaterial = Mat.pbr(.hex(0xB9BFC5), metal: 0.65, rough: 0.35)
            p.position = SCNVector3(8.8, 2.8, z)
            n.addChildNode(p)
            let lamp = Mat.box(1.1, 0.1, 0.55, .hex(0xFFF6DC), chamfer: 0.03)
            lamp.geometry?.firstMaterial = Mat.glow(.hex(0xFFF3D0), strength: 0.65)
            lamp.position = SCNVector3(5.5, 4.28, z)
            n.addChildNode(lamp)
            z += 15
        }

        let benchColors: [UIColor] = [.hex(0x2E86C1), .hex(0x2E86C1), .hex(0x6B4A2C)]
        for (i, bz) in [Float(-32), Float(0), Float(32)].enumerated() {
            let bench = Mat.box(0.62, 0.12, 2.1, benchColors[i], chamfer: 0.04, rough: 0.85)
            bench.position = SCNVector3(7.9, 1.5, bz)
            n.addChildNode(bench)
            let back = Mat.box(0.12, 0.55, 2.1, benchColors[i], chamfer: 0.04, rough: 0.85)
            back.position = SCNVector3(8.24, 1.8, bz)
            n.addChildNode(back)
            let legL = Mat.box(0.5, 0.5, 0.1, .hex(0x3A4048), chamfer: 0.02, metal: 0.5, rough: 0.5)
            legL.position = SCNVector3(7.9, 1.25, bz - 0.9)
            n.addChildNode(legL)
            let legR = legL.clone()
            legR.position = SCNVector3(7.9, 1.25, bz + 0.9)
            n.addChildNode(legR)
        }

        let coats: [UIColor] = [.hex(0xC0392B), .hex(0x2C6DBE), .hex(0x2FA35A), .hex(0xE8C13A),
                                .hex(0x8E44AD), .hex(0xE67E22), .hex(0x34495E)]
        var rng = SystemRandomNumberGenerator()
        for i in 0..<9 {
            let pnode = person(coats[i % coats.count])
            let px = Float.random(in: 3.4...8.2, using: &rng)
            let pz = Float.random(in: -50...50, using: &rng)
            pnode.position = SCNVector3(px, 1.0, pz)
            pnode.eulerAngles.y = Float.random(in: -3.1...3.1, using: &rng)
            n.addChildNode(pnode)
        }

        for sz in [Float(-26), Float(26)] {
            let sign = Mat.label(s.name(lang), w: 4.4, h: 0.95, bg: .hex(0x123C6E), fg: .white, font: 110, both: false)
            sign.position = SCNVector3(2.7, 3.15, sz)
            sign.eulerAngles.y = -.pi / 2
            n.addChildNode(sign)
            let post = Mat.box(0.1, 2.3, 0.1, .hex(0xB9BFC5), chamfer: 0.02, metal: 0.6, rough: 0.4)
            post.position = SCNVector3(2.7, 2.05, sz)
            n.addChildNode(post)
        }

        let hall = Mat.box(15, 7.5, 22, .hex(0xE3DACB), chamfer: 0.2, rough: 0.85)
        hall.position = SCNVector3(19, 3.75, 0)
        n.addChildNode(hall)
        let hallRoof = Mat.box(16, 0.7, 23, .hex(0x8A3B32), chamfer: 0.2, rough: 0.8)
        hallRoof.position = SCNVector3(19, 7.8, 0)
        n.addChildNode(hallRoof)
        for wz in [Float(-7), Float(0), Float(7)] {
            let win = Mat.box(15.2, 2.2, 3.0, .hex(0x2A3A48), chamfer: 0.1, metal: 0.5, rough: 0.2)
            win.position = SCNVector3(19, 4.2, wz)
            n.addChildNode(win)
        }
        let entry = Mat.box(0.3, 3.0, 3.2, .hex(0x1D3F8C), chamfer: 0.05, rough: 0.4)
        entry.position = SCNVector3(11.6, 1.5, 0)
        n.addChildNode(entry)

        n.position = SCNVector3(0, 0, -Float(s.pos))
        return n
    }
}
