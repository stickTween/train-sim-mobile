import SceneKit
import UIKit

struct Station {
    let ru: String
    let en: String
    let pos: Double
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
}

enum WorldBuilder {
    static let stations: [Station] = [
        Station(ru: "Заречная", en: "Zarechnaya", pos: 950),
        Station(ru: "Северный Парк", en: "North Park", pos: 2500),
        Station(ru: "Лесная", en: "Lesnaya", pos: 4200),
        Station(ru: "Приморская", en: "Primorskaya", pos: 6100)
    ]
    static let length: Double = 7400

    static func build(_ lang: Lang) -> SCNNode {
        let root = SCNNode()

        let floor = SCNFloor()
        floor.reflectivity = 0
        floor.firstMaterial = Mat.pbr(.hex(0x5F8B45), rough: 1)
        root.addChildNode(SCNNode(geometry: floor))

        let zStart: CGFloat = 200
        let zEnd: CGFloat = -CGFloat(length)
        let mid = Float((zStart + zEnd) / 2)
        let span = CGFloat(zStart - zEnd)

        let bed = Mat.box(12, 0.5, span, .hex(0x6F6A61), chamfer: 0, rough: 1)
        bed.position = SCNVector3(0, 0.25, mid)
        root.addChildNode(bed)

        let sleepers = SCNNode()
        var z = Float(zStart)
        while z > Float(zEnd) {
            let sl = Mat.box(2.7, 0.16, 0.28, .hex(0x4A4038), chamfer: 0.02, rough: 1)
            sl.position = SCNVector3(0, 0.55, z)
            sleepers.addChildNode(sl)
            let sl2 = sl.clone()
            sl2.position = SCNVector3(-9, 0.55, z)
            sleepers.addChildNode(sl2)
            z -= 5
        }
        root.addChildNode(sleepers.flattenedClone())

        for x in [Float(-0.72), Float(0.72), Float(-9.72), Float(-8.28)] {
            let rail = Mat.box(0.14, 0.18, span, .hex(0x8A8F94), chamfer: 0.02, metal: 0.9, rough: 0.3)
            rail.position = SCNVector3(x, 0.68, mid)
            root.addChildNode(rail)
        }

        let poles = SCNNode()
        var pz = Float(zStart)
        while pz > Float(zEnd) {
            let pole = Mat.box(0.22, 8.5, 0.22, .hex(0x7E848A), chamfer: 0.03, metal: 0.5, rough: 0.5)
            pole.position = SCNVector3(4.6, 4.25, pz)
            poles.addChildNode(pole)
            let arm = Mat.box(4.4, 0.16, 0.16, .hex(0x7E848A), chamfer: 0.03, metal: 0.5, rough: 0.5)
            arm.position = SCNVector3(2.5, 8.2, pz)
            poles.addChildNode(arm)
            pz -= 55
        }
        root.addChildNode(poles.flattenedClone())

        let wire = Mat.box(0.05, 0.05, span, .hex(0x3E4348), chamfer: 0, metal: 0.7, rough: 0.4)
        wire.position = SCNVector3(0, 7.4, mid)
        root.addChildNode(wire)

        root.addChildNode(scenery())

        for s in stations {
            root.addChildNode(station(s, lang))
        }

        return root
    }

    private static func scenery() -> SCNNode {
        let group = SCNNode()
        var rng = SystemRandomNumberGenerator()
        var z: Float = 150
        let greens: [UIColor] = [.hex(0x2F6B32), .hex(0x3C7A38), .hex(0x26582B), .hex(0x497F3A)]
        while z > -Float(length) {
            let count = Int.random(in: 1...3, using: &rng)
            for _ in 0..<count {
                let side: Float = Bool.random(using: &rng) ? 1 : -1
                let x = side * Float.random(in: 16...70, using: &rng)
                let hgt = CGFloat.random(in: 4...9, using: &rng)
                let tree = SCNNode()
                let trunk = Mat.box(0.5, hgt * 0.4, 0.5, .hex(0x5A4028), chamfer: 0.05, rough: 1)
                trunk.position = SCNVector3(0, Float(hgt * 0.2), 0)
                tree.addChildNode(trunk)
                let crown = SCNNode(geometry: SCNCone(topRadius: 0, bottomRadius: hgt * 0.32, height: hgt * 0.85))
                crown.geometry?.firstMaterial = Mat.pbr(greens.randomElement(using: &rng)!, rough: 1)
                crown.position = SCNVector3(0, Float(hgt * 0.4 + hgt * 0.42), 0)
                tree.addChildNode(crown)
                tree.position = SCNVector3(x, 0, z)
                group.addChildNode(tree)
            }
            if Int.random(in: 0...4, using: &rng) == 0 {
                let colors: [UIColor] = [.hex(0xC9B79B), .hex(0xB9A98F), .hex(0xD8C9A8), .hex(0xA8B4C0)]
                let w = CGFloat.random(in: 8...18, using: &rng)
                let hh = CGFloat.random(in: 6...16, using: &rng)
                let b = Mat.box(w, hh, w * 0.8, colors.randomElement(using: &rng)!, chamfer: 0.1, rough: 0.9)
                let side: Float = Bool.random(using: &rng) ? 1 : -1
                b.position = SCNVector3(side * Float.random(in: 40...95, using: &rng), Float(hh / 2), z)
                group.addChildNode(b)
                let roof = Mat.box(w + 0.6, 0.5, w * 0.8 + 0.6, .hex(0x8A3B32), chamfer: 0.1, rough: 0.9)
                roof.position = SCNVector3(b.position.x, Float(hh) + 0.25, z)
                group.addChildNode(roof)
            }
            z -= Float.random(in: 18...34, using: &rng)
        }
        return group.flattenedClone()
    }

    private static func station(_ s: Station, _ lang: Lang) -> SCNNode {
        let n = SCNNode()

        let plat = Mat.box(8, 1.0, 130, .hex(0xBDB7AE), chamfer: 0.05, rough: 0.9)
        plat.position = SCNVector3(5.7, 0.5, 0)
        n.addChildNode(plat)

        let edge = Mat.box(0.55, 0.14, 130, .hex(0xEFC93E), chamfer: 0.02, rough: 0.6)
        edge.position = SCNVector3(1.95, 1.03, 0)
        n.addChildNode(edge)

        let canopy = Mat.box(7.6, 0.3, 96, .hex(0x2E5F86), chamfer: 0.1, rough: 0.5)
        canopy.position = SCNVector3(6.0, 4.4, 0)
        n.addChildNode(canopy)

        var z: Float = -44
        while z <= 44 {
            let p = Mat.box(0.28, 3.5, 0.28, .hex(0xB9BFC5), chamfer: 0.03, metal: 0.6, rough: 0.4)
            p.position = SCNVector3(8.6, 2.75, z)
            n.addChildNode(p)
            let lamp = Mat.box(1.0, 0.12, 0.5, .hex(0xFFF6DC), chamfer: 0.03)
            lamp.geometry?.firstMaterial = Mat.glow(.hex(0xFFF3D0))
            lamp.position = SCNVector3(5.4, 4.18, z)
            n.addChildNode(lamp)
            z += 16
        }

        for bz in [Float(-30), Float(0), Float(30)] {
            let bench = Mat.box(0.6, 0.12, 2.0, .hex(0x6B4A2C), chamfer: 0.04, rough: 0.9)
            bench.position = SCNVector3(7.8, 1.5, bz)
            n.addChildNode(bench)
            let back = Mat.box(0.12, 0.55, 2.0, .hex(0x6B4A2C), chamfer: 0.04, rough: 0.9)
            back.position = SCNVector3(8.15, 1.8, bz)
            n.addChildNode(back)
        }

        for sz in [Float(-24), Float(24)] {
            let sign = Mat.label(s.name(lang), w: 4.2, h: 0.9, bg: .hex(0x123C6E), fg: .white, font: 110)
            sign.position = SCNVector3(2.6, 3.1, sz)
            sign.eulerAngles.y = -.pi / 2
            n.addChildNode(sign)
            let post = Mat.box(0.12, 2.2, 0.12, .hex(0xB9BFC5), chamfer: 0.02, metal: 0.6, rough: 0.4)
            post.position = SCNVector3(2.6, 2.0, sz)
            n.addChildNode(post)
        }

        let hall = Mat.box(14, 7, 20, .hex(0xE3DACB), chamfer: 0.2, rough: 0.8)
        hall.position = SCNVector3(18, 3.5, 0)
        n.addChildNode(hall)
        let hallRoof = Mat.box(15, 0.6, 21, .hex(0x8A3B32), chamfer: 0.2, rough: 0.8)
        hallRoof.position = SCNVector3(18, 7.3, 0)
        n.addChildNode(hallRoof)

        n.position = SCNVector3(0, 0, -Float(s.pos))
        return n
    }
}
