import UIKit

final class PixelBuffer {
    let width: Int
    let height: Int
    let ctx: CGContext

    init?(width: Int, height: Int) {
        self.width = width
        self.height = height
        let info = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        guard let c = CGContext(data: nil, width: width, height: height, bitsPerComponent: 8,
                                bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: info) else { return nil }
        ctx = c
        ctx.interpolationQuality = .none
    }

    func begin() {
        ctx.saveGState()
        ctx.translateBy(x: 0, y: CGFloat(height))
        ctx.scaleBy(x: 1, y: -1)
        ctx.setShouldAntialias(false)
        UIGraphicsPushContext(ctx)
    }

    func end() -> CGImage? {
        UIGraphicsPopContext()
        ctx.restoreGState()
        return ctx.makeImage()
    }
}

struct Pix {
    let ctx: CGContext
    let width: Int
    let height: Int

    func fill(_ c: UIColor) {
        rect(0, 0, width, height, c)
    }

    func rect(_ x: Int, _ y: Int, _ w: Int, _ h: Int, _ c: UIColor) {
        guard w > 0, h > 0 else { return }
        ctx.setFillColor(c.cgColor)
        ctx.fill(CGRect(x: CGFloat(x), y: CGFloat(y), width: CGFloat(w), height: CGFloat(h)))
    }

    func frame(_ x: Int, _ y: Int, _ w: Int, _ h: Int, _ c: UIColor, _ t: Int = 1) {
        rect(x, y, w, t, c)
        rect(x, y + h - t, w, t, c)
        rect(x, y, t, h, c)
        rect(x + w - t, y, t, h, c)
    }

    func bevel(_ x: Int, _ y: Int, _ w: Int, _ h: Int, face: UIColor, light: UIColor, dark: UIColor) {
        rect(x, y, w, h, face)
        rect(x, y, w, 1, light)
        rect(x, y, 1, h, light)
        rect(x, y + h - 1, w, 1, dark)
        rect(x + w - 1, y, 1, h, dark)
    }

    func circle(_ cx: Int, _ cy: Int, _ r: Int, _ c: UIColor) {
        guard r > 0 else { return }
        ctx.setFillColor(c.cgColor)
        ctx.fillEllipse(in: CGRect(x: CGFloat(cx - r), y: CGFloat(cy - r),
                                   width: CGFloat(r * 2), height: CGFloat(r * 2)))
    }

    func poly(_ pts: [(Int, Int)], _ c: UIColor) {
        guard pts.count > 2 else { return }
        ctx.beginPath()
        ctx.move(to: CGPoint(x: CGFloat(pts[0].0), y: CGFloat(pts[0].1)))
        for p in pts.dropFirst() {
            ctx.addLine(to: CGPoint(x: CGFloat(p.0), y: CGFloat(p.1)))
        }
        ctx.closePath()
        ctx.setFillColor(c.cgColor)
        ctx.fillPath()
    }

    func line(_ x0: Int, _ y0: Int, _ x1: Int, _ y1: Int, _ c: UIColor, _ t: Int = 1) {
        var x = x0, y = y0
        let dx = abs(x1 - x0), dy = -abs(y1 - y0)
        let sx = x0 < x1 ? 1 : -1
        let sy = y0 < y1 ? 1 : -1
        var err = dx + dy
        var guardCount = 0
        while guardCount < 4000 {
            guardCount += 1
            rect(x, y, t, t, c)
            if x == x1 && y == y1 { break }
            let e2 = 2 * err
            if e2 >= dy { err += dy; x += sx }
            if e2 <= dx { err += dx; y += sy }
        }
    }

    func polar(_ cx: Int, _ cy: Int, _ r: Double, _ angle: Double) -> (Int, Int) {
        (cx + Int((cos(angle) * r).rounded()), cy + Int((sin(angle) * r).rounded()))
    }

    func gradientV(_ x: Int, _ y: Int, _ w: Int, _ h: Int, _ top: UIColor, _ bottom: UIColor, steps: Int = 0) {
        guard h > 0 else { return }
        let n = steps > 0 ? steps : h
        var t0: CGFloat = 0, t1: CGFloat = 0, t2: CGFloat = 0, ta: CGFloat = 0
        var b0: CGFloat = 0, b1: CGFloat = 0, b2: CGFloat = 0, ba: CGFloat = 0
        top.getRed(&t0, green: &t1, blue: &t2, alpha: &ta)
        bottom.getRed(&b0, green: &b1, blue: &b2, alpha: &ba)
        for i in 0..<n {
            let f = CGFloat(i) / CGFloat(max(1, n - 1))
            let c = UIColor(red: t0 + (b0 - t0) * f,
                            green: t1 + (b1 - t1) * f,
                            blue: t2 + (b2 - t2) * f, alpha: 1)
            let sy = y + i * h / n
            let ey = y + (i + 1) * h / n
            rect(x, sy, w, max(1, ey - sy), c)
        }
    }

    func text(_ s: String, _ x: Int, _ y: Int, size: CGFloat, color: UIColor,
              align: TextAlign = .left, weight: UIFont.Weight = .bold, mono: Bool = false) {
        let font = mono
            ? UIFont.monospacedSystemFont(ofSize: size, weight: weight)
            : UIFont.systemFont(ofSize: size, weight: weight)
        let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color]
        let str = NSString(string: s)
        let sz = str.size(withAttributes: attrs)
        var dx = CGFloat(x)
        switch align {
        case .left: break
        case .center: dx -= sz.width / 2
        case .right: dx -= sz.width
        }
        ctx.setShouldAntialias(true)
        str.draw(at: CGPoint(x: dx.rounded(), y: CGFloat(y)), withAttributes: attrs)
        ctx.setShouldAntialias(false)
    }

    func textWidth(_ s: String, size: CGFloat, weight: UIFont.Weight = .bold, mono: Bool = false) -> Int {
        let font = mono
            ? UIFont.monospacedSystemFont(ofSize: size, weight: weight)
            : UIFont.systemFont(ofSize: size, weight: weight)
        return Int(NSString(string: s).size(withAttributes: [.font: font]).width.rounded())
    }

    private static let segMasks: [[Bool]] = [
        [true, true, true, true, true, true, false],
        [false, true, true, false, false, false, false],
        [true, true, false, true, true, false, true],
        [true, true, true, true, false, false, true],
        [false, true, true, false, false, true, true],
        [true, false, true, true, false, true, true],
        [true, false, true, true, true, true, true],
        [true, true, true, false, false, false, false],
        [true, true, true, true, true, true, true],
        [true, true, true, true, false, true, true]
    ]

    func seg7(_ digit: Int, _ x: Int, _ y: Int, _ w: Int, _ h: Int,
              on: UIColor, off: UIColor?) {
        let t = max(1, w / 5)
        let vh = (h - 3 * t) / 2
        let mask: [Bool] = (digit >= 0 && digit <= 9) ? Pix.segMasks[digit] : [Bool](repeating: false, count: 7)
        let rects: [(Int, Int, Int, Int)] = [
            (x + t, y, w - 2 * t, t),
            (x + w - t, y + t, t, vh),
            (x + w - t, y + 2 * t + vh, t, vh),
            (x + t, y + h - t, w - 2 * t, t),
            (x, y + 2 * t + vh, t, vh),
            (x, y + t, t, vh),
            (x + t, y + t + vh, w - 2 * t, t)
        ]
        for (i, r) in rects.enumerated() {
            if mask[i] {
                rect(r.0, r.1, r.2, r.3, on)
            } else if let o = off {
                rect(r.0, r.1, r.2, r.3, o)
            }
        }
    }

    func seg7Number(_ value: Int, digits: Int, _ x: Int, _ y: Int, _ dw: Int, _ dh: Int,
                    gap: Int, on: UIColor, off: UIColor?, leadingBlank: Bool = true) {
        var v = max(0, value)
        var out: [Int] = []
        for _ in 0..<digits {
            out.append(v % 10)
            v /= 10
        }
        out.reverse()
        var started = false
        for (i, d) in out.enumerated() {
            let dx = x + i * (dw + gap)
            let isLast = i == digits - 1
            if leadingBlank && !started && d == 0 && !isLast {
                if let o = off { seg7(-1, dx, y, dw, dh, on: on, off: o) }
                continue
            }
            started = true
            seg7(d, dx, y, dw, dh, on: on, off: off)
        }
    }
}

enum TextAlign {
    case left, center, right
}

extension UIColor {
    static func rgb(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 255) / 255,
                green: CGFloat((v >> 8) & 255) / 255,
                blue: CGFloat(v & 255) / 255, alpha: 1)
    }

    func shade(_ f: CGFloat) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        if f >= 0 {
            return UIColor(red: r + (1 - r) * f, green: g + (1 - g) * f, blue: b + (1 - b) * f, alpha: a)
        }
        let k = 1 + f
        return UIColor(red: r * k, green: g * k, blue: b * k, alpha: a)
    }
}
