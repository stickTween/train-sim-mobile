import SceneKit
import UIKit

enum TrainBuilder {

    static func build(_ s: TrainSpec, playerCab: Bool = false) -> SCNNode {
        let train = SCNNode()
        let gap: CGFloat = 0.7

        let head = headCar(s, front: true, details: !playerCab)
        train.addChildNode(head)

        var z: CGFloat = 0
        for _ in 0..<s.cars {
            z += s.length + gap
            let c = midCar(s)
            c.position = SCNVector3(0, 0, Float(z))
            train.addChildNode(c)
        }

        let tail = headCar(s, front: false, details: true)
        tail.eulerAngles.y = .pi
        tail.position = SCNVector3(0, 0, Float(z + gap))
        train.addChildNode(tail)

        return train
    }

    private static let floorY: CGFloat = 1.15

    static func headCar(_ s: TrainSpec, front: Bool, details: Bool) -> SCNNode {
        let car = SCNNode()
        let L = s.length, H = s.height, W = s.width, N = s.nose

        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: L - N * 0.08, y: 0))
        path.addQuadCurve(to: CGPoint(x: L, y: H * 0.34), controlPoint: CGPoint(x: L, y: H * 0.02))
        path.addQuadCurve(to: CGPoint(x: L - N, y: H), controlPoint: CGPoint(x: L - N * 0.32, y: H))
        path.addLine(to: CGPoint(x: 0, y: H))
        path.close()

        let shape = SCNShape(path: path, extrusionDepth: W)
        shape.chamferRadius = 0.16
        shape.materials = Array(repeating: Mat.pbr(s.body, metal: 0.35, rough: 0.28), count: 5)
        let shell = SCNNode(geometry: shape)
        shell.eulerAngles.y = .pi / 2
        shell.position = SCNVector3(0, Float(floorY), 0)
        car.addChildNode(shell)

        car.addChildNode(roofRidge(s, length: L - N - 1.4, offset: -(L - N - 1.4) / 2 - 0.6))
        car.addChildNode(stripes(s, length: L - N * 0.5, offset: -(L - N * 0.5) / 2))

        var z: CGFloat = 3.2
        while z < L - N - 1.0 {
            car.addChildNode(sideWindows(s, z: z, width: 1.5, height: 0.88))
            z += 2.3
        }

        let wsAngle = Float(atan2(Double(N * 0.75), Double(H * 0.62)))
        let wsHolder = SCNNode()
        wsHolder.eulerAngles.x = wsAngle
        let ws = SCNNode(geometry: SCNPlane(width: W * 0.88, height: 1.62))
        ws.geometry?.firstMaterial = Mat.outwardGlass(.hex(0x1E2C3A), alpha: 0.55)
        ws.eulerAngles.y = .pi
        wsHolder.addChildNode(ws)
        wsHolder.position = SCNVector3(0, Float(floorY + H * 0.71), -Float(L - N * 0.60))
        car.addChildNode(wsHolder)

        if details {
            let frame = SCNNode(geometry: SCNBox(width: W * 0.92, height: 1.72, length: 0.1, chamferRadius: 0.05))
            frame.geometry?.firstMaterial = Mat.pbr(.hex(0x1C2126), rough: 0.5)
            frame.eulerAngles.x = wsAngle
            frame.position = SCNVector3(0, Float(floorY + H * 0.71), -Float(L - N * 0.60) + 0.04)
            car.addChildNode(frame)

            for dx in [Float(-1), Float(1)] {
                let arm = Mat.box(0.045, 0.8, 0.045, .hex(0x14181C), chamfer: 0.02, rough: 0.5)
                arm.eulerAngles = SCNVector3(wsAngle, 0, dx * 0.4)
                arm.position = SCNVector3(dx * Float(W * 0.18), Float(floorY + H * 0.52), -Float(L - N * 0.55))
                car.addChildNode(arm)
                let blade = Mat.box(0.85, 0.045, 0.035, .hex(0x101317), chamfer: 0.014, rough: 0.6)
                blade.eulerAngles = SCNVector3(wsAngle, 0, dx * 0.4)
                blade.position = SCNVector3(dx * Float(W * 0.27), Float(floorY + H * 0.83), -Float(L - N * 0.71))
                car.addChildNode(blade)
            }
        }

        let noseBand = SCNNode(geometry: SCNBox(width: W * 0.94, height: 0.44, length: 1.6, chamferRadius: 0.2))
        noseBand.geometry?.firstMaterial = Mat.pbr(s.accent, metal: 0.3, rough: 0.3)
        noseBand.position = SCNVector3(0, Float(floorY + H * 0.13), -Float(L - 0.85))
        car.addChildNode(noseBand)

        let noseCap = SCNNode(geometry: SCNBox(width: W * 0.55, height: 0.3, length: 0.5, chamferRadius: 0.14))
        noseCap.geometry?.firstMaterial = Mat.pbr(s.stripe, metal: 0.3, rough: 0.3)
        noseCap.position = SCNVector3(0, Float(floorY + H * 0.24), -Float(L - 0.4))
        car.addChildNode(noseCap)

        for dx in [Float(-1), Float(1)] {
            let housing = SCNNode(geometry: SCNBox(width: 0.5, height: 0.26, length: 0.22, chamferRadius: 0.09))
            housing.geometry?.firstMaterial = Mat.pbr(.hex(0x1C2126), rough: 0.4)
            housing.position = SCNVector3(dx * Float(W * 0.28), Float(floorY + H * 0.22), -Float(L - 0.62))
            car.addChildNode(housing)

            let lamp = SCNNode(geometry: SCNSphere(radius: 0.13))
            lamp.name = "headlight"
            lamp.geometry?.firstMaterial = Mat.pbr(.hex(0xF3F4E8), rough: 0.08)
            lamp.position = SCNVector3(dx * Float(W * 0.28), Float(floorY + H * 0.22), -Float(L - 0.55))
            car.addChildNode(lamp)

            let tail = SCNNode(geometry: SCNSphere(radius: 0.075))
            tail.geometry?.firstMaterial = Mat.glow(.hex(0xC02020), strength: 0.7)
            tail.position = SCNVector3(dx * Float(W * 0.36), Float(floorY + H * 0.19), -Float(L - 0.5))
            car.addChildNode(tail)
        }

        let coupler = Mat.box(0.5, 0.3, 0.6, .hex(0x2A2E33), chamfer: 0.05, metal: 0.6, rough: 0.5)
        coupler.position = SCNVector3(0, Float(floorY) - 0.55, -Float(L) + 0.1)
        car.addChildNode(coupler)

        if front {
            for (i, dz) in [Float(-0.34), Float(0.34)].enumerated() {
                let leaf = SCNNode(geometry: SCNBox(width: 0.1, height: 2.02, length: 0.64, chamferRadius: 0.03))
                leaf.geometry?.firstMaterial = Mat.pbr(s.doorColor, metal: 0.2, rough: 0.32)
                leaf.name = "door\(i)"
                leaf.position = SCNVector3(Float(W / 2), Float(floorY + 1.05), -Float(L * 0.45) + dz)
                car.addChildNode(leaf)
            }
            let doorFrame = Mat.box(0.04, 2.16, 1.5, .hex(0x2B3138), chamfer: 0.02, rough: 0.55)
            doorFrame.position = SCNVector3(Float(W / 2) + 0.03, Float(floorY + 1.05), -Float(L * 0.45))
            car.addChildNode(doorFrame)
        }

        car.addChildNode(skirt(s, length: L))
        for bz in [L * 0.22, L * 0.78] {
            let b = bogie(s)
            b.position = SCNVector3(0, 0, -Float(bz))
            car.addChildNode(b)
        }
        car.addChildNode(roofKit(s, L: L, pantograph: false))
        return car
    }

    static func midCar(_ s: TrainSpec) -> SCNNode {
        let car = SCNNode()
        let L = s.length, H = s.height, W = s.width

        let body = SCNNode(geometry: SCNBox(width: W, height: H, length: L, chamferRadius: 0.36))
        body.geometry?.firstMaterial = Mat.pbr(s.body, metal: 0.35, rough: 0.28)
        body.position = SCNVector3(0, Float(floorY + H / 2), -Float(L / 2))
        car.addChildNode(body)

        car.addChildNode(roofRidge(s, length: L - 1.2, offset: -L / 2))
        car.addChildNode(stripes(s, length: L, offset: -L / 2))

        var z: CGFloat = 1.7
        while z < L - 1.2 {
            car.addChildNode(sideWindows(s, z: z, width: 1.6, height: 0.92))
            z += 2.4
        }

        for dz in [L * 0.28, L * 0.72] {
            for dx in [-1, 1] as [CGFloat] {
                let leaf = SCNNode(geometry: SCNBox(width: 0.09, height: 2.02, length: 1.3, chamferRadius: 0.04))
                leaf.geometry?.firstMaterial = Mat.pbr(s.doorColor, metal: 0.2, rough: 0.32)
                leaf.position = SCNVector3(Float(dx * W / 2), Float(floorY + 1.05), -Float(dz))
                car.addChildNode(leaf)
                let strip = SCNNode(geometry: SCNBox(width: 0.03, height: 0.08, length: 1.34, chamferRadius: 0.01))
                strip.geometry?.firstMaterial = Mat.pbr(.hex(0xE8C13A), rough: 0.5)
                strip.position = SCNVector3(Float(dx * (W / 2 + 0.04)), Float(floorY + 0.12), -Float(dz))
                car.addChildNode(strip)
            }
        }

        car.addChildNode(skirt(s, length: L))
        for bz in [L * 0.2, L * 0.8] {
            let b = bogie(s)
            b.position = SCNVector3(0, 0, -Float(bz))
            car.addChildNode(b)
        }
        car.addChildNode(roofKit(s, L: L, pantograph: true))
        return car
    }

    private static func sideWindows(_ s: TrainSpec, z: CGFloat, width: CGFloat, height: CGFloat) -> SCNNode {
        let n = SCNNode()
        let W = s.width, H = s.height
        for dx in [Float(-1), Float(1)] {
            let holder = SCNNode()
            let glass = SCNNode(geometry: SCNPlane(width: width, height: height))
            glass.geometry?.firstMaterial = Mat.outwardGlass(.hex(0x243240), alpha: 0.62)
            glass.eulerAngles.y = dx > 0 ? .pi / 2 : -.pi / 2
            holder.addChildNode(glass)
            holder.position = SCNVector3(dx * Float(W / 2 + 0.012), Float(floorY + H * 0.62), -Float(z))
            n.addChildNode(holder)

            let frame = SCNNode(geometry: SCNBox(width: 0.03, height: height + 0.1, length: width + 0.1, chamferRadius: 0.04))
            frame.geometry?.firstMaterial = Mat.pbr(.hex(0x2B3138), rough: 0.5)
            frame.position = SCNVector3(dx * Float(W / 2 + 0.004), Float(floorY + H * 0.62), -Float(z))
            n.addChildNode(frame)
        }
        return n
    }

    private static func stripes(_ s: TrainSpec, length: CGFloat, offset: CGFloat) -> SCNNode {
        let n = SCNNode()
        let W = s.width, H = s.height
        let main = Mat.box(W + 0.05, 0.36, length, s.stripe, chamfer: 0.05, metal: 0.2, rough: 0.35)
        main.position = SCNVector3(0, Float(floorY + H * 0.30), Float(offset))
        n.addChildNode(main)
        let thin = Mat.box(W + 0.06, 0.09, length, s.accent, chamfer: 0.03, metal: 0.2, rough: 0.35)
        thin.position = SCNVector3(0, Float(floorY + H * 0.19), Float(offset))
        n.addChildNode(thin)
        return n
    }

    private static func roofRidge(_ s: TrainSpec, length: CGFloat, offset: CGFloat) -> SCNNode {
        let roof = Mat.box(s.width - 0.5, 0.24, length, s.roof, chamfer: 0.1, rough: 0.55)
        roof.position = SCNVector3(0, Float(floorY + s.height) - 0.03, Float(offset))
        return roof
    }

    private static func skirt(_ s: TrainSpec, length: CGFloat) -> SCNNode {
        let n = Mat.box(s.width - 0.22, 0.88, length - 0.6, s.skirt, chamfer: 0.08, rough: 0.75)
        n.position = SCNVector3(0, Float(floorY) - 0.44, -Float(length / 2))
        return n
    }

    private static func roofKit(_ s: TrainSpec, L: CGFloat, pantograph: Bool) -> SCNNode {
        let n = SCNNode()
        let y = Float(floorY + s.height) + 0.2
        for dz in [L * 0.33, L * 0.66] {
            let ac = Mat.box(s.width - 1.2, 0.3, 2.1, .hex(0x767E86), chamfer: 0.09, metal: 0.3, rough: 0.55)
            ac.position = SCNVector3(0, y, -Float(dz))
            n.addChildNode(ac)
        }
        if pantograph {
            let panto = SCNNode()
            let base = Mat.box(1.7, 0.15, 1.2, .hex(0x4A5058), chamfer: 0.03, metal: 0.4, rough: 0.5)
            panto.addChildNode(base)
            let lower = Mat.box(0.09, 1.2, 0.09, .hex(0x9AA1A8), chamfer: 0.02, metal: 0.8, rough: 0.25)
            lower.eulerAngles.x = 0.65
            lower.position = SCNVector3(0, 0.58, -0.28)
            panto.addChildNode(lower)
            let upper = Mat.box(0.07, 1.0, 0.07, .hex(0x9AA1A8), chamfer: 0.02, metal: 0.8, rough: 0.25)
            upper.eulerAngles.x = -0.5
            upper.position = SCNVector3(0, 1.28, -0.72)
            panto.addChildNode(upper)
            let bar = Mat.box(1.6, 0.07, 0.14, .hex(0xC9CFD5), chamfer: 0.03, metal: 0.9, rough: 0.2)
            bar.position = SCNVector3(0, 1.74, -0.94)
            panto.addChildNode(bar)
            let insA = SCNNode(geometry: SCNCylinder(radius: 0.08, height: 0.3))
            insA.geometry?.firstMaterial = Mat.pbr(.hex(0x8B5E3C), rough: 0.45)
            insA.position = SCNVector3(-0.6, 0.22, 0.35)
            panto.addChildNode(insA)
            let insB = insA.clone()
            insB.position = SCNVector3(0.6, 0.22, 0.35)
            panto.addChildNode(insB)
            panto.position = SCNVector3(0, y, -Float(L * 0.5))
            n.addChildNode(panto)
        }
        return n
    }

    private static func bogie(_ s: TrainSpec) -> SCNNode {
        let n = SCNNode()
        let frame = Mat.box(s.width - 0.9, 0.52, 2.8, .hex(0x2B2F35), chamfer: 0.06, metal: 0.6, rough: 0.5)
        frame.position = SCNVector3(0, 0.84, 0)
        n.addChildNode(frame)
        for dz in [Float(-0.98), Float(0.98)] {
            for dx in [Float(-1), Float(1)] {
                let x = dx * Float(s.width / 2 - 0.28)
                let tyre = SCNNode(geometry: SCNCylinder(radius: 0.47, height: 0.15))
                tyre.geometry?.firstMaterial = Mat.pbr(.hex(0x1F2328), metal: 0.85, rough: 0.4)
                tyre.eulerAngles.z = .pi / 2
                tyre.position = SCNVector3(x, 0.47, dz)
                n.addChildNode(tyre)
                let disc = SCNNode(geometry: SCNCylinder(radius: 0.3, height: 0.18))
                disc.geometry?.firstMaterial = Mat.pbr(.hex(0x767E86), metal: 0.9, rough: 0.22)
                disc.eulerAngles.z = .pi / 2
                disc.position = SCNVector3(x, 0.47, dz)
                n.addChildNode(disc)
                let spring = SCNNode(geometry: SCNCylinder(radius: 0.09, height: 0.28))
                spring.geometry?.firstMaterial = Mat.pbr(.hex(0x4A5058), metal: 0.7, rough: 0.4)
                spring.position = SCNVector3(x, 0.74, dz)
                n.addChildNode(spring)
            }
        }
        return n
    }
}
