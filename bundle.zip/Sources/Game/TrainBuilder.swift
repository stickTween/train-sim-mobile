import SceneKit
import UIKit

enum TrainBuilder {

    static func build(_ s: TrainSpec) -> SCNNode {
        let train = SCNNode()
        let gap: CGFloat = 0.7

        let head = headCar(s, front: true)
        head.position = SCNVector3(0, 0, 0)
        train.addChildNode(head)

        var z: CGFloat = 0
        for _ in 0..<s.cars {
            z += s.length + gap
            let c = midCar(s)
            c.position = SCNVector3(0, 0, Float(z))
            train.addChildNode(c)
        }

        let tail = headCar(s, front: false)
        tail.eulerAngles.y = .pi
        tail.position = SCNVector3(0, 0, Float(z + gap))
        train.addChildNode(tail)

        return train
    }

    static func headCar(_ s: TrainSpec, front: Bool) -> SCNNode {
        let car = SCNNode()
        let L = s.length, H = s.height, W = s.width, N = s.nose
        let floorY: CGFloat = 1.15

        let p = UIBezierPath()
        p.move(to: CGPoint(x: 0, y: 0))
        p.addLine(to: CGPoint(x: L - N * 0.08, y: 0))
        p.addQuadCurve(to: CGPoint(x: L, y: H * 0.34), controlPoint: CGPoint(x: L, y: H * 0.02))
        p.addQuadCurve(to: CGPoint(x: L - N, y: H), controlPoint: CGPoint(x: L - N * 0.32, y: H))
        p.addLine(to: CGPoint(x: 0, y: H))
        p.close()

        let shape = SCNShape(path: p, extrusionDepth: W)
        shape.chamferRadius = 0.14
        shape.materials = Array(repeating: Mat.pbr(s.body, metal: 0.25, rough: 0.35), count: 5)
        let shell = SCNNode(geometry: shape)
        shell.eulerAngles.y = .pi / 2
        shell.position = SCNVector3(0, Float(floorY), 0)
        car.addChildNode(shell)

        let roof = Mat.box(W - 0.5, 0.22, L - N - 1.5, s.roof, chamfer: 0.1, rough: 0.5)
        roof.position = SCNVector3(0, Float(floorY + H) - 0.02, -Float((L - N - 1.5) / 2) - 0.6)
        car.addChildNode(roof)

        let stripe = Mat.box(W + 0.05, 0.34, L - N * 0.55, s.stripe, chamfer: 0.05, rough: 0.4)
        stripe.position = SCNVector3(0, Float(floorY + H * 0.30), -Float((L - N * 0.55) / 2))
        car.addChildNode(stripe)

        let thin = Mat.box(W + 0.06, 0.10, L - N * 0.55, s.accent, chamfer: 0.03, rough: 0.4)
        thin.position = SCNVector3(0, Float(floorY + H * 0.20), -Float((L - N * 0.55) / 2))
        car.addChildNode(thin)

        var z: CGFloat = 3.0
        while z < L - N - 1.0 {
            let win = SCNNode(geometry: SCNBox(width: W + 0.03, height: 0.86, length: 1.5, chamferRadius: 0.14))
            win.geometry?.firstMaterial = Mat.clearGlass()
            win.position = SCNVector3(0, Float(floorY + H * 0.62), -Float(z))
            car.addChildNode(win)
            z += 2.3
        }

        let wsAngle = Float(atan2(Double(N * 0.75), Double(H * 0.62)))
        let ws = SCNNode(geometry: SCNBox(width: W * 0.86, height: 1.55, length: 0.18, chamferRadius: 0.09))
        ws.geometry?.firstMaterial = Mat.clearGlass()
        ws.eulerAngles.x = wsAngle
        ws.position = SCNVector3(0, Float(floorY + H * 0.70), -Float(L - N * 0.62))
        car.addChildNode(ws)

        let noseBand = SCNNode(geometry: SCNBox(width: W * 0.92, height: 0.42, length: 1.5, chamferRadius: 0.18))
        noseBand.geometry?.firstMaterial = Mat.pbr(s.accent, metal: 0.3, rough: 0.35)
        noseBand.position = SCNVector3(0, Float(floorY + H * 0.14), -Float(L - 0.8))
        car.addChildNode(noseBand)

        for dx in [Float(-1), Float(1)] {
            let wiperArm = SCNNode(geometry: SCNBox(width: 0.05, height: 0.85, length: 0.05, chamferRadius: 0.02))
            wiperArm.geometry?.firstMaterial = Mat.pbr(.hex(0x15181C), rough: 0.5)
            wiperArm.eulerAngles = SCNVector3(wsAngle, 0, dx * 0.45)
            wiperArm.position = SCNVector3(dx * Float(W * 0.20), Float(floorY + H * 0.55), -Float(L - N * 0.55))
            car.addChildNode(wiperArm)

            let blade = SCNNode(geometry: SCNBox(width: 0.9, height: 0.05, length: 0.04, chamferRadius: 0.015))
            blade.geometry?.firstMaterial = Mat.pbr(.hex(0x101317), rough: 0.6)
            blade.eulerAngles = SCNVector3(wsAngle, 0, dx * 0.45)
            blade.position = SCNVector3(dx * Float(W * 0.30), Float(floorY + H * 0.86), -Float(L - N * 0.72))
            car.addChildNode(blade)
        }

        for dx in [-1, 1] as [Float] {
            let lamp = SCNNode(geometry: SCNSphere(radius: 0.19))
            lamp.name = "headlight"
            lamp.geometry?.firstMaterial = Mat.pbr(.hex(0xF7F7E8), rough: 0.1)
            lamp.position = SCNVector3(dx * Float(W * 0.30), Float(floorY + H * 0.20), -Float(L - 0.55))
            car.addChildNode(lamp)

            let tail = SCNNode(geometry: SCNSphere(radius: 0.10))
            tail.geometry?.firstMaterial = Mat.glow(.hex(0xB01818))
            tail.position = SCNVector3(dx * Float(W * 0.36), Float(floorY + H * 0.20), -Float(L - 0.5))
            car.addChildNode(tail)
        }

        if front {
            for (i, dz) in [Float(-0.32), Float(0.32)].enumerated() {
                let d = SCNNode(geometry: SCNBox(width: 0.09, height: 2.05, length: 0.62, chamferRadius: 0.03))
                d.geometry?.firstMaterial = Mat.pbr(s.stripe, metal: 0.2, rough: 0.35)
                d.name = "door\(i)"
                d.position = SCNVector3(Float(W / 2), Float(floorY + 1.05), -Float(L * 0.45) + dz)
                car.addChildNode(d)
            }
        }

        car.addChildNode(skirt(s, floorY: floorY, length: L))
        for bz in [L * 0.22, L * 0.78] {
            let b = bogie(s)
            b.position = SCNVector3(0, 0, -Float(bz))
            car.addChildNode(b)
        }
        car.addChildNode(roofKit(s, floorY: floorY, L: L, N: N))
        return car
    }

    static func midCar(_ s: TrainSpec) -> SCNNode {
        let car = SCNNode()
        let L = s.length, H = s.height, W = s.width
        let floorY: CGFloat = 1.15

        let body = SCNNode(geometry: SCNBox(width: W, height: H, length: L, chamferRadius: 0.35))
        body.geometry?.firstMaterial = Mat.pbr(s.body, metal: 0.25, rough: 0.35)
        body.position = SCNVector3(0, Float(floorY + H / 2), -Float(L / 2))
        car.addChildNode(body)

        let roof = Mat.box(W - 0.5, 0.22, L - 1.2, s.roof, chamfer: 0.1, rough: 0.5)
        roof.position = SCNVector3(0, Float(floorY + H) - 0.02, -Float(L / 2))
        car.addChildNode(roof)

        let stripe = Mat.box(W + 0.05, 0.34, L, s.stripe, chamfer: 0.05, rough: 0.4)
        stripe.position = SCNVector3(0, Float(floorY + H * 0.30), -Float(L / 2))
        car.addChildNode(stripe)

        let thin = Mat.box(W + 0.06, 0.10, L, s.accent, chamfer: 0.03, rough: 0.4)
        thin.position = SCNVector3(0, Float(floorY + H * 0.20), -Float(L / 2))
        car.addChildNode(thin)

        var z: CGFloat = 1.6
        while z < L - 1.2 {
            let win = SCNNode(geometry: SCNBox(width: W + 0.03, height: 0.9, length: 1.6, chamferRadius: 0.15))
            win.geometry?.firstMaterial = Mat.glass()
            win.position = SCNVector3(0, Float(floorY + H * 0.62), -Float(z))
            car.addChildNode(win)
            z += 2.4
        }

        for dz in [L * 0.28, L * 0.72] {
            for dx in [-1, 1] as [CGFloat] {
                let d = SCNNode(geometry: SCNBox(width: 0.08, height: 2.05, length: 1.25, chamferRadius: 0.05))
                d.geometry?.firstMaterial = Mat.pbr(s.stripe, metal: 0.2, rough: 0.35)
                d.position = SCNVector3(Float(dx * W / 2), Float(floorY + 1.05), -Float(dz))
                car.addChildNode(d)
            }
        }

        car.addChildNode(skirt(s, floorY: floorY, length: L))
        for bz in [L * 0.2, L * 0.8] {
            let b = bogie(s)
            b.position = SCNVector3(0, 0, -Float(bz))
            car.addChildNode(b)
        }
        car.addChildNode(roofKit(s, floorY: floorY, L: L, N: 0))
        return car
    }

    private static func skirt(_ s: TrainSpec, floorY: CGFloat, length: CGFloat) -> SCNNode {
        let n = Mat.box(s.width - 0.25, 0.85, length - 0.6, .hex(0x3A4048), chamfer: 0.08, rough: 0.8)
        n.position = SCNVector3(0, Float(floorY) - 0.42, -Float(length / 2))
        return n
    }

    private static func roofKit(_ s: TrainSpec, floorY: CGFloat, L: CGFloat, N: CGFloat) -> SCNNode {
        let n = SCNNode()
        let y = Float(floorY + s.height) + 0.18
        for dz in [L * 0.35, L * 0.65] {
            let ac = Mat.box(s.width - 1.2, 0.28, 2.0, .hex(0x7C848D), chamfer: 0.08, rough: 0.6)
            ac.position = SCNVector3(0, y, -Float(dz))
            n.addChildNode(ac)
        }
        let panto = SCNNode()
        let base = Mat.box(1.6, 0.14, 1.1, .hex(0x50565E), chamfer: 0.03, rough: 0.5)
        panto.addChildNode(base)
        let arm = Mat.box(0.09, 1.1, 0.09, .hex(0x9AA1A8), chamfer: 0.02, metal: 0.8, rough: 0.3)
        arm.eulerAngles.x = 0.6
        arm.position = SCNVector3(0, 0.55, -0.2)
        panto.addChildNode(arm)
        let bar = Mat.box(1.5, 0.06, 0.12, .hex(0xC9CFD5), chamfer: 0.02, metal: 0.9, rough: 0.2)
        bar.position = SCNVector3(0, 1.08, -0.55)
        panto.addChildNode(bar)
        panto.position = SCNVector3(0, y, -Float(L * 0.52))
        n.addChildNode(panto)
        return n
    }

    private static func bogie(_ s: TrainSpec) -> SCNNode {
        let n = SCNNode()
        let frame = Mat.box(s.width - 0.9, 0.5, 2.7, .hex(0x2E3238), chamfer: 0.06, metal: 0.6, rough: 0.5)
        frame.position = SCNVector3(0, 0.82, 0)
        n.addChildNode(frame)
        for dz in [Float(-0.95), Float(0.95)] {
            for dx in [Float(-1), Float(1)] {
                let w = SCNNode(geometry: SCNCylinder(radius: 0.46, height: 0.14))
                w.geometry?.firstMaterial = Mat.pbr(.hex(0x24282D), metal: 0.9, rough: 0.35)
                w.eulerAngles.z = .pi / 2
                w.position = SCNVector3(dx * Float(s.width / 2 - 0.28), 0.46, dz)
                n.addChildNode(w)
                let disc = SCNNode(geometry: SCNCylinder(radius: 0.30, height: 0.17))
                disc.geometry?.firstMaterial = Mat.pbr(.hex(0x6E7378), metal: 0.9, rough: 0.25)
                disc.eulerAngles.z = .pi / 2
                disc.position = SCNVector3(dx * Float(s.width / 2 - 0.28), 0.46, dz)
                n.addChildNode(disc)
            }
        }
        return n
    }
}
