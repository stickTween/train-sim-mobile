import UIKit

enum DoorSide {
    case left
    case right
}

struct StationDef {
    let index: Int
    let city: Int
    let ru: String
    let en: String
    let pos: Double
    let side: DoorSide
    let central: Bool
    var platformLen: Double { central ? 360 : 280 }
    var platformStart: Double { pos - platformLen + 8 }
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
}

struct RouteDef: Identifiable {
    let id: String
    let ru: String
    let en: String
    let trainIDs: [String]
    let stops: [Int]
    let traffic: Int
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
    var reward: Int { 2 * stops.count }
}

struct Prop {
    let kind: Int
    let pos: Double
    let seed: Int
}

enum World {

    static let cityGap: Double = 17000
    static let cityNamesRU = ["Северогорск", "Лесной", "Приозёрск", "Южный"]
    static let cityNamesEN = ["Severogorsk", "Lesnoy", "Priozersk", "Yuzhny"]

    static let stationNamesRU: [[String]] = [
        ["Северогорск-Центральный", "Заводская", "Парковая", "Речная", "Ольховая", "Северная", "Гранитная"],
        ["Лесной-Центральный", "Сосновая", "Ключевая", "Берёзовая", "Полевая", "Дачная", "Заречная"],
        ["Приозёрск-Центральный", "Озёрная", "Маяковая", "Портовая", "Гаванская", "Чайковая", "Дюнная"],
        ["Южный-Центральный", "Виноградная", "Солнечная", "Абрикосовая", "Приморская", "Тополиная", "Южный Порт"]
    ]

    static let stationNamesEN: [[String]] = [
        ["Severogorsk Central", "Zavodskaya", "Parkovaya", "Rechnaya", "Olkhovaya", "Severnaya", "Granitnaya"],
        ["Lesnoy Central", "Sosnovaya", "Klyuchevaya", "Berezovaya", "Polevaya", "Dachnaya", "Zarechnaya"],
        ["Priozersk Central", "Ozernaya", "Mayakovaya", "Portovaya", "Gavanskaya", "Chaykovaya", "Dyunnaya"],
        ["Yuzhny Central", "Vinogradnaya", "Solnechnaya", "Abrikosovaya", "Primorskaya", "Topolinaya", "Yuzhny Port"]
    ]

    static let offsets: [Double] = [1500, 3000, 4500, 6000, 7500, 9000, 10500]

    static let stations: [StationDef] = {
        var out: [StationDef] = []
        var idx = 0
        for c in 0..<4 {
            for s in 0..<7 {
                out.append(StationDef(index: idx, city: c,
                                      ru: stationNamesRU[c][s], en: stationNamesEN[c][s],
                                      pos: Double(c) * cityGap + offsets[s],
                                      side: (idx % 2 == 0) ? .right : .left,
                                      central: s == 0))
                idx += 1
            }
        }
        return out
    }()

    static let lineLength: Double = 3 * cityGap + 12000

    static func cityName(_ c: Int, _ l: Lang) -> String {
        l == .ru ? cityNamesRU[c] : cityNamesEN[c]
    }

    static func nearestCentral(_ i: Int) -> Int { (i / 7) * 7 }

    static let routes: [RouteDef] = {
        var out: [RouteDef] = []
        for c in 0..<4 {
            let all = Array((c * 7)..<(c * 7 + 7))
            out.append(RouteDef(id: "city\(c)full",
                                ru: "\(cityNamesRU[c]): все станции",
                                en: "\(cityNamesEN[c]): all stops",
                                trainIDs: ["lastochka", "ivolga"],
                                stops: all, traffic: 2))
            out.append(RouteDef(id: "city\(c)short",
                                ru: "\(cityNamesRU[c]): короткий",
                                en: "\(cityNamesEN[c]): short run",
                                trainIDs: ["lastochka", "ivolga"],
                                stops: Array(all.prefix(3)), traffic: 1))
        }
        for c in 0..<3 {
            out.append(RouteDef(id: "exp\(c)",
                                ru: "\(cityNamesRU[c]) — \(cityNamesRU[c + 1])",
                                en: "\(cityNamesEN[c]) — \(cityNamesEN[c + 1])",
                                trainIDs: ["sapsan"],
                                stops: [c * 7, (c + 1) * 7],
                                traffic: 1))
        }
        out.append(RouteDef(id: "expFull",
                            ru: "\(cityNamesRU[0]) — \(cityNamesRU[3])",
                            en: "\(cityNamesEN[0]) — \(cityNamesEN[3])",
                            trainIDs: ["sapsan"],
                            stops: [0, 7, 14, 21],
                            traffic: 0))
        return out
    }()

    static func buildRoute(spec: TrainSpec, from a0: Int, to b0: Int) -> (RouteDef, Bool) {
        var a = min(max(0, a0), stations.count - 1)
        var b = min(max(0, b0), stations.count - 1)
        var adjusted = false
        if a > b {
            let t = a; a = b; b = t
            adjusted = true
        }
        if a == b {
            if b < stations.count - 1 { b += 1 } else { a -= 1 }
            adjusted = true
        }
        var stops: [Int]
        if spec.express {
            var ca = a, cb = b
            if !stations[ca].central { ca = nearestCentral(ca); adjusted = true }
            if !stations[cb].central { cb = nearestCentral(cb); adjusted = true }
            if ca > cb { let t = ca; ca = cb; cb = t }
            if ca == cb {
                if cb < 21 { cb += 7 } else { ca -= 7 }
                adjusted = true
            }
            stops = Array(stride(from: ca, through: cb, by: 7))
        } else {
            stops = Array(a...b)
        }
        let traffic: Int
        if spec.express {
            traffic = (stops.first == 0 && stops.last == 21) ? 0 : 1
        } else {
            traffic = stops.count > 7 ? 2 : 1
        }
        let f = stations[stops[0]]
        let l = stations[stops[stops.count - 1]]
        let route = RouteDef(id: "custom",
                             ru: "\(f.ru) — \(l.ru)",
                             en: "\(f.en) — \(l.en)",
                             trainIDs: [spec.id],
                             stops: stops, traffic: traffic)
        return (route, adjusted)
    }

    static func speedLimit(at d: Double, stops: [Int], maxSpeed: Double) -> Double {
        var limit = maxSpeed
        for i in stops {
            let st = stations[i]
            let delta = st.pos - d
            if delta > -60 && delta < 150 { limit = min(limit, 60) }
            else if delta >= 150 && delta < 340 { limit = min(limit, 90) }
        }
        return limit
    }

    static let rivers: [Double] = [13300, 30300, 47300]
    static let bridgeHalf: Double = 55

    static func bridgeAt(_ d: Double) -> Double? {
        for r in rivers where abs(d - r) < bridgeHalf + 30 { return r }
        return nil
    }

    static func zone(at d: Double) -> Int {
        for c in 0..<4 {
            let center = Double(c) * cityGap + 6000
            let dd = abs(d - center)
            if dd < 2600 { return 3 }
            if dd < 5200 { return 2 }
        }
        for c in 0..<4 {
            let ind = Double(c) * cityGap + 12600
            if abs(d - ind) < 1500 { return 4 }
        }
        let t = (d / 2300).truncatingRemainder(dividingBy: 2)
        return t < 1 ? 1 : 0
    }

    static func limitAhead(from d: Double, stops: [Int], maxSpeed: Double) -> (Double, Double)? {
        var best: (Double, Double)?
        let now = speedLimit(at: d, stops: stops, maxSpeed: maxSpeed)
        var probe = d + 10
        while probe < d + 700 {
            let v = speedLimit(at: probe, stops: stops, maxSpeed: maxSpeed)
            if v < now - 1 {
                best = (v, probe - d)
                break
            }
            probe += 10
        }
        return best
    }

    static func hash(_ i: Int) -> UInt64 {
        var x = UInt64(bitPattern: Int64(i &* 2654435761)) &+ 0x9E3779B97F4A7C15
        x ^= x >> 30
        x = x &* 0xBF58476D1CE4E5B9
        x ^= x >> 27
        x = x &* 0x94D049BB133111EB
        x ^= x >> 31
        return x
    }

    static func rnd(_ i: Int, _ salt: Int) -> Double {
        Double(hash(i &* 31 &+ salt) & 0xFFFFFF) / Double(0xFFFFFF)
    }

    static func cityFactor(at d: Double) -> Double {
        var best: Double = 0
        for c in 0..<4 {
            let center = Double(c) * cityGap + 6000
            best = max(best, max(0, 1 - abs(d - center) / 9000))
        }
        return best
    }

    static func props(from: Double, to: Double) -> [Prop] {
        var out: [Prop] = []
        let step: Double = 13
        var i = Int((from / step).rounded(.down))
        let last = Int((to / step).rounded(.up))
        while i <= last {
            let p = Double(i) * step
            let r = rnd(i, 7)
            let city = cityFactor(at: p)
            let nearStation = stations.contains { p > $0.platformStart - 40 && p < $0.pos + 60 }
            let onBridge = bridgeAt(p) != nil
            if !nearStation && !onBridge && p > 0 {
                let z = zone(at: p)
                let seed = Int(rnd(i, 11) * 997)
                switch z {
                case 3:
                    if r < 0.72 { out.append(Prop(kind: 2, pos: p, seed: seed)) }
                    else if r < 0.82 { out.append(Prop(kind: 3, pos: p, seed: seed)) }
                case 2:
                    if r < 0.46 { out.append(Prop(kind: 3, pos: p, seed: seed)) }
                    else if r < 0.60 { out.append(Prop(kind: 0, pos: p, seed: seed)) }
                    else if r < 0.68 { out.append(Prop(kind: 2, pos: p, seed: seed)) }
                case 4:
                    if r < 0.50 { out.append(Prop(kind: 5, pos: p, seed: seed)) }
                    else if r < 0.62 { out.append(Prop(kind: 6, pos: p, seed: seed)) }
                case 1:
                    if r < 0.78 { out.append(Prop(kind: 0, pos: p, seed: seed)) }
                    else if r < 0.86 { out.append(Prop(kind: 1, pos: p, seed: seed)) }
                default:
                    if r < 0.16 { out.append(Prop(kind: 0, pos: p, seed: seed)) }
                    else if r < 0.30 { out.append(Prop(kind: 1, pos: p, seed: seed)) }
                    else if r < 0.36 { out.append(Prop(kind: 7, pos: p, seed: seed)) }
                }
            }
            _ = city
            i += 1
        }
        var m = Int((from / 42).rounded(.down))
        let lastM = Int((to / 42).rounded(.up))
        while m <= lastM {
            out.append(Prop(kind: 4, pos: Double(m) * 42, seed: m))
            m += 1
        }
        return out
    }
}
