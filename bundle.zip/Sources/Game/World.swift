import UIKit

enum DoorSide {
    case left
    case right
}

struct StationDef {
    let index: Int
    let city: Int
    let ru: String
    let en: String
    let pos: Double
    let side: DoorSide
    let central: Bool
    var platformHalf: Double { central ? 78 : 62 }
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
}

struct RouteDef: Identifiable {
    let id: String
    let ru: String
    let en: String
    let trainIDs: [String]
    let stops: [Int]
    let traffic: Int
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
    var reward: Int { 2 * stops.count }
}

struct Prop {
    let kind: Int
    let pos: Double
    let seed: Int
}

enum World {

    static let cityGap: Double = 17000
    static let cityNamesRU = ["Северогорск", "Лесной", "Приозёрск", "Южный"]
    static let cityNamesEN = ["Severogorsk", "Lesnoy", "Priozersk", "Yuzhny"]

    static let stationNamesRU: [[String]] = [
        ["Северогорск-Центральный", "Заводская", "Парковая", "Речная", "Ольховая", "Северная", "Гранитная"],
        ["Лесной-Центральный", "Сосновая", "Ключевая", "Берёзовая", "Полевая", "Дачная", "Заречная"],
        ["Приозёрск-Центральный", "Озёрная", "Маяковая", "Портовая", "Гаванская", "Чайковая", "Дюнная"],
        ["Южный-Центральный", "Виноградная", "Солнечная", "Абрикосовая", "Приморская", "Тополиная", "Южный Порт"]
    ]

    static let stationNamesEN: [[String]] = [
        ["Severogorsk Central", "Zavodskaya", "Parkovaya", "Rechnaya", "Olkhovaya", "Severnaya", "Granitnaya"],
        ["Lesnoy Central", "Sosnovaya", "Klyuchevaya", "Berezovaya", "Polevaya", "Dachnaya", "Zarechnaya"],
        ["Priozersk Central", "Ozernaya", "Mayakovaya", "Portovaya", "Gavanskaya", "Chaykovaya", "Dyunnaya"],
        ["Yuzhny Central", "Vinogradnaya", "Solnechnaya", "Abrikosovaya", "Primorskaya", "Topolinaya", "Yuzhny Port"]
    ]

    static let offsets: [Double] = [1500, 3000, 4500, 6000, 7500, 9000, 10500]

    static let stations: [StationDef] = {
        var out: [StationDef] = []
        var idx = 0
        for c in 0..<4 {
            for s in 0..<7 {
                let pos = Double(c) * cityGap + offsets[s]
                out.append(StationDef(index: idx, city: c,
                                      ru: stationNamesRU[c][s], en: stationNamesEN[c][s],
                                      pos: pos,
                                      side: (idx % 2 == 0) ? .right : .left,
                                      central: s == 0))
                idx += 1
            }
        }
        return out
    }()

    static let lineLength: Double = 3 * cityGap + 12500

    static func cityName(_ c: Int, _ l: Lang) -> String {
        l == .ru ? cityNamesRU[c] : cityNamesEN[c]
    }

    static func centralIndex(_ city: Int) -> Int { city * 7 }

    static let routes: [RouteDef] = {
        var out: [RouteDef] = []
        for c in 0..<4 {
            let all = Array((c * 7)..<(c * 7 + 7))
            out.append(RouteDef(id: "city\(c)full",
                                ru: "\(cityNamesRU[c]): все станции",
                                en: "\(cityNamesEN[c]): all stops",
                                trainIDs: ["lastochka", "ivolga"],
                                stops: all, traffic: 2))
            out.append(RouteDef(id: "city\(c)short",
                                ru: "\(cityNamesRU[c]): короткий",
                                en: "\(cityNamesEN[c]): short run",
                                trainIDs: ["lastochka", "ivolga"],
                                stops: Array(all.prefix(3)), traffic: 1))
        }
        for c in 0..<3 {
            out.append(RouteDef(id: "exp\(c)",
                                ru: "\(cityNamesRU[c]) — \(cityNamesRU[c + 1])",
                                en: "\(cityNamesEN[c]) — \(cityNamesEN[c + 1])",
                                trainIDs: ["sapsan"],
                                stops: [centralIndex(c), centralIndex(c + 1)],
                                traffic: 1))
        }
        out.append(RouteDef(id: "expFull",
                            ru: "\(cityNamesRU[0]) — \(cityNamesRU[3])",
                            en: "\(cityNamesEN[0]) — \(cityNamesEN[3])",
                            trainIDs: ["sapsan"],
                            stops: [centralIndex(0), centralIndex(1), centralIndex(2), centralIndex(3)],
                            traffic: 0))
        return out
    }()

    static func speedLimit(at d: Double, stops: [Int], maxSpeed: Double) -> Double {
        var limit = maxSpeed
        for i in stops {
            let st = stations[i]
            let delta = abs(st.pos - d)
            if delta < 140 { limit = min(limit, 60) }
            else if delta < 330 { limit = min(limit, 90) }
        }
        return limit
    }

    static func hash(_ i: Int) -> UInt64 {
        var x = UInt64(bitPattern: Int64(i &* 2654435761)) &+ 0x9E3779B97F4A7C15
        x ^= x >> 30
        x = x &* 0xBF58476D1CE4E5B9
        x ^= x >> 27
        x = x &* 0x94D049BB133111EB
        x ^= x >> 31
        return x
    }

    static func rnd(_ i: Int, _ salt: Int) -> Double {
        Double(hash(i &* 31 &+ salt) & 0xFFFFFF) / Double(0xFFFFFF)
    }

    static func cityFactor(at d: Double) -> Double {
        var best: Double = 0
        for c in 0..<4 {
            let center = Double(c) * cityGap + 6000
            let f = max(0, 1 - abs(d - center) / 9000)
            best = max(best, f)
        }
        return best
    }

    static func props(from: Double, to: Double) -> [Prop] {
        var out: [Prop] = []
        let step: Double = 13
        var i = Int((from / step).rounded(.down))
        let last = Int((to / step).rounded(.up))
        while i <= last {
            let p = Double(i) * step
            let r = rnd(i, 7)
            let city = cityFactor(at: p)
            let nearStation = stations.contains { abs($0.pos - p) < 130 }
            if !nearStation {
                if r < 0.30 - city * 0.2 {
                    out.append(Prop(kind: 0, pos: p, seed: Int(rnd(i, 11) * 997)))
                } else if r < 0.42 - city * 0.2 {
                    out.append(Prop(kind: 1, pos: p, seed: Int(rnd(i, 13) * 997)))
                } else if r < 0.42 + city * 0.34 {
                    out.append(Prop(kind: 2, pos: p, seed: Int(rnd(i, 17) * 997)))
                } else if r < 0.52 {
                    out.append(Prop(kind: 3, pos: p, seed: Int(rnd(i, 19) * 997)))
                }
            }
            i += 1
        }
        var m = Int((from / 42).rounded(.down))
        let lastM = Int((to / 42).rounded(.up))
        while m <= lastM {
            out.append(Prop(kind: 4, pos: Double(m) * 42, seed: m))
            m += 1
        }
        return out
    }
}
