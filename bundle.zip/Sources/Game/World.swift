import UIKit

enum DoorSide {
    case left
    case right
}

struct StationDef {
    let ru: String
    let en: String
    let pos: Double
    let side: DoorSide
    let platformHalf: Double
    func name(_ l: Lang) -> String { l == .ru ? ru : en }
}

struct SignalDef {
    let pos: Double
    var green: Bool
}

struct Prop {
    let kind: Int
    let pos: Double
    let seed: Int
    let layer: Int
}

enum World {
    static let stations: [StationDef] = [
        StationDef(ru: "Заречье", en: "Zarechye", pos: 900, side: .right, platformHalf: 62),
        StationDef(ru: "Северный Парк", en: "North Park", pos: 2250, side: .left, platformHalf: 62),
        StationDef(ru: "Лесная", en: "Lesnaya", pos: 3600, side: .right, platformHalf: 55),
        StationDef(ru: "Ключевая", en: "Klyuchevaya", pos: 4950, side: .left, platformHalf: 62),
        StationDef(ru: "Приморская", en: "Primorskaya", pos: 6400, side: .right, platformHalf: 70)
    ]

    static let routeLength: Double = 7000

    static func makeSignals() -> [SignalDef] {
        var out: [SignalDef] = []
        for st in stations {
            out.append(SignalDef(pos: st.pos - 260, green: true))
            out.append(SignalDef(pos: st.pos + 120, green: true))
        }
        out.append(SignalDef(pos: 420, green: true))
        out.sort { $0.pos < $1.pos }
        return out
    }

    static func speedLimit(at d: Double) -> Double {
        var limit: Double = 120
        for st in stations {
            let delta = abs(st.pos - d)
            if delta < 180 { limit = min(limit, 60) }
            else if delta < 400 { limit = min(limit, 90) }
        }
        return limit
    }

    static func makeProps() -> [Prop] {
        var out: [Prop] = []
        var seed: UInt64 = 20260726
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double((seed >> 33) & 0xFFFFFF) / Double(0xFFFFFF)
        }
        var p: Double = -60
        while p < routeLength + 200 {
            let nearStation = stations.contains { abs($0.pos - p) < 110 }
            let roll = rnd()
            if !nearStation {
                if roll < 0.42 {
                    out.append(Prop(kind: 0, pos: p, seed: Int(rnd() * 1000), layer: 1))
                } else if roll < 0.56 {
                    out.append(Prop(kind: 1, pos: p, seed: Int(rnd() * 1000), layer: 1))
                } else if roll < 0.64 {
                    out.append(Prop(kind: 2, pos: p, seed: Int(rnd() * 1000), layer: 2))
                } else if roll < 0.70 {
                    out.append(Prop(kind: 3, pos: p, seed: Int(rnd() * 1000), layer: 1))
                }
            }
            p += 8 + rnd() * 16
        }
        var q: Double = -100
        while q < routeLength + 300 {
            out.append(Prop(kind: 4, pos: q, seed: Int(rnd() * 1000), layer: 1))
            q += 42
        }
        var h: Double = -400
        while h < routeLength + 600 {
            out.append(Prop(kind: 5, pos: h, seed: Int(rnd() * 1000), layer: 3))
            h += 120 + rnd() * 140
        }
        return out.sorted { $0.pos < $1.pos }
    }
}
