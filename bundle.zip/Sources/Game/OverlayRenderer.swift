import UIKit

struct OverlayRects {
    let resume: (Int, Int, Int, Int)
    let exit: (Int, Int, Int, Int)

    static func make(_ w: Int, _ h: Int) -> OverlayRects {
        let bw = 150, bh = 30
        let cx = w / 2 - bw / 2
        return OverlayRects(resume: (cx, h / 2 - 10, bw, bh),
                            exit: (cx, h / 2 + 28, bw, bh))
    }

    static func hit(_ r: (Int, Int, Int, Int), _ x: Int, _ y: Int) -> Bool {
        x >= r.0 && x < r.0 + r.2 && y >= r.1 && y < r.1 + r.3
    }
}

enum OverlayRenderer {

    static func tipRect(_ width: Int, _ st: GameState, _ l: PanelLayout, _ id: String) -> (Int, Int, Int, Int)? {
        guard let b = l.button(id, st.lang) else { return nil }
        let tw = 168
        let th = 54
        var x = b.x + b.w / 2 - tw / 2
        x = max(4, min(width - tw - 4, x))
        let y = max(4, b.y - th - 6)
        return (x, y, tw, th)
    }

    static func tipCloseRect(_ r: (Int, Int, Int, Int)) -> (Int, Int, Int, Int) {
        (r.0 + r.2 - 15, r.1 + 3, 12, 12)
    }

    static func tooltip(_ g: Pix, _ st: GameState, _ l: PanelLayout, _ id: String) {
        guard let r = tipRect(g.width, st, l, id) else { return }
        g.ctx.setFillColor(UIColor(red: 0, green: 0, blue: 0, alpha: 0.35).cgColor)
        g.ctx.fill(CGRect(x: 0, y: CGFloat(l.top), width: CGFloat(g.width),
                          height: CGFloat(g.height - l.top)))
        g.bevel(r.0, r.1, r.2, r.3, face: .rgb(0x151C25), light: .rgb(0x4C5B6C), dark: .rgb(0x05070A))
        g.rect(r.0, r.1, r.2, 2, .rgb(0x4A9BE8))
        g.text(Loc.s("tt_" + id + "_t", st.lang), r.0 + 7, r.1 + 5, size: 8, color: .rgb(0xEAF1F8), align: .left)
        let body = Loc.s("tt_" + id + "_d", st.lang)
        let words = body.split(separator: " ").map(String.init)
        var line = ""
        var ly = r.1 + 18
        for word in words {
            let test = line.isEmpty ? word : line + " " + word
            if g.textWidth(test, size: 7) > r.2 - 14 {
                g.text(line, r.0 + 7, ly, size: 7, color: .rgb(0xA9BACA), align: .left)
                line = word
                ly += 9
                if ly > r.1 + r.3 - 10 { break }
            } else {
                line = test
            }
        }
        if !line.isEmpty && ly <= r.1 + r.3 - 10 {
            g.text(line, r.0 + 7, ly, size: 7, color: .rgb(0xA9BACA), align: .left)
        }
        let c = tipCloseRect(r)
        g.rect(c.0, c.1, c.2, c.3, .rgb(0x35242A))
        g.frame(c.0, c.1, c.2, c.3, .rgb(0x8A4038))
        g.line(c.0 + 3, c.1 + 3, c.0 + c.2 - 4, c.1 + c.3 - 4, .rgb(0xFF9A88))
        g.line(c.0 + c.2 - 4, c.1 + 3, c.0 + 3, c.1 + c.3 - 4, .rgb(0xFF9A88))
    }

    static func dim(_ g: Pix, _ alpha: CGFloat) {
        g.ctx.setFillColor(UIColor(red: 0, green: 0, blue: 0, alpha: alpha).cgColor)
        g.ctx.fill(CGRect(x: 0, y: 0, width: CGFloat(g.width), height: CGFloat(g.height)))
    }

    private static func button(_ g: Pix, _ r: (Int, Int, Int, Int), _ title: String, _ accent: UIColor) {
        g.bevel(r.0, r.1, r.2, r.3, face: .rgb(0x1E252E), light: .rgb(0x505C6A), dark: .rgb(0x080B0F))
        g.rect(r.0 + 2, r.1 + 2, 3, r.3 - 4, accent)
        g.text(title, r.0 + r.2 / 2 + 2, r.1 + r.3 / 2 - 6, size: 11, color: .rgb(0xEDF2F7), align: .center)
    }

    static func pauseMenu(_ g: Pix, _ st: GameState) {
        dim(g, 0.62)
        let w = g.width, h = g.height
        let pw = 230, ph = 132
        let px = w / 2 - pw / 2, py = h / 2 - ph / 2 - 14
        g.bevel(px, py, pw, ph, face: .rgb(0x141A22), light: .rgb(0x46525F), dark: .rgb(0x05070A))
        g.rect(px, py, pw, 3, st.spec.liveryMain)
        g.text(Loc.s("paused", st.lang), w / 2, py + 9, size: 13, color: .rgb(0xEDF2F7), align: .center)
        g.text(st.route.name(st.lang), w / 2, py + 27, size: 7, color: .rgb(0x93A2B2), align: .center)
        g.text("\(Loc.s("score", st.lang)) \(st.score)   \(Loc.s("coins", st.lang)) \(Save.coins)",
               w / 2, py + 38, size: 7, color: .rgb(0x93A2B2), align: .center)
        let r = OverlayRects.make(w, h)
        button(g, r.resume, Loc.s("resume", st.lang), .rgb(0x35C463))
        button(g, r.exit, Loc.s("toMenu", st.lang), .rgb(0xE04A3A))
    }

    static func countdown(_ g: Pix, _ st: GameState) {
        dim(g, 0.45)
        let n = max(1, Int(st.countdown.rounded(.up)))
        let w = g.width, h = g.height
        g.seg7(n, w / 2 - 17, h / 2 - 39, 34, 58, on: .rgb(0xFFFFFF), off: .rgb(0x1E252E))
        g.text(Loc.s("getReady", st.lang), w / 2, h / 2 + 32, size: 9, color: .rgb(0xBFD0E0), align: .center)
    }

    static func crash(_ g: Pix, _ st: GameState) {
        g.ctx.setFillColor(UIColor(red: 0.7, green: 0.05, blue: 0.05, alpha: 0.35).cgColor)
        g.ctx.fill(CGRect(x: 0, y: 0, width: CGFloat(g.width), height: CGFloat(WorldRenderer.winH)))
        let w = g.width
        g.bevel(w / 2 - 95, 34, 190, 40, face: .rgb(0x2A0E0C), light: .rgb(0x8A2A22), dark: .rgb(0x120404))
        g.text(Loc.s("eCrash", st.lang), w / 2, 42, size: 13, color: .rgb(0xFF6A58), align: .center)
        g.text(Loc.s("respawning", st.lang), w / 2, 58, size: 8, color: .rgb(0xE0A8A0), align: .center)
    }

    static func finish(_ g: Pix, _ st: GameState) {
        dim(g, 0.68)
        let w = g.width, h = g.height
        let pw = 250, ph = 136
        let px = w / 2 - pw / 2, py = h / 2 - ph / 2 - 14
        g.bevel(px, py, pw, ph, face: .rgb(0x121A16), light: .rgb(0x3F6A52), dark: .rgb(0x05070A))
        g.rect(px, py, pw, 3, .rgb(0x35C463))
        g.text(Loc.s("routeDone", st.lang), w / 2, py + 8, size: 13, color: .rgb(0x8CF0B0), align: .center)
        g.text(st.route.name(st.lang), w / 2, py + 25, size: 7, color: .rgb(0x93A2B2), align: .center)
        let rows: [(String, String)] = [
            (Loc.s("rStations", st.lang), "\(st.passedCount)"),
            (Loc.s("rBonus", st.lang), "+\(st.route.reward)"),
            (Loc.s("rScore", st.lang), "\(st.score)"),
            (Loc.s("rCoins", st.lang), "+\(st.earnedCoins)")
        ]
        for (i, r) in rows.enumerated() {
            let y = py + 40 + i * 13
            g.text(r.0, px + 14, y, size: 8, color: .rgb(0xA8B6C4), align: .left)
            g.text(r.1, px + pw - 14, y, size: 8, color: .rgb(0xF0F6FA), align: .right)
        }
        button(g, OverlayRects.make(w, h).exit, Loc.s("toMenu", st.lang), .rgb(0x35C463))
    }
}
