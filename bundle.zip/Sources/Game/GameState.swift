import UIKit

struct Passenger {
    var pos: Double
    var target: Double
    var coat: Int
    var boarding: Bool
    var done: Bool
    var phase: Double
    var speed: Double
}

struct Traffic {
    var pos: Double
    var speed: Double
    let specId: String
    let sameTrack: Bool
    let cars: Int
    var active: Bool
}

enum RunPhase {
    case running
    case arrived
    case boarding
    case ready
    case crashed
    case finished
}

final class GameState {
    let spec: TrainSpec
    let route: RouteDef
    let lang: Lang

    var distance: Double
    var speed: Double = 0
    var controller: Double = -1
    var doorsOpen = false
    var doorSide: DoorSide = .right
    var doorAnim: Double = 0
    var autoStop = true
    var headlights = true
    var cabinLight = true
    var emergency = false
    var horn: Double = 0
    var sand = false

    var paused = false
    var countdown: Double = 0

    var clock: Double = 6 * 3600
    var time: Double = 0
    var phase: RunPhase = .running
    var stopCursor = 0
    var boardTimer: Double = 0
    var crashTimer: Double = 0
    var respawns = 0
    var passedCount = 0
    var nextPassIndex = 0

    var score = 0
    var earnedCoins = 0
    var message = ""
    var messageTimer: Double = 0
    var overspeedTimer: Double = 0

    var traffic: [Traffic] = []
    var passengers: [Int: [Passenger]] = [:]

    private let cars: Int
    private let traction: Double
    private let braking: Double
    private let precise: Bool

    init(spec: TrainSpec, route: RouteDef, lang: Lang) {
        self.spec = spec
        self.route = route
        self.lang = lang
        self.cars = spec.cars()
        self.traction = spec.traction()
        self.braking = spec.braking()
        self.precise = Save.owns(spec.id, .autopilot)
        let first = World.stations[route.stops[0]]
        self.distance = first.pos - 260
        self.nextPassIndex = World.stations.firstIndex { $0.pos >= first.pos - 260 } ?? 0
        makeTraffic()
    }

    var carCount: Int { cars }

    var currentStop: StationDef? {
        stopCursor < route.stops.count ? World.stations[route.stops[stopCursor]] : nil
    }

    var speedLimit: Double {
        World.speedLimit(at: distance, stops: route.stops, maxSpeed: spec.maxSpeed)
    }

    var isNight: Bool {
        let h = (clock / 3600).truncatingRemainder(dividingBy: 24)
        return h < 5.2 || h > 21.0
    }

    var dayPhase: Double {
        let h = (clock / 3600).truncatingRemainder(dividingBy: 24)
        if h < 4.5 { return 0 }
        if h < 7.0 { return (h - 4.5) / 2.5 * 0.5 }
        if h < 18.0 { return 1 }
        if h < 21.0 { return 1 - (h - 18) / 3 * 0.5 }
        return 0
    }

    func clockString() -> String {
        let t = Int(clock) % 86400
        return String(format: "%02d:%02d", t / 3600, (t / 60) % 60)
    }

    func doorWorldPositions() -> [Double] {
        var out: [Double] = []
        for c in 0..<cars {
            let front = distance - Double(c) * (spec.carLengthM + 0.6)
            out.append(front - spec.carLengthM * 0.34)
            out.append(front - spec.carLengthM * 0.74)
        }
        return out
    }

    private func makeTraffic() {
        traffic.removeAll()
        guard route.traffic > 0 else { return }
        let startP = World.stations[route.stops[0]].pos
        let endP = World.stations[route.stops[route.stops.count - 1]].pos
        let span = max(1, endP - startP)
        let count = route.traffic * 2
        for i in 0..<count {
            let f = (Double(i) + 0.6) / Double(count + 1)
            let p = startP + span * f + World.rnd(i, 5) * 300
            let same = World.rnd(i, 9) < 0.5
            let ids = ["lastochka", "ivolga", "sapsan"]
            let sid = ids[Int(World.rnd(i, 21) * 3) % 3]
            traffic.append(Traffic(pos: p, speed: same ? 0 : -(18 + World.rnd(i, 23) * 22),
                                   specId: sid, sameTrack: same,
                                   cars: 4 + Int(World.rnd(i, 27) * 3), active: true))
        }
        traffic.sort { $0.pos < $1.pos }
    }

    func setMessage(_ t: String, _ seconds: Double = 2.6) {
        message = t
        messageTimer = seconds
    }

    func blockingTraffic() -> Traffic? {
        traffic.first { $0.active && $0.sameTrack && $0.pos > distance - 10 }
    }

    func signalGreen(at pos: Double) -> Bool {
        guard let t = blockingTraffic() else { return true }
        return !(t.pos > pos && t.pos - pos < 1400)
    }

    func passengersFor(_ index: Int) -> [Passenger] {
        if let p = passengers[index] { return p }
        let st = World.stations[index]
        var list: [Passenger] = []
        let n = 5 + Int(World.rnd(index, 3) * 8)
        for k in 0..<n {
            let x = st.pos + (World.rnd(index &* 100 &+ k, 31) - 0.5) * st.platformHalf * 1.7
            list.append(Passenger(pos: x, target: x, coat: Int(World.rnd(index &* 100 &+ k, 37) * 7),
                                  boarding: false, done: false,
                                  phase: World.rnd(index &* 100 &+ k, 41) * 6.28,
                                  speed: 0.9 + World.rnd(index &* 100 &+ k, 43) * 0.6))
        }
        passengers[index] = list
        return list
    }

    func update(_ dt: Double) {
        if countdown > 0 {
            countdown -= dt
            return
        }
        if paused { return }
        if phase == .finished { return }

        time += dt
        clock += dt * 60
        if messageTimer > 0 {
            messageTimer -= dt
            if messageTimer <= 0 { message = "" }
        }
        if horn > 0 { horn -= dt }

        if phase == .crashed {
            crashTimer -= dt
            if crashTimer <= 0 { respawn() }
            return
        }

        var demand = controller
        if emergency { demand = -1 }

        if autoStop, let st = currentStop, !doorsOpen {
            let d = st.pos - distance
            if d > 0 {
                let margin = precise ? 0.4 : 1.2
                let need = speed * speed / (2 * max(d - margin, 0.5))
                if need > braking * 0.72 {
                    demand = min(demand, -min(1, need / braking))
                }
                if d < 12 && speed < 1.5 { demand = -1 }
            }
        }

        if let t = blockingTraffic(), t.speed <= 0.5 {
            let d = t.pos - distance - 25
            if d > 0 && d < 900 {
                let need = speed * speed / (2 * max(d, 0.5))
                if need > braking * 0.5 {
                    demand = min(demand, -min(1, need / braking))
                }
            }
        }

        var accel: Double = 0
        if demand > 0.02 {
            let vmax = spec.maxSpeed / 3.6
            let fade = max(0.2, 1 - pow(speed / vmax, 1.6))
            accel = demand * traction * fade
        } else if demand < -0.02 {
            accel = demand * braking
        }
        accel -= 0.010 + speed * 0.0012 + speed * speed * 0.00010

        if speed <= 0.001 && accel < 0 { accel = 0 }
        speed = max(0, speed + accel * dt)
        if speed < 0.05 && demand <= 0.02 { speed = 0 }
        if doorsOpen { speed = 0 }

        distance += speed * dt

        while nextPassIndex < World.stations.count && World.stations[nextPassIndex].pos < distance {
            nextPassIndex += 1
            passedCount += 1
            score += 1
        }

        if speed * 3.6 > speedLimit + 4 {
            overspeedTimer += dt
            if overspeedTimer > 1.2 {
                overspeedTimer = 0
                score = max(0, score - 1)
                setMessage(Loc.s("overspeed", lang), 1.6)
            }
        } else {
            overspeedTimer = 0
        }

        doorAnim += (doorsOpen ? 1 : -1) * dt * 1.9
        doorAnim = max(0, min(1, doorAnim))

        updateTraffic(dt)
        updateStop(dt)
        updatePassengers(dt)
    }

    private func updateTraffic(_ dt: Double) {
        for i in traffic.indices where traffic[i].active {
            traffic[i].pos += traffic[i].speed * dt
            if traffic[i].sameTrack {
                let gap = traffic[i].pos - distance
                if gap < 500 && traffic[i].speed < 1 {
                    traffic[i].speed = 0
                }
                if gap < 14 && gap > -60 {
                    crash()
                    return
                }
            } else if traffic[i].pos < distance - 900 {
                traffic[i].active = false
            }
        }
    }

    private func crash() {
        guard phase != .crashed else { return }
        phase = .crashed
        crashTimer = 2.6
        speed = 0
        controller = -1
        score = max(0, score - 5)
        respawns += 1
        setMessage(Loc.s("crash", lang), 3)
    }

    private func respawn() {
        if let idx = traffic.firstIndex(where: { $0.active && $0.sameTrack && $0.pos > distance - 60 }) {
            traffic[idx].active = false
        }
        distance = max(0, distance - 260)
        speed = 0
        controller = -1
        emergency = false
        phase = .running
        setMessage(Loc.s("respawn", lang), 2.4)
    }

    private func updateStop(_ dt: Double) {
        guard let st = currentStop else { return }
        let err = distance - st.pos
        switch phase {
        case .running:
            if speed == 0 && abs(err) < st.platformHalf {
                phase = .arrived
                let acc = abs(err)
                let gained = acc < 1 ? 3 : (acc < 3 ? 2 : (acc < 8 ? 1 : 0))
                score += gained
                setMessage(String(format: Loc.s("stopped", lang), Int(acc.rounded()), gained), 3.2)
            }
        case .arrived:
            if doorsOpen {
                if doorSide == st.side {
                    phase = .boarding
                    boardTimer = 0
                } else {
                    setMessage(Loc.s("wrongSide", lang), 2.2)
                }
            }
        case .boarding:
            boardTimer += dt
            let list = passengersFor(st.index)
            let left = list.contains { !$0.done }
            if boardTimer > 3.5 && !left {
                phase = .ready
                setMessage(Loc.s("boardDone", lang), 2.6)
            }
        case .ready:
            if !doorsOpen && speed > 0.4 {
                advanceStop()
            }
        default:
            break
        }
        if err > st.platformHalf + 40 && (phase == .running || phase == .arrived) {
            advanceStop()
        }
    }

    private func advanceStop() {
        stopCursor += 1
        if stopCursor >= route.stops.count {
            finish()
        } else {
            phase = .running
        }
    }

    private func finish() {
        phase = .finished
        score += route.reward
        earnedCoins = score * 10
        Save.addCoins(earnedCoins)
        setMessage(Loc.s("routeDone", lang), 8)
    }

    private func updatePassengers(_ dt: Double) {
        guard let st = currentStop else { return }
        let open = doorsOpen && doorSide == st.side && phase == .boarding
        var list = passengersFor(st.index)
        let doors = doorWorldPositions()
        for i in list.indices {
            if list[i].done { continue }
            if open {
                if !list[i].boarding {
                    list[i].boarding = true
                    var best = distance
                    var bestD = Double.greatestFiniteMagnitude
                    for d in doors where abs(d - st.pos) < st.platformHalf + 20 {
                        let dd = abs(d - list[i].pos)
                        if dd < bestD { bestD = dd; best = d }
                    }
                    list[i].target = best
                }
                let dir = list[i].target - list[i].pos
                if abs(dir) < 0.45 {
                    list[i].done = true
                } else {
                    list[i].pos += (dir > 0 ? 1 : -1) * list[i].speed * dt
                    list[i].phase += dt * 9
                }
            } else {
                list[i].phase += dt * 1.3
            }
        }
        passengers[st.index] = list
    }

    func pressDoors(_ side: DoorSide) {
        guard speed < 0.2 else {
            setMessage(Loc.s("needStop", lang), 1.8)
            return
        }
        if doorsOpen && doorSide == side {
            doorsOpen = false
            setMessage(Loc.s("doorsShut", lang), 1.4)
        } else {
            doorSide = side
            doorsOpen = true
            setMessage(side == .left ? Loc.s("doorsLeft", lang) : Loc.s("doorsRight", lang), 1.4)
        }
    }

    func closeDoors() {
        guard doorsOpen else { return }
        doorsOpen = false
        setMessage(Loc.s("doorsShut", lang), 1.4)
    }
}
