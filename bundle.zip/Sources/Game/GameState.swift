import UIKit

struct Passenger {
    var pos: Double
    var target: Double
    var coat: Int
    var boarding: Bool
    var done: Bool
    var phase: Double
    var speed: Double
}

struct Traffic {
    var pos: Double
    var speed: Double
    let specId: String
    let sameTrack: Bool
    let cars: Int
    var active: Bool
}

struct Toast {
    var text: String
    var life: Double
    var total: Double
    var bad: Bool
}

enum RunPhase {
    case running
    case arrived
    case boarding
    case ready
    case crashed
    case finished
}

final class GameState {
    let spec: TrainSpec
    let route: RouteDef
    let lang: Lang

    var distance: Double
    var speed: Double = 0
    var controller: Double = -1
    var doorsOpen = false
    var doorSide: DoorSide = .right
    var doorAnim: Double = 0
    var autoStop = true
    var headlights = true
    var cabinLight = true
    var emergency = false
    var horn: Double = 0
    var sand = false

    var paused = false
    var countdown: Double = 0
    var camOffset: Double = 0
    var camDragging = false

    var tooltipID: String?

    var clock: Double = 6 * 3600
    var time: Double = 0
    var phase: RunPhase = .running
    var stopCursor = 0
    var boardTimer: Double = 0
    var crashTimer: Double = 0
    var passedCount = 0
    var nextPassIndex = 0
    var stopError: Double = 0

    var score = 0
    var earnedCoins = 0
    var toasts: [Toast] = []

    var pendingClack = false
    var pendingChime = false
    var pendingHiss = false
    var pendingDoor = false
    private var lastDemand: Double = 0
    private var lastClack: Double = 0
    private var overspeedTimer: Double = 0

    var traffic: [Traffic] = []
    var passengers: [Int: [Passenger]] = [:]

    let cars: Int
    private let traction: Double
    private let braking: Double
    private let precise: Bool

    init(spec: TrainSpec, route: RouteDef, lang: Lang) {
        self.spec = spec
        self.route = route
        self.lang = lang
        self.cars = spec.cars()
        self.traction = spec.traction()
        self.braking = spec.braking()
        self.precise = Save.owns(spec.id, .autopilot)
        let first = World.stations[route.stops[0]]
        self.distance = first.pos - 300
        self.lastClack = self.distance
        self.nextPassIndex = World.stations.firstIndex { $0.pos >= first.pos - 300 } ?? 0
        makeTraffic()
    }

    var currentStop: StationDef? {
        stopCursor < route.stops.count ? World.stations[route.stops[stopCursor]] : nil
    }

    var consistLength: Double {
        Double(cars) * (spec.carLengthM + 0.6)
    }

    var speedLimit: Double {
        World.speedLimit(at: distance, stops: route.stops, maxSpeed: spec.maxSpeed)
    }

    var dayPhase: Double {
        let h = (clock / 3600).truncatingRemainder(dividingBy: 24)
        if h < 4.6 { return 0 }
        if h < 7.2 { return (h - 4.6) / 2.6 }
        if h < 18.4 { return 1 }
        if h < 21.2 { return 1 - (h - 18.4) / 2.8 }
        return 0
    }

    func clockString() -> String {
        let t = Int(clock) % 86400
        return String(format: "%02d:%02d", t / 3600, (t / 60) % 60)
    }

    func toast(_ text: String, bad: Bool = true, seconds: Double = 3.0) {
        toasts.removeAll { $0.text == text }
        toasts.append(Toast(text: text, life: seconds, total: seconds, bad: bad))
        if toasts.count > 3 { toasts.removeFirst() }
    }

    func doorWorldPositions() -> [Double] {
        var out: [Double] = []
        for c in 0..<cars {
            let front = distance - Double(c) * (spec.carLengthM + 0.6)
            out.append(front - spec.carLengthM * 0.36)
            out.append(front - spec.carLengthM * 0.74)
        }
        return out
    }

    private func makeTraffic() {
        traffic.removeAll()
        guard route.traffic > 0 else { return }
        let a = World.stations[route.stops[0]].pos
        let b = World.stations[route.stops[route.stops.count - 1]].pos
        let span = max(1, b - a)
        let count = route.traffic * 2
        for i in 0..<count {
            let f = (Double(i) + 0.7) / Double(count + 1)
            let p = a + span * f + World.rnd(i, 5) * 200
            let same = World.rnd(i, 9) < 0.45
            let ids = ["lastochka", "ivolga", "sapsan"]
            traffic.append(Traffic(pos: p,
                                   speed: same ? 0 : -(20 + World.rnd(i, 23) * 24),
                                   specId: ids[Int(World.rnd(i, 21) * 3) % 3],
                                   sameTrack: same,
                                   cars: 4 + Int(World.rnd(i, 27) * 3),
                                   active: true))
        }
        traffic.sort { $0.pos < $1.pos }
    }

    func blockingTraffic() -> Traffic? {
        traffic.first { $0.active && $0.sameTrack && $0.pos > distance - 10 }
    }

    func signalGreen(at pos: Double) -> Bool {
        guard let t = blockingTraffic() else { return true }
        return !(t.pos > pos && t.pos - pos < 1400)
    }

    func passengersFor(_ index: Int) -> [Passenger] {
        if let p = passengers[index] { return p }
        let st = World.stations[index]
        var list: [Passenger] = []
        let n = 6 + Int(World.rnd(index, 3) * 8)
        for k in 0..<n {
            let key = index &* 100 &+ k
            let x = st.platformStart + 30 + World.rnd(key, 31) * (st.platformLen - 60)
            list.append(Passenger(pos: x, target: x, coat: Int(World.rnd(key, 37) * 7),
                                  boarding: false, done: false,
                                  phase: World.rnd(key, 41) * 6.28,
                                  speed: 1.0 + World.rnd(key, 43) * 0.7))
        }
        passengers[index] = list
        return list
    }

    func update(_ dt: Double) {
        for i in toasts.indices { toasts[i].life -= dt }
        toasts.removeAll { $0.life <= 0 }

        if countdown > 0 {
            countdown -= dt
            return
        }
        if paused || phase == .finished { return }

        time += dt
        clock += dt * 60
        if horn > 0 { horn -= dt }

        if phase == .crashed {
            crashTimer -= dt
            if crashTimer <= 0 { respawn() }
            return
        }

        var demand = controller
        if emergency { demand = -1 }
        if demand < -0.15 && lastDemand >= -0.15 { pendingHiss = true }
        lastDemand = demand

        let atStopNow = (phase == .arrived || phase == .boarding || phase == .ready)
        if autoStop, let st = currentStop, !doorsOpen, !atStopNow {
            let d = st.pos - distance
            if d > 0 {
                let margin = precise ? 0.4 : 1.4
                let need = speed * speed / (2 * max(d - margin, 0.5))
                if need > braking * 0.72 {
                    demand = min(demand, -min(1, need / braking))
                }
                if d < 12 && speed < 1.5 { demand = -1 }
            }
        }

        if let t = blockingTraffic(), t.speed <= 0.5 {
            let d = t.pos - distance - 30
            if d > 0 && d < 900 {
                let need = speed * speed / (2 * max(d, 0.5))
                if need > braking * 0.6 {
                    demand = min(demand, -min(1, need / braking))
                }
            }
        }

        let vmax = spec.maxSpeed / 3.6
        var accel: Double = 0
        if demand > 0.02 {
            accel = demand * traction * max(0.30, 1 - pow(min(1, speed / vmax), 1.9))
        } else if demand < -0.02 {
            accel = demand * braking
        }
        if speed > vmax { accel = min(accel, -0.5) }

        if speed <= 0.001 && accel < 0 { accel = 0 }
        speed = max(0, speed + accel * dt)
        if speed < 0.05 && demand < -0.02 { speed = 0 }
        if doorsOpen {
            if speed > 0.01 { toast(Loc.s("eDoorsMove", lang)) }
            speed = 0
        }

        distance += speed * dt

        while nextPassIndex < World.stations.count && World.stations[nextPassIndex].pos < distance {
            nextPassIndex += 1
            passedCount += 1
            score += 1
        }

        if speed * 3.6 > speedLimit + 4 {
            overspeedTimer += dt
            if overspeedTimer > 1.2 {
                overspeedTimer = 0
                score = max(0, score - 1)
                toast(Loc.s("eOverspeed", lang))
            }
        } else {
            overspeedTimer = 0
        }

        doorAnim += (doorsOpen ? 1 : -1) * dt * 1.9
        doorAnim = max(0, min(1, doorAnim))

        if !camDragging {
            if camOffset > 0 { camOffset = max(0, camOffset - 45 * dt) }
            if camOffset < 0 { camOffset = min(0, camOffset + 45 * dt) }
        }
        if distance - lastClack > 12.5 {
            lastClack = distance
            if speed > 1 { pendingClack = true }
        }

        updateTraffic(dt)
        updateStop(dt)
        updatePassengers(dt)
    }

    private func updateTraffic(_ dt: Double) {
        for i in traffic.indices where traffic[i].active {
            traffic[i].pos += traffic[i].speed * dt
            if traffic[i].sameTrack {
                let gap = traffic[i].pos - distance
                if gap < 16 && gap > -80 {
                    crash()
                    return
                }
            } else if traffic[i].pos < distance - 900 {
                traffic[i].active = false
            }
        }
    }

    private func crash() {
        guard phase != .crashed else { return }
        phase = .crashed
        crashTimer = 2.6
        speed = 0
        controller = -1
        score = max(0, score - 5)
        toast(Loc.s("eCrash", lang), seconds: 3.5)
    }

    private func respawn() {
        if let idx = traffic.firstIndex(where: { $0.active && $0.sameTrack && $0.pos > distance - 80 }) {
            traffic[idx].active = false
        }
        distance = max(10, distance - 280)
        speed = 0
        controller = -1
        emergency = false
        phase = .running
        toast(Loc.s("eRespawn", lang), bad: false, seconds: 2.5)
    }

    private func updateStop(_ dt: Double) {
        guard let st = currentStop else { return }
        let err = distance - st.pos
        switch phase {
        case .running:
            if speed == 0 && err > -st.platformLen && err < 40 {
                phase = .arrived
                stopError = err
                let acc = abs(err)
                let gained = acc < 1 ? 3 : (acc < 3 ? 2 : (acc < 8 ? 1 : 0))
                score += gained
                pendingChime = true
                toast(String(format: Loc.s("mStopped", lang), Int(acc.rounded()), gained), bad: false, seconds: 3.2)
                if acc > 25 { toast(Loc.s("eFarStop", lang)) }
            }
        case .arrived:
            if doorsOpen && doorSide == st.side {
                phase = .boarding
                boardTimer = 0
            }
        case .boarding:
            boardTimer += dt
            if boardTimer > 3.5 && !passengersFor(st.index).contains(where: { !$0.done }) {
                phase = .ready
                toast(Loc.s("mBoardDone", lang), bad: false, seconds: 2.6)
            }
        case .ready:
            if !doorsOpen && speed > 0.4 {
                advanceStop()
            }
        default:
            break
        }
        if err > 60 && (phase == .running || phase == .arrived) {
            toast(Loc.s("eMissed", lang))
            advanceStop()
        }
    }

    private func advanceStop() {
        stopCursor += 1
        if stopCursor >= route.stops.count {
            finish()
        } else {
            phase = .running
        }
    }

    private func finish() {
        phase = .finished
        score += route.reward
        earnedCoins = score * 10
        Save.addCoins(earnedCoins)
    }

    private func updatePassengers(_ dt: Double) {
        guard let st = currentStop else { return }
        let open = doorsOpen && doorSide == st.side && phase == .boarding
        var list = passengersFor(st.index)
        let doors = doorWorldPositions()
        for i in list.indices {
            if list[i].done { continue }
            if open {
                if !list[i].boarding {
                    list[i].boarding = true
                    var best = distance
                    var bestD = Double.greatestFiniteMagnitude
                    for d in doors {
                        let dd = abs(d - list[i].pos)
                        if dd < bestD { bestD = dd; best = d }
                    }
                    list[i].target = best
                }
                let dir = list[i].target - list[i].pos
                if abs(dir) < 0.5 {
                    list[i].done = true
                } else {
                    list[i].pos += (dir > 0 ? 1 : -1) * list[i].speed * dt
                    list[i].phase += dt * 9
                }
            } else {
                list[i].phase += dt * 1.3
            }
        }
        passengers[st.index] = list
    }

    func pressDoors(_ side: DoorSide) {
        guard speed < 0.2 else {
            toast(Loc.s("eNeedStop", lang))
            return
        }
        if doorsOpen && doorSide == side {
            doorsOpen = false
            pendingDoor = true
            toast(Loc.s("mDoorsShut", lang), bad: false, seconds: 1.8)
            return
        }
        if let st = currentStop, phase != .running, side != st.side {
            toast(Loc.s("eWrongSide", lang))
            return
        }
        if currentStop == nil || phase == .running {
            toast(Loc.s("eNoPlatform", lang))
            return
        }
        doorSide = side
        doorsOpen = true
        pendingDoor = true
        pendingChime = true
        toast(side == .left ? Loc.s("mDoorsLeft", lang) : Loc.s("mDoorsRight", lang), bad: false, seconds: 1.8)
    }

    func closeDoors() {
        guard doorsOpen else {
            toast(Loc.s("eDoorsAlready", lang))
            return
        }
        if phase == .boarding {
            toast(Loc.s("eBoarding", lang))
        }
        doorsOpen = false
        pendingDoor = true
        toast(Loc.s("mDoorsShut", lang), bad: false, seconds: 1.8)
    }
}
