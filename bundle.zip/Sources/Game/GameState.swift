import UIKit

struct Passenger {
    var pos: Double
    var target: Double
    var coat: Int
    var boarding: Bool
    var done: Bool
    var phase: Double
    var speed: Double
}

enum StopPhase {
    case running
    case arrived
    case boarding
    case ready
}

final class GameState {
    let spec: TrainSpec
    let lang: Lang

    var distance: Double = 40
    var speed: Double = 0
    var controller: Double = -1
    var doorsOpen = false
    var doorSide: DoorSide = .right
    var doorAnim: Double = 0
    var autoStop = true
    var headlights = true
    var cabinLight = true
    var emergency = false
    var horn: Double = 0
    var sand = false

    var signals: [SignalDef] = World.makeSignals()
    var props: [Prop] = World.makeProps()
    var passengers: [Passenger] = []

    var stationIndex = 0
    var phase: StopPhase = .running
    var boardTimer: Double = 0
    var clock: Double = 8 * 3600 + 13 * 60
    var time: Double = 0
    var score: Int = 0
    var lastStopError: Double = 0
    var message: String = ""
    var messageTimer: Double = 0
    var overspeedTimer: Double = 0
    var finished = false

    init(spec: TrainSpec, lang: Lang) {
        self.spec = spec
        self.lang = lang
        spawnPassengers()
    }

    var currentStation: StationDef? {
        stationIndex < World.stations.count ? World.stations[stationIndex] : nil
    }

    var speedLimit: Double { World.speedLimit(at: distance) }

    var trainLength: Double {
        Double(spec.cars) * spec.carLengthM + Double(spec.cars - 1) * 0.6
    }

    func doorWorldPositions() -> [Double] {
        var out: [Double] = []
        for c in 0..<spec.cars {
            let front = distance - Double(c) * (spec.carLengthM + 0.6)
            out.append(front - spec.carLengthM * 0.32)
            out.append(front - spec.carLengthM * 0.72)
        }
        return out
    }

    private func spawnPassengers() {
        passengers.removeAll()
        var seed: UInt64 = 987654321
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double((seed >> 33) & 0xFFFFFF) / Double(0xFFFFFF)
        }
        for st in World.stations {
            let count = 7 + Int(rnd() * 7)
            for _ in 0..<count {
                let x = st.pos + (rnd() - 0.5) * st.platformHalf * 1.7
                passengers.append(Passenger(pos: x, target: x, coat: Int(rnd() * 7),
                                            boarding: false, done: false,
                                            phase: rnd() * 6.28, speed: 0.9 + rnd() * 0.5))
            }
        }
    }

    func setMessage(_ t: String, _ seconds: Double = 2.6) {
        message = t
        messageTimer = seconds
    }

    func signalAhead() -> SignalDef? {
        signals.first { $0.pos > distance - 5 }
    }

    func update(_ dt: Double) {
        time += dt
        clock += dt
        if messageTimer > 0 {
            messageTimer -= dt
            if messageTimer <= 0 { message = "" }
        }
        if horn > 0 { horn -= dt }

        var demand = controller
        if emergency { demand = -1 }

        if autoStop, let st = currentStation, !doorsOpen {
            let d = st.pos - distance
            if d > 0 && d < 700 {
                let need = speed * speed / (2 * max(d - 1.0, 0.6))
                if need > spec.braking * 0.22 {
                    demand = min(demand, -min(1, need / spec.braking))
                }
                if d < 14 && speed < 1.2 { demand = -1 }
            }
        }

        var accel: Double = 0
        if demand > 0.02 {
            let fade = max(0.25, 1 - speed / (spec.maxSpeed / 3.6) * 0.8)
            accel = demand * spec.traction * fade
        } else if demand < -0.02 {
            accel = demand * spec.braking
        }
        accel -= 0.012 + speed * 0.0016 + speed * speed * 0.00016

        if speed <= 0.001 && accel < 0 { accel = 0 }
        speed = max(0, speed + accel * dt)
        if speed < 0.05 && demand <= 0.02 { speed = 0 }

        if doorsOpen { speed = 0 }
        distance += speed * dt

        if speed * 3.6 > speedLimit + 3 {
            overspeedTimer += dt
            if overspeedTimer > 1.0 {
                overspeedTimer = 0
                score -= 5
                setMessage(Loc.s("overspeed", lang), 1.6)
            }
        } else {
            overspeedTimer = 0
        }

        if doorAnim < (doorsOpen ? 1 : 0) {
            doorAnim = min(1, doorAnim + dt * 1.8)
        } else if doorAnim > (doorsOpen ? 1 : 0) {
            doorAnim = max(0, doorAnim - dt * 1.8)
        }

        updateStop(dt)
        updatePassengers(dt)

        if distance > World.routeLength && !finished {
            finished = true
            setMessage(Loc.s("routeDone", lang), 6)
        }
    }

    private func updateStop(_ dt: Double) {
        guard let st = currentStation else { return }
        let err = distance - st.pos
        switch phase {
        case .running:
            if speed == 0 && abs(err) < st.platformHalf {
                phase = .arrived
                lastStopError = err
                let acc = abs(err)
                let gained = acc < 1 ? 100 : (acc < 3 ? 70 : (acc < 8 ? 40 : 15))
                score += gained
                setMessage(String(format: Loc.s("stopped", lang), Int(acc.rounded()), gained), 3.4)
            }
        case .arrived:
            if doorsOpen {
                if doorSide == st.side {
                    phase = .boarding
                    boardTimer = 0
                } else {
                    setMessage(Loc.s("wrongSide", lang), 2.4)
                }
            }
        case .boarding:
            boardTimer += dt
            let remaining = passengers.contains { !$0.done && abs($0.pos - st.pos) < st.platformHalf * 1.2 }
            if boardTimer > 4 && !remaining {
                phase = .ready
                setMessage(Loc.s("boardDone", lang), 3.0)
            }
        case .ready:
            if !doorsOpen && speed > 0.3 {
                stationIndex += 1
                phase = .running
            }
        }
        if err > st.platformHalf + 30 && phase != .running {
            stationIndex += 1
            phase = .running
        }
    }

    private func updatePassengers(_ dt: Double) {
        guard let st = currentStation else { return }
        let open = doorsOpen && doorSide == st.side && phase == .boarding
        let doors = doorWorldPositions()
        for i in passengers.indices {
            if passengers[i].done { continue }
            if abs(passengers[i].pos - st.pos) > st.platformHalf * 2 { continue }
            if open {
                if !passengers[i].boarding {
                    passengers[i].boarding = true
                    var best = doors.first ?? distance
                    var bestD = Double.greatestFiniteMagnitude
                    for d in doors where abs(d - st.pos) < st.platformHalf + 12 {
                        let dd = abs(d - passengers[i].pos)
                        if dd < bestD { bestD = dd; best = d }
                    }
                    passengers[i].target = best
                }
                let dir = passengers[i].target - passengers[i].pos
                if abs(dir) < 0.4 {
                    passengers[i].done = true
                } else {
                    passengers[i].pos += (dir > 0 ? 1 : -1) * passengers[i].speed * dt
                    passengers[i].phase += dt * 9
                }
            } else {
                passengers[i].phase += dt * 1.4
            }
        }
    }

    func pressDoors(_ side: DoorSide) {
        guard speed < 0.2 else {
            setMessage(Loc.s("needStop", lang), 2.0)
            return
        }
        if doorsOpen && doorSide == side {
            doorsOpen = false
            setMessage(Loc.s("doorsShut", lang), 1.6)
        } else {
            doorSide = side
            doorsOpen = true
            setMessage(side == .left ? Loc.s("doorsLeft", lang) : Loc.s("doorsRight", lang), 1.6)
        }
    }

    func closeDoors() {
        guard doorsOpen else { return }
        doorsOpen = false
        setMessage(Loc.s("doorsShut", lang), 1.6)
    }
}
