import UIKit

struct PanelButton {
    let id: String
    let line1: String
    let line2: String
    let color: UIColor
    let x: Int
    let y: Int
    let w: Int
    let h: Int

    func contains(_ px: Int, _ py: Int) -> Bool {
        px >= x && px < x + w && py >= y && py < y + h
    }
}

struct PanelLayout {
    let w: Int
    let h: Int
    let top = 118

    var leverX: Int { 6 }
    var leverY: Int { top + 10 }
    var leverW: Int { 58 }
    var leverH: Int { 126 }

    var gaugeR: Int { 23 }
    var gaugeAX: Int { 96 }
    var gaugeBX: Int { 148 }
    var gaugeY: Int { top + 40 }

    var speedoX: Int { 178 }
    var speedoY: Int { top + 4 }
    var speedoW: Int { 132 }
    var speedoH: Int { 88 }

    var rightX: Int { speedoX + speedoW + 8 }
    var rightW: Int { max(90, w - rightX - 6) }

    var row1Y: Int { top + 96 }
    var row2Y: Int { top + 124 }
    var rowH: Int { 26 }
    var btnX0: Int { 70 }
    var emergencyR: Int { 15 }
    var emergencyX: Int { w - 26 }
    var emergencyY: Int { row2Y + 12 }

    func buttons(_ lang: Lang) -> [PanelButton] {
        var out: [PanelButton] = []
        let x1 = w - 8 - 44
        let area = x1 - btnX0
        let gap = 3

        let r1: [(String, String, String, UIColor)] = [
            ("doorsLeft", Loc.s("bDoorsL1", lang), Loc.s("bDoorsL2", lang), .rgb(0xE8E8E8)),
            ("doorsRight", Loc.s("bDoorsR1", lang), Loc.s("bDoorsR2", lang), .rgb(0xE8E8E8)),
            ("autostop", Loc.s("bAuto1", lang), Loc.s("bAuto2", lang), .rgb(0x35C463)),
            ("headlights", Loc.s("bLamp1", lang), Loc.s("bLamp2", lang), .rgb(0xE8B33C)),
            ("cabin", Loc.s("bCabin1", lang), Loc.s("bCabin2", lang), .rgb(0xE8E8E8)),
            ("sand", Loc.s("bSand1", lang), Loc.s("bSand2", lang), .rgb(0xC8A06A))
        ]
        let bw1 = (area - gap * (r1.count - 1)) / r1.count
        for (i, b) in r1.enumerated() {
            out.append(PanelButton(id: b.0, line1: b.1, line2: b.2, color: b.3,
                                   x: btnX0 + i * (bw1 + gap), y: row1Y, w: bw1, h: rowH))
        }

        let r2: [(String, String, String, UIColor)] = [
            ("closeDoors", Loc.s("bClose1", lang), Loc.s("bClose2", lang), .rgb(0x35C463)),
            ("horn", Loc.s("bHorn1", lang), Loc.s("bHorn2", lang), .rgb(0x2F3740)),
            ("announce", Loc.s("bAnn1", lang), Loc.s("bAnn2", lang), .rgb(0xE8B33C)),
            ("als", Loc.s("bAls1", lang), Loc.s("bAls2", lang), .rgb(0x4A9BE8)),
            ("reset", Loc.s("bReset1", lang), Loc.s("bReset2", lang), .rgb(0xE8E8E8))
        ]
        let bw2 = (area - gap * (r2.count - 1)) / r2.count
        for (i, b) in r2.enumerated() {
            out.append(PanelButton(id: b.0, line1: b.1, line2: b.2, color: b.3,
                                   x: btnX0 + i * (bw2 + gap), y: row2Y, w: bw2, h: rowH))
        }
        return out
    }

    func hitLever(_ px: Int, _ py: Int) -> Bool {
        px >= leverX - 4 && px < leverX + leverW + 8 && py >= leverY - 6 && py < leverY + leverH + 10
    }

    func hitEmergency(_ px: Int, _ py: Int) -> Bool {
        let dx = px - emergencyX, dy = py - emergencyY
        return dx * dx + dy * dy <= (emergencyR + 4) * (emergencyR + 4)
    }

    func leverValue(_ py: Int) -> Double {
        let t = Double(py - leverY) / Double(leverH)
        return max(-1, min(1, 1 - t * 2))
    }
}

enum PanelRenderer {

    static func draw(_ g: Pix, _ st: GameState, _ layout: PanelLayout, pressed: String?) {
        let spec = st.spec
        let top = layout.top
        g.rect(0, top, g.width, g.height - top, spec.panelFace)
        g.rect(0, top, g.width, 2, spec.panelLight)
        g.rect(0, top + 2, g.width, 1, spec.panelFace.shade(0.1))

        lever(g, st, layout)
        gauges(g, st, layout)
        speedometer(g, st, layout)
        rightBlock(g, st, layout)
        buttons(g, st, layout, pressed: pressed)
        emergency(g, st, layout, pressed: pressed == "emergency")
    }

    private static func lever(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let spec = st.spec
        let x = l.leverX, y = l.leverY, w = l.leverW, h = l.leverH
        g.bevel(x, y - 6, w, h + 14, face: spec.panelDark, light: spec.panelFace, dark: .rgb(0x111519))

        let cx = x + w / 2
        g.rect(cx - 3, y, 6, h, .rgb(0x14181C))
        g.rect(cx - 3, y, 1, h, .rgb(0x2E353D))

        for i in 0...8 {
            let ty = y + i * h / 8
            let major = i % 4 == 0
            g.rect(cx + 5, ty, major ? 9 : 5, 1, major ? .rgb(0xE0E6EC) : .rgb(0x9AA2AA))
        }
        g.text(Loc.s("lThrottle", st.lang), cx + 16, y - 3, size: 6, color: .rgb(0xB8E8C0), align: .left)
        g.text("0", cx + 16, y + h / 2 - 4, size: 7, color: .rgb(0xE0E6EC), align: .left)
        g.text(Loc.s("lBrake", st.lang), cx + 16, y + h - 8, size: 6, color: .rgb(0xF0B0A8), align: .left)

        let t = (1 - st.controller) / 2
        let ky = y + Int(t * Double(h))
        g.rect(cx - 12, ky - 5, 24, 10, .rgb(0x2A3038))
        g.bevel(cx - 11, ky - 4, 22, 8, face: .rgb(0x4A525C), light: .rgb(0x707A86), dark: .rgb(0x1A1F24))
        g.circle(cx, ky, 7, .rgb(0x22272E))
        g.circle(cx, ky, 6, .rgb(0x3E4650))
        g.circle(cx - 1, ky - 1, 4, .rgb(0x5A6470))
        g.circle(cx - 2, ky - 2, 2, .rgb(0x7E8894))
    }

    private static func gauges(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let brake = max(0.0, -min(0.0, st.controller))
        gauge(g, l.gaugeAX, l.gaugeY, l.gaugeR, value: brake, maxValue: 1.0,
              caption: "\u{041C}\u{041F}\u{0410}", ticks: 8, red: 0.85)
        let reservoir = 0.55 + 0.25 * sin(st.time * 0.4)
        gauge(g, l.gaugeBX, l.gaugeY, l.gaugeR, value: reservoir, maxValue: 1.0,
              caption: "\u{041D}\u{041C}", ticks: 6, red: 0.95)
    }

    private static func gauge(_ g: Pix, _ cx: Int, _ cy: Int, _ r: Int,
                              value: Double, maxValue: Double, caption: String,
                              ticks: Int, red: Double) {
        g.circle(cx, cy, r + 2, .rgb(0x1A1F24))
        g.circle(cx, cy, r, .rgb(0x2E353D))
        g.circle(cx, cy, r - 2, .rgb(0xEFEDE6))
        g.circle(cx - 1, cy - 1, r - 3, .rgb(0xF8F6F0))

        for i in 0...ticks {
            let a = Double.pi * 0.75 + Double(i) / Double(ticks) * Double.pi * 1.5
            let isRed = Double(i) / Double(ticks) >= red
            let (x1, y1) = g.polar(cx, cy, Double(r - 4), a)
            let (x2, y2) = g.polar(cx, cy, Double(r - 9), a)
            g.line(x1, y1, x2, y2, isRed ? .rgb(0xC02020) : .rgb(0x1A1F24))
            if i % 2 == 0 {
                let (tx, ty) = g.polar(cx, cy, Double(r - 14), a)
                g.text("\(i)", tx, ty - 3, size: 5.5, color: .rgb(0x2A2F36), align: .center)
            }
        }

        let a = Double.pi * 0.75 + min(1, value / maxValue) * Double.pi * 1.5
        let (nx, ny) = g.polar(cx, cy, Double(r - 6), a)
        g.line(cx, cy, nx, ny, .rgb(0xC02020), 2)
        g.circle(cx, cy, 3, .rgb(0x2A2F36))
        g.text(caption, cx, cy + 5, size: 5.5, color: .rgb(0x5A6068), align: .center)
    }

    private static func speedometer(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let x = l.speedoX, y = l.speedoY, w = l.speedoW, h = l.speedoH
        g.bevel(x, y, w, h, face: .rgb(0x0B0E12), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        g.frame(x + 1, y + 1, w - 2, h - 2, .rgb(0x151A20))

        let cx = x + w / 2
        let cy = y + h - 10
        let r = min(w / 2 - 8, h - 20)
        let maxV = Int(st.spec.maxSpeed)
        let step = maxV <= 130 ? 10 : (maxV <= 180 ? 20 : 25)
        let minor = max(1, step / 5)
        let speedKmh = st.speed * 3.6
        let limit = st.speedLimit

        var v = 0
        while v <= maxV {
            let f = Double(v) / Double(maxV)
            let a = Double.pi + f * Double.pi
            let major = v % step == 0
            let lit = Double(v) <= speedKmh + 0.01
            let over = Double(v) > limit
            var color = UIColor.rgb(0x39424C)
            if lit { color = over ? .rgb(0xF04030) : .rgb(0xF2F6FA) }
            else if over { color = .rgb(0x5A2A24) }
            let (x1, y1) = g.polar(cx, cy, Double(r), a)
            let (x2, y2) = g.polar(cx, cy, Double(r - (major ? 8 : 4)), a)
            g.line(x1, y1, x2, y2, color, major ? 2 : 1)
            if major && v > 0 && v < maxV {
                let (tx, ty) = g.polar(cx, cy, Double(r - 16), a)
                g.text("\(v)", tx, ty - 4, size: 7, color: .rgb(0xC8D2DC), align: .center)
            }
            v += minor
        }
        g.text("0", cx - r + 6, cy - 8, size: 7, color: .rgb(0xC8D2DC), align: .center)
        g.text("\(maxV)", cx + r - 8, cy - 8, size: 7, color: .rgb(0xC8D2DC), align: .center)

        let shown = Int(speedKmh.rounded())
        let dw = 15, dh = 30
        let total = 3 * dw + 2 * 4
        g.seg7Number(shown, digits: 3, cx - total / 2, cy - 40, dw, dh, gap: 4,
                     on: .rgb(0xFFFFFF), off: .rgb(0x161C22))

        let barW = w - 24
        g.rect(cx - barW / 2, cy - 2, barW, 3, .rgb(0x1A2028))
        let f = min(1.0, speedKmh / Double(maxV))
        g.rect(cx - barW / 2, cy - 2, Int(Double(barW) * f), 3,
               speedKmh > limit ? .rgb(0xF04030) : .rgb(0x3A6EE0))
    }

    private static func rightBlock(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let spec = st.spec
        let x = l.rightX, w = l.rightW
        var y = l.top + 4

        g.bevel(x, y, w, 30, face: .rgb(0x1A1F24), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        g.rect(x + 2, y + 2, w - 4, 26, spec.lcd)
        var lcdText = Loc.s("lcdIdle", st.lang)
        if let s = st.currentStation {
            let d = Int(max(0, s.pos - st.distance))
            switch st.phase {
            case .running: lcdText = "\(s.name(st.lang))  \(d) \(Loc.s("m", st.lang))"
            case .arrived: lcdText = "\(s.name(st.lang)) — \(Loc.s("lcdOpen", st.lang))"
            case .boarding: lcdText = "\(s.name(st.lang)) — \(Loc.s("lcdBoard", st.lang))"
            case .ready: lcdText = "\(s.name(st.lang)) — \(Loc.s("lcdDepart", st.lang))"
            }
        }
        g.text(lcdText, x + 6, y + 5, size: 9, color: spec.lcdInk, align: .left, mono: true)
        if !st.message.isEmpty {
            g.text(st.message, x + 6, y + 16, size: 7, color: spec.lcdInk, align: .left)
        }

        y += 34
        let barW = w
        g.bevel(x, y, barW, 16, face: .rgb(0x14181C), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        let mid = x + barW / 2
        g.rect(mid, y + 2, 1, 12, .rgb(0x5A626A))
        let ctrl = st.controller
        if ctrl > 0 {
            g.rect(mid + 1, y + 3, Int(Double(barW / 2 - 3) * ctrl), 10, .rgb(0x35C463))
        } else if ctrl < 0 {
            let ww = Int(Double(barW / 2 - 3) * -ctrl)
            g.rect(mid - 1 - ww, y + 3, ww, 10, .rgb(0xE04A3A))
        }
        for i in 0...8 {
            let tx = x + 2 + i * (barW - 4) / 8
            g.rect(tx, y + 13, 1, 2, .rgb(0x6E767E))
        }

        y += 20
        g.bevel(x, y, w, 26, face: .rgb(0x1A1F24), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        let green = (st.signalAhead()?.pos ?? 1e9) > st.distance
        g.circle(x + 12, y + 13, 6, .rgb(0x0A0D10))
        g.circle(x + 12, y + 13, 5, green ? .rgb(0x30E070) : .rgb(0xF04030))
        g.text(Loc.s("als", st.lang), x + 24, y + 3, size: 6, color: .rgb(0x8A939C), align: .left)
        g.seg7Number(Int(st.speedLimit), digits: 3, x + 24, y + 10, 8, 13, gap: 3,
                     on: .rgb(0xF0C040), off: .rgb(0x2A2418))
        let sideText = st.currentStation.map { $0.side == .left ? Loc.s("sideLeft", st.lang) : Loc.s("sideRight", st.lang) } ?? "—"
        g.text(Loc.s("platform", st.lang), x + w - 6, y + 3, size: 6, color: .rgb(0x8A939C), align: .right)
        g.text(sideText, x + w - 6, y + 12, size: 9, color: .rgb(0xF2F6FA), align: .right)
    }

    private static func buttons(_ g: Pix, _ st: GameState, _ l: PanelLayout, pressed: String?) {
        for b in l.buttons(st.lang) {
            let on = isOn(b.id, st)
            drawButton(g, b, on: on, pressed: pressed == b.id, panel: st.spec.panelDark)
        }
    }

    private static func isOn(_ id: String, _ st: GameState) -> Bool {
        switch id {
        case "doorsLeft": return st.doorsOpen && st.doorSide == .left
        case "doorsRight": return st.doorsOpen && st.doorSide == .right
        case "autostop": return st.autoStop
        case "headlights": return st.headlights
        case "cabin": return st.cabinLight
        case "sand": return st.sand
        case "horn": return st.horn > 0
        case "als": return true
        default: return false
        }
    }

    private static func drawButton(_ g: Pix, _ b: PanelButton, on: Bool, pressed: Bool, panel: UIColor) {
        g.bevel(b.x, b.y, b.w, 11, face: .rgb(0x30363E), light: .rgb(0x4C545E), dark: .rgb(0x14181C))
        if b.line2.isEmpty {
            g.text(b.line1, b.x + b.w / 2, b.y + 2, size: 6.5, color: .rgb(0xE4E9EE), align: .center)
        } else {
            g.text(b.line1, b.x + b.w / 2, b.y - 1, size: 6, color: .rgb(0xE4E9EE), align: .center)
            g.text(b.line2, b.x + b.w / 2, b.y + 5, size: 6, color: .rgb(0xE4E9EE), align: .center)
        }

        let cx = b.x + b.w / 2
        let cy = b.y + 19 + (pressed ? 1 : 0)
        let r = 8
        g.circle(cx, cy + 1, r + 1, .rgb(0x14181C))
        g.circle(cx, cy, r, .rgb(0x39414A))
        let face = on ? b.color : b.color.shade(-0.45)
        g.circle(cx, cy, r - 2, face)
        if pressed {
            g.circle(cx, cy + 1, r - 3, face.shade(-0.15))
        } else {
            g.circle(cx - 1, cy - 1, r - 4, face.shade(0.22))
            g.circle(cx - 2, cy - 2, r - 6, face.shade(0.4))
        }
        if on {
            g.rect(cx - r, cy - r - 2, 2, 2, b.color)
            g.rect(cx + r - 1, cy - r - 2, 2, 2, b.color)
        }
    }

    private static func emergency(_ g: Pix, _ st: GameState, _ l: PanelLayout, pressed: Bool) {
        let cx = l.emergencyX, cy = l.emergencyY, r = l.emergencyR
        g.text(Loc.s("bStop1", st.lang), cx, l.row2Y - 8, size: 6, color: .rgb(0xE4E9EE), align: .center)
        g.circle(cx, cy + 1, r + 2, .rgb(0x14181C))
        g.circle(cx, cy, r, .rgb(0xE8C13A))
        g.circle(cx, cy, r - 3, st.emergency ? .rgb(0xF05040) : .rgb(0xB0261B))
        if !pressed {
            g.circle(cx - 1, cy - 1, r - 6, st.emergency ? .rgb(0xF87060) : .rgb(0xC8342A))
        }
        g.circle(cx, cy, r - 9, .rgb(0x8A1C14))
    }

    static func overlay(_ g: Pix, _ st: GameState) {
        g.bevel(6, 4, 78, 15, face: .rgb(0x14181C), light: .rgb(0x39414A), dark: .rgb(0x05070A))
        let total = Int(st.clock)
        let hh = (total / 3600) % 24
        let mm = (total / 60) % 60
        let ss = total % 60
        g.seg7Number(hh, digits: 2, 10, 7, 6, 9, gap: 2, on: .rgb(0xF08018), off: .rgb(0x2A1808), leadingBlank: false)
        g.rect(28, 14, 2, 2, .rgb(0xF08018))
        g.seg7Number(mm, digits: 2, 32, 7, 6, 9, gap: 2, on: .rgb(0xF08018), off: .rgb(0x2A1808), leadingBlank: false)
        g.rect(50, 14, 2, 2, .rgb(0xF08018))
        g.seg7Number(ss, digits: 2, 54, 7, 6, 9, gap: 2, on: .rgb(0xF08018), off: .rgb(0x2A1808), leadingBlank: false)

        g.bevel(88, 4, 54, 15, face: .rgb(0x14181C), light: .rgb(0x39414A), dark: .rgb(0x05070A))
        g.text(Loc.s("score", st.lang), 92, 6, size: 6, color: .rgb(0x8A939C), align: .left)
        g.text("\(st.score)", 138, 5, size: 9, color: .rgb(0x60E890), align: .right)
    }
}
