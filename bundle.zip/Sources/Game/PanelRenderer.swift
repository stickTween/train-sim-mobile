import UIKit

struct PanelButton {
    let id: String
    let line1: String
    let line2: String
    let color: UIColor
    let x: Int
    let y: Int
    let w: Int
    let h: Int
    func contains(_ px: Int, _ py: Int) -> Bool {
        px >= x && px < x + w && py >= y && py < y + h
    }
}

struct PanelLayout {
    let w: Int
    let h: Int
    let top = 118

    var leverX: Int { 6 }
    var leverY: Int { top + 10 }
    var leverW: Int { 58 }
    var leverH: Int { 126 }

    var gaugeR: Int { 23 }
    var gaugeAX: Int { 96 }
    var gaugeBX: Int { 148 }
    var gaugeY: Int { top + 40 }

    var speedoX: Int { 178 }
    var speedoY: Int { top + 4 }
    var speedoW: Int { 132 }
    var speedoH: Int { 88 }

    var rightX: Int { speedoX + speedoW + 8 }
    var rightW: Int { max(90, w - rightX - 6) }

    var row1Y: Int { top + 96 }
    var row2Y: Int { top + 124 }
    var rowH: Int { 26 }
    var btnX0: Int { 70 }
    var emergencyR: Int { 15 }
    var emergencyX: Int { w - 26 }
    var emergencyY: Int { row2Y + 12 }

    var pauseX: Int { w - 22 }
    var pauseY: Int { 5 }
    var pauseS: Int { 17 }

    func hitPause(_ px: Int, _ py: Int) -> Bool {
        px >= pauseX - 5 && px < pauseX + pauseS + 5 && py >= pauseY - 5 && py < pauseY + pauseS + 5
    }

    func buttons(_ lang: Lang) -> [PanelButton] {
        var out: [PanelButton] = []
        let x1 = w - 8 - 44
        let area = x1 - btnX0
        let gap = 3
        let r1: [(String, String, String, UIColor)] = [
            ("doorsLeft", Loc.s("bDoorsL1", lang), Loc.s("bDoorsL2", lang), .rgb(0xE8E8E8)),
            ("doorsRight", Loc.s("bDoorsR1", lang), Loc.s("bDoorsR2", lang), .rgb(0xE8E8E8)),
            ("autostop", Loc.s("bAuto1", lang), Loc.s("bAuto2", lang), .rgb(0x35C463)),
            ("headlights", Loc.s("bLamp1", lang), Loc.s("bLamp2", lang), .rgb(0xE8B33C)),
            ("cabin", Loc.s("bCabin1", lang), Loc.s("bCabin2", lang), .rgb(0xE8E8E8)),
            ("sand", Loc.s("bSand1", lang), Loc.s("bSand2", lang), .rgb(0xC8A06A))
        ]
        let bw1 = (area - gap * (r1.count - 1)) / r1.count
        for (i, b) in r1.enumerated() {
            out.append(PanelButton(id: b.0, line1: b.1, line2: b.2, color: b.3,
                                   x: btnX0 + i * (bw1 + gap), y: row1Y, w: bw1, h: rowH))
        }
        let r2: [(String, String, String, UIColor)] = [
            ("closeDoors", Loc.s("bClose1", lang), Loc.s("bClose2", lang), .rgb(0x35C463)),
            ("horn", Loc.s("bHorn1", lang), Loc.s("bHorn2", lang), .rgb(0x9AA4AE)),
            ("announce", Loc.s("bAnn1", lang), Loc.s("bAnn2", lang), .rgb(0xE8B33C)),
            ("als", Loc.s("bAls1", lang), Loc.s("bAls2", lang), .rgb(0x4A9BE8)),
            ("cam", Loc.s("bCam1", lang), Loc.s("bCam2", lang), .rgb(0xB07AE0))
        ]
        let bw2 = (area - gap * (r2.count - 1)) / r2.count
        for (i, b) in r2.enumerated() {
            out.append(PanelButton(id: b.0, line1: b.1, line2: b.2, color: b.3,
                                   x: btnX0 + i * (bw2 + gap), y: row2Y, w: bw2, h: rowH))
        }
        return out
    }

    func button(_ id: String, _ lang: Lang) -> PanelButton? {
        buttons(lang).first { $0.id == id }
    }

    func hitLever(_ px: Int, _ py: Int) -> Bool {
        px >= leverX - 4 && px < leverX + leverW + 8 && py >= leverY - 6 && py < leverY + leverH + 10
    }

    func hitEmergency(_ px: Int, _ py: Int) -> Bool {
        let dx = px - emergencyX, dy = py - emergencyY
        return dx * dx + dy * dy <= (emergencyR + 4) * (emergencyR + 4)
    }

    func leverValue(_ py: Int) -> Double {
        max(-1, min(1, 1 - Double(py - leverY) / Double(leverH) * 2))
    }
}

enum PanelRenderer {

    static func draw(_ g: Pix, _ st: GameState, _ l: PanelLayout, pressed: String?) {
        let spec = st.spec
        g.rect(0, l.top, g.width, g.height - l.top, spec.panelFace)
        g.rect(0, l.top, g.width, 2, spec.panelLight)

        lever(g, st, l)
        gauges(g, st, l)
        speedometer(g, st, l)
        rightBlock(g, st, l)
        buttons(g, st, l, pressed: pressed)
        emergency(g, st, l, pressed: pressed == "emergency")
        pauseButton(g, l)
        topStrip(g, st, l)
        toasts(g, st, l)
    }

    private static func pauseButton(_ g: Pix, _ l: PanelLayout) {
        g.bevel(l.pauseX, l.pauseY, l.pauseS, l.pauseS, face: .rgb(0x1A1F26),
                light: .rgb(0x555F6A), dark: .rgb(0x05070A))
        g.rect(l.pauseX + 5, l.pauseY + 4, 3, l.pauseS - 8, .rgb(0xE8EDF2))
        g.rect(l.pauseX + 10, l.pauseY + 4, 3, l.pauseS - 8, .rgb(0xE8EDF2))
    }

    private static func topStrip(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let text = "\(st.clockString())   \(Loc.s("score", st.lang)) \(st.score)"
        let tw = g.textWidth(text, size: 8) + 12
        g.rect(5, 4, tw, 14, .rgb(0x10161E))
        g.frame(5, 4, tw, 14, .rgb(0x394452))
        g.text(text, 11, 6, size: 8, color: .rgb(0xBFD4E6), align: .left, mono: true)
        if abs(st.camOffset) > 1 {
            let t = Loc.s("freeCam", st.lang)
            let cw = g.textWidth(t, size: 7) + 10
            g.rect(5, 20, cw, 12, .rgb(0x2A1F3A))
            g.frame(5, 20, cw, 12, .rgb(0x7A5AB0))
            g.text(t, 10, 22, size: 7, color: .rgb(0xD4BCF0), align: .left)
        }
    }

    private static func toasts(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        var y = l.top - 16
        for t in st.toasts.reversed() {
            let fade = min(1.0, t.life / 0.7)
            let tw = g.textWidth(t.text, size: 8) + 18
            let x = g.width / 2 - tw / 2
            let bg = t.bad ? UIColor.rgb(0x3A1010) : UIColor.rgb(0x0E2A18)
            let fg = t.bad ? UIColor.rgb(0xFF9A88) : UIColor.rgb(0x8CF0B0)
            let edge = t.bad ? UIColor.rgb(0xA02A20) : UIColor.rgb(0x2E8A50)
            g.ctx.saveGState()
            g.ctx.setAlpha(CGFloat(fade))
            g.rect(x, y, tw, 14, bg)
            g.frame(x, y, tw, 14, edge)
            g.rect(x, y, 3, 14, edge)
            g.text(t.text, x + tw / 2 + 1, y + 2, size: 8, color: fg, align: .center)
            g.ctx.restoreGState()
            y -= 17
        }
    }

    private static func lever(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let spec = st.spec
        let x = l.leverX, y = l.leverY, w = l.leverW, h = l.leverH
        g.bevel(x, y - 6, w, h + 14, face: spec.panelDark, light: spec.panelFace, dark: .rgb(0x111519))
        let cx = x + w / 2
        g.rect(cx - 3, y, 6, h, .rgb(0x14181C))
        for i in 0...8 {
            let ty = y + i * h / 8
            let major = i % 4 == 0
            g.rect(cx + 5, ty, major ? 9 : 5, 1, major ? .rgb(0xE0E6EC) : .rgb(0x9AA2AA))
        }
        g.text(Loc.s("lThrottle", st.lang), cx + 16, y - 3, size: 6, color: .rgb(0xB8E8C0), align: .left)
        g.text("0", cx + 16, y + h / 2 - 4, size: 7, color: .rgb(0xE0E6EC), align: .left)
        g.text(Loc.s("lBrake", st.lang), cx + 16, y + h - 8, size: 6, color: .rgb(0xF0B0A8), align: .left)
        let ky = y + Int((1 - st.controller) / 2 * Double(h))
        g.bevel(cx - 11, ky - 4, 22, 8, face: .rgb(0x4A525C), light: .rgb(0x707A86), dark: .rgb(0x1A1F24))
        g.circle(cx, ky, 7, .rgb(0x22272E))
        g.circle(cx, ky, 6, .rgb(0x3E4650))
        g.circle(cx - 1, ky - 1, 4, .rgb(0x5A6470))
        g.circle(cx - 2, ky - 2, 2, .rgb(0x7E8894))
    }

    private static func gauges(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        gauge(g, l.gaugeAX, l.gaugeY, l.gaugeR, value: max(0, -min(0, st.controller)),
              caption: "\u{0422}\u{0426}", ticks: 8, red: 0.85)
        gauge(g, l.gaugeBX, l.gaugeY, l.gaugeR, value: 0.55 + 0.25 * sin(st.time * 0.4),
              caption: "\u{041D}\u{041C}", ticks: 6, red: 0.95)
    }

    private static func gauge(_ g: Pix, _ cx: Int, _ cy: Int, _ r: Int, value: Double,
                              caption: String, ticks: Int, red: Double) {
        g.circle(cx, cy, r + 2, .rgb(0x1A1F24))
        g.circle(cx, cy, r, .rgb(0x2E353D))
        g.circle(cx, cy, r - 2, .rgb(0xEFEDE6))
        g.circle(cx - 1, cy - 1, r - 3, .rgb(0xF8F6F0))
        for i in 0...ticks {
            let a = Double.pi * 0.75 + Double(i) / Double(ticks) * Double.pi * 1.5
            let isRed = Double(i) / Double(ticks) >= red
            let (x1, y1) = g.polar(cx, cy, Double(r - 4), a)
            let (x2, y2) = g.polar(cx, cy, Double(r - 9), a)
            g.line(x1, y1, x2, y2, isRed ? .rgb(0xC02020) : .rgb(0x1A1F24))
            if i % 2 == 0 {
                let (tx, ty) = g.polar(cx, cy, Double(r - 14), a)
                g.text("\(i)", tx, ty - 3, size: 5.5, color: .rgb(0x2A2F36), align: .center)
            }
        }
        let a = Double.pi * 0.75 + min(1, max(0, value)) * Double.pi * 1.5
        let (nx, ny) = g.polar(cx, cy, Double(r - 6), a)
        g.line(cx, cy, nx, ny, .rgb(0xC02020), 2)
        g.circle(cx, cy, 3, .rgb(0x2A2F36))
        g.text(caption, cx, cy + 5, size: 5.5, color: .rgb(0x5A6068), align: .center)
    }

    private static func speedometer(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let x = l.speedoX, y = l.speedoY, w = l.speedoW, h = l.speedoH
        g.bevel(x, y, w, h, face: .rgb(0x0B0E12), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        let cx = x + w / 2
        let cy = y + h - 10
        let r = min(w / 2 - 8, h - 20)
        let maxV = Int(st.spec.maxSpeed)
        let step = maxV <= 130 ? 20 : (maxV <= 180 ? 20 : 50)
        let minor = max(1, step / 4)
        let kmh = st.speed * 3.6
        let limit = st.speedLimit
        var v = 0
        while v <= maxV {
            let a = Double.pi + Double(v) / Double(maxV) * Double.pi
            let major = v % step == 0
            let lit = Double(v) <= kmh + 0.01
            let over = Double(v) > limit
            var color = UIColor.rgb(0x39424C)
            if lit { color = over ? .rgb(0xF04030) : .rgb(0xF2F6FA) }
            else if over { color = .rgb(0x5A2A24) }
            let (x1, y1) = g.polar(cx, cy, Double(r), a)
            let (x2, y2) = g.polar(cx, cy, Double(r - (major ? 8 : 4)), a)
            g.line(x1, y1, x2, y2, color, major ? 2 : 1)
            if major && v > 0 && v < maxV {
                let (tx, ty) = g.polar(cx, cy, Double(r - 16), a)
                g.text("\(v)", tx, ty - 4, size: 7, color: .rgb(0xC8D2DC), align: .center)
            }
            v += minor
        }
        let dw = 15, dh = 30
        g.seg7Number(Int(kmh.rounded()), digits: 3, cx - (3 * dw + 8) / 2, cy - 40, dw, dh,
                     gap: 4, on: .rgb(0xFFFFFF), off: .rgb(0x161C22))
        let barW = w - 24
        g.rect(cx - barW / 2, cy - 2, barW, 3, .rgb(0x1A2028))
        g.rect(cx - barW / 2, cy - 2, Int(Double(barW) * min(1, kmh / Double(maxV))), 3,
               kmh > limit ? .rgb(0xF04030) : .rgb(0x3A6EE0))
    }

    private static func rightBlock(_ g: Pix, _ st: GameState, _ l: PanelLayout) {
        let spec = st.spec
        let x = l.rightX, w = l.rightW
        var y = l.top + 4
        g.bevel(x, y, w, 30, face: .rgb(0x1A1F24), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        g.rect(x + 2, y + 2, w - 4, 26, spec.lcd)
        var line1 = Loc.s("lcdIdle", st.lang)
        var line2 = ""
        if let s = st.currentStop {
            line1 = s.name(st.lang)
            let d = Int(max(0, s.pos - st.distance))
            switch st.phase {
            case .running: line2 = "\(d) \(Loc.s("m", st.lang))"
            case .arrived: line2 = Loc.s("lcdOpen", st.lang)
            case .boarding: line2 = Loc.s("lcdBoard", st.lang)
            case .ready: line2 = Loc.s("lcdDepart", st.lang)
            case .crashed: line2 = Loc.s("eCrash", st.lang)
            case .finished: line2 = Loc.s("routeDone", st.lang)
            }
        }
        g.text(line1, x + 6, y + 3, size: 9, color: spec.lcdInk, align: .left, mono: true)
        g.text(line2, x + 6, y + 16, size: 7, color: spec.lcdInk, align: .left)

        y += 34
        g.bevel(x, y, w, 16, face: .rgb(0x14181C), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        let mid = x + w / 2
        g.rect(mid, y + 2, 1, 12, .rgb(0x5A626A))
        if st.controller > 0 {
            g.rect(mid + 1, y + 3, Int(Double(w / 2 - 3) * st.controller), 10, .rgb(0x35C463))
        } else if st.controller < 0 {
            let ww = Int(Double(w / 2 - 3) * -st.controller)
            g.rect(mid - 1 - ww, y + 3, ww, 10, .rgb(0xE04A3A))
        }

        y += 20
        g.bevel(x, y, w, 26, face: .rgb(0x1A1F24), light: .rgb(0x3A424C), dark: .rgb(0x05070A))
        let green = st.signalGreen(at: st.distance + 40)
        g.circle(x + 12, y + 13, 6, .rgb(0x0A0D10))
        g.circle(x + 12, y + 13, 5, green ? .rgb(0x30E070) : .rgb(0xF04030))
        g.text(Loc.s("als", st.lang), x + 24, y + 2, size: 6, color: .rgb(0x8A939C), align: .left)
        g.seg7Number(Int(st.speedLimit), digits: 3, x + 24, y + 10, 8, 13, gap: 3,
                     on: .rgb(0xF0C040), off: .rgb(0x2A2418))
        let side = st.currentStop.map { $0.side == .left ? Loc.s("sideLeft", st.lang) : Loc.s("sideRight", st.lang) } ?? "—"
        g.text(Loc.s("platform", st.lang), x + w - 6, y + 2, size: 6, color: .rgb(0x8A939C), align: .right)
        g.text(side, x + w - 6, y + 11, size: 9, color: .rgb(0xF2F6FA), align: .right)
    }

    private static func buttons(_ g: Pix, _ st: GameState, _ l: PanelLayout, pressed: String?) {
        for b in l.buttons(st.lang) {
            drawButton(g, b, on: isOn(b.id, st), pressed: pressed == b.id)
        }
    }

    static func isOn(_ id: String, _ st: GameState) -> Bool {
        switch id {
        case "doorsLeft": return st.doorsOpen && st.doorSide == .left
        case "doorsRight": return st.doorsOpen && st.doorSide == .right
        case "autostop": return st.autoStop
        case "headlights": return st.headlights
        case "cabin": return st.cabinLight
        case "sand": return st.sand
        case "horn": return st.horn > 0
        case "cam": return abs(st.camOffset) > 1
        case "als": return true
        default: return false
        }
    }

    private static func drawButton(_ g: Pix, _ b: PanelButton, on: Bool, pressed: Bool) {
        g.bevel(b.x, b.y, b.w, 11, face: .rgb(0x30363E), light: .rgb(0x4C545E), dark: .rgb(0x14181C))
        if b.line2.isEmpty {
            g.text(b.line1, b.x + b.w / 2, b.y + 2, size: 6.5, color: .rgb(0xE4E9EE), align: .center)
        } else {
            g.text(b.line1, b.x + b.w / 2, b.y - 1, size: 6, color: .rgb(0xE4E9EE), align: .center)
            g.text(b.line2, b.x + b.w / 2, b.y + 5, size: 6, color: .rgb(0xE4E9EE), align: .center)
        }
        let cx = b.x + b.w / 2
        let cy = b.y + 19 + (pressed ? 1 : 0)
        let r = 8
        g.circle(cx, cy + 1, r + 1, .rgb(0x14181C))
        g.circle(cx, cy, r, .rgb(0x39414A))
        let face = on ? b.color : b.color.shade(-0.45)
        g.circle(cx, cy, r - 2, face)
        if pressed {
            g.circle(cx, cy + 1, r - 3, face.shade(-0.15))
        } else {
            g.circle(cx - 1, cy - 1, r - 4, face.shade(0.22))
            g.circle(cx - 2, cy - 2, r - 6, face.shade(0.4))
        }
        if on {
            g.rect(cx - r, cy - r - 2, 2, 2, b.color)
            g.rect(cx + r - 1, cy - r - 2, 2, 2, b.color)
        }
    }

    private static func emergency(_ g: Pix, _ st: GameState, _ l: PanelLayout, pressed: Bool) {
        let cx = l.emergencyX, cy = l.emergencyY, r = l.emergencyR
        g.text(Loc.s("bStop1", st.lang), cx, l.row2Y - 8, size: 6, color: .rgb(0xE4E9EE), align: .center)
        g.circle(cx, cy + 1, r + 2, .rgb(0x14181C))
        g.circle(cx, cy, r, .rgb(0xE8C13A))
        g.circle(cx, cy, r - 3, st.emergency ? .rgb(0xF05040) : .rgb(0xB0261B))
        if !pressed {
            g.circle(cx - 1, cy - 1, r - 6, st.emergency ? .rgb(0xF87060) : .rgb(0xC8342A))
        }
        g.circle(cx, cy, r - 9, .rgb(0x8A1C14))
    }
}
