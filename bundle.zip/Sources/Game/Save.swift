import Foundation

enum Upgrade: String, CaseIterable {
    case autostop
    case pair
    case brakes
    case power
    case autopilot

    var baseCost: Int {
        switch self {
        case .autostop: return 150
        case .pair: return 300
        case .brakes: return 220
        case .power: return 260
        case .autopilot: return 320
        }
    }

    func titleKey() -> String {
        switch self {
        case .autostop: return "upAutostop"
        case .pair: return "upPair"
        case .brakes: return "upBrakes"
        case .power: return "upPower"
        case .autopilot: return "upAuto"
        }
    }

    func descKey() -> String {
        switch self {
        case .autostop: return "upAutostopD"
        case .pair: return "upPairD"
        case .brakes: return "upBrakesD"
        case .power: return "upPowerD"
        case .autopilot: return "upAutoD"
        }
    }
}

enum Save {
    private static let coinsKey = "ts.coins"
    private static let upKey = "ts.up."

    static var coins: Int {
        get { UserDefaults.standard.integer(forKey: coinsKey) }
        set { UserDefaults.standard.set(newValue, forKey: coinsKey) }
    }

    static func owns(_ train: String, _ u: Upgrade) -> Bool {
        UserDefaults.standard.bool(forKey: upKey + train + "." + u.rawValue)
    }

    static func buy(_ train: String, _ u: Upgrade, cost: Int) -> Bool {
        guard coins >= cost, !owns(train, u) else { return false }
        coins -= cost
        UserDefaults.standard.set(true, forKey: upKey + train + "." + u.rawValue)
        return true
    }

    static func addCoins(_ n: Int) {
        coins = max(0, coins + n)
    }
}
