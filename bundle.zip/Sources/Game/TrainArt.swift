import UIKit

enum TrainArt {

    static func noseOutline(_ a: Int, _ b: Int, _ topY: Int, _ floorY: Int,
                            _ style: NoseStyle) -> [(Int, Int)] {
        let h = Double(floorY - topY)
        let cut: Double
        let power: Double
        switch style {
        case .blunt: cut = h * 0.42; power = 0.72
        case .sharp: cut = h * 0.66; power = 1.75
        case .rounded: cut = h * 0.30; power = 0.48
        }
        var pts: [(Int, Int)] = []
        for i in 0...12 {
            let t = Double(i) / 12
            pts.append((a + Int((Double(b - a) * t).rounded()),
                        topY + Int((cut * pow(t, power)).rounded())))
        }
        pts.append((b, floorY))
        pts.append((a, floorY))
        return pts
    }

    static func car(_ g: Pix, spec: TrainSpec, x0: Int, x1: Int, topY: Int, floorY: Int,
                    base: Int, head: Bool, tail: Bool, day: Double,
                    doorAnim: Double, scale: Double, wheelPhase: Double, cabin: Bool) {
        g.ctx.saveGState()
        g.ctx.clip(to: CGRect(x: CGFloat(x0 - 3), y: CGFloat(topY - 22),
                              width: CGFloat(x1 - x0 + 6), height: CGFloat(base - topY + 30)))

        let mix = WorldRenderer.mix
        let h = floorY - topY
        let nose = head ? Int(spec.noseLenM * WorldRenderer.ppm * scale) : 0
        let bodyEnd = x1 - nose
        let dim = max(0.42, day)
        let body = mix(spec.body.shade(-0.58), spec.body, dim)
        let shade = mix(spec.bodyShade.shade(-0.58), spec.bodyShade, dim)
        let roof = mix(spec.roof.shade(-0.58), spec.roof, dim)
        let main = mix(spec.liveryMain.shade(-0.52), spec.liveryMain, dim)
        let alt = mix(spec.liveryAlt.shade(-0.52), spec.liveryAlt, dim)
        let skirt = mix(spec.skirt.shade(-0.55), spec.skirt, dim)

        g.rect(x0, topY, bodyEnd - x0, h, body)
        g.rect(x0, topY, bodyEnd - x0, 4, roof)
        g.rect(x0, topY + 4, bodyEnd - x0, 1, roof.shade(-0.2))

        let bandTop = topY + h * 20 / 100
        let bandH = max(8, h * 30 / 100)

        switch spec.id {
        case "lastochka":
            g.rect(x0, floorY - h * 26 / 100, bodyEnd - x0, h * 26 / 100, main)
            g.rect(x0, floorY - h * 26 / 100 - 2, bodyEnd - x0, 2, main.shade(0.18))
            g.poly([(bodyEnd - 92, floorY - h * 26 / 100), (bodyEnd, floorY - h * 82 / 100),
                    (bodyEnd, floorY - h * 26 / 100)], main)
            g.rect(x0, bandTop - 4, bodyEnd - x0, bandH + 8, mix(.rgb(0x161C24), .rgb(0x2A323C), dim))
        case "sapsan":
            g.rect(x0, bandTop - 3, bodyEnd - x0, bandH + 6, mix(.rgb(0x121A22), .rgb(0x1E2833), dim))
            g.rect(x0, topY + h * 56 / 100, bodyEnd - x0, 4, main)
            g.rect(x0, floorY - h * 20 / 100, bodyEnd - x0, h * 20 / 100, shade)
            g.rect(x0, floorY - h * 20 / 100, bodyEnd - x0, 2, alt)
        default:
            g.rect(x0, bandTop - 4, bodyEnd - x0, bandH + 8, mix(.rgb(0x161C24), .rgb(0x27313C), dim))
            g.rect(x0, floorY - h * 30 / 100, bodyEnd - x0, h * 30 / 100, main)
            g.rect(x0, floorY - h * 30 / 100 - 4, bodyEnd - x0, 4, alt)
        }
        g.rect(x0, floorY - 6, bodyEnd - x0, 6, skirt)

        if head && nose > 0 {
            let outline = noseOutline(bodyEnd, x1 - 1, topY, floorY, spec.nose)
            g.poly(outline, body)
            switch spec.id {
            case "lastochka":
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 4), (x1 - 1, topY + h * 42 / 100),
                        (x1 - 1, topY + h * 56 / 100), (bodyEnd, topY + h * 17 / 100)],
                       mix(.rgb(0x141A22), .rgb(0x22303C), dim))
            case "sapsan":
                g.poly([(x1 - nose * 4 / 10, topY + h * 50 / 100), (x1 - 1, topY + h * 66 / 100),
                        (x1 - 1, floorY), (x1 - nose * 4 / 10, floorY)], alt)
                g.poly([(bodyEnd, topY + h * 56 / 100), (x1 - nose * 4 / 10, topY + h * 64 / 100),
                        (x1 - nose * 4 / 10, topY + h * 70 / 100), (bodyEnd, topY + h * 62 / 100)], main)
                g.poly([(bodyEnd, topY + 5), (x1 - nose / 2, topY + h * 40 / 100),
                        (x1 - nose / 2, topY + h * 54 / 100), (bodyEnd, topY + h * 18 / 100)],
                       mix(.rgb(0x0E141C), .rgb(0x1C2836), dim))
            default:
                g.poly(outline, main)
                g.poly([(bodyEnd, topY + 5), (x1 - 1, topY + h * 27 / 100),
                        (x1 - 1, topY + h * 47 / 100), (bodyEnd, topY + h * 22 / 100)],
                       mix(.rgb(0x141A22), .rgb(0x22303C), dim))
                g.rect(x1 - nose, floorY - 8, nose, 8, alt)
            }
        }

        let night = day < 0.5
        let glass: UIColor = cabin
            ? .rgb(0xF2DC9C)
            : (night ? mix(.rgb(0x0E141C), .rgb(0x1A2836), 0.3) : mix(spec.glass.shade(-0.25), spec.glass, dim))
        let winTop = bandTop + 3
        let winH2 = max(6, bandH - 6)
        let ww: Int
        let stepW: Int
        switch spec.id {
        case "sapsan": ww = 15; stepW = 23
        case "ivolga": ww = 26; stepW = 35
        default: ww = 20; stepW = 29
        }
        let doorW = max(11, Int(18 * scale))
        var doorRanges: [(Int, Int)] = []
        for f in [0.30, 0.72] {
            let dx = x1 - Int(Double(x1 - x0) * f) - doorW / 2
            if dx > x0 + 6 && dx + doorW < bodyEnd - 6 {
                doorRanges.append((dx - 3, dx + doorW + 3))
            }
        }

        var wx = x0 + 7
        let winEnd = head ? bodyEnd - 10 : x1 - 7
        while wx + ww < winEnd {
            if !doorRanges.contains(where: { wx < $0.1 && wx + ww > $0.0 }) {
                g.rect(wx - 1, winTop - 1, ww + 2, winH2 + 2, mix(.rgb(0x0C1016), .rgb(0x1A222C), dim))
                g.rect(wx, winTop, ww, winH2, glass)
                g.rect(wx, winTop, ww, 2, glass.shade(0.25))
                g.rect(wx, winTop + winH2 - 2, ww, 2, glass.shade(-0.32))
            }
            wx += stepW
        }

        for r in doorRanges {
            let dx = r.0 + 3
            let dh = h * 74 / 100
            let dTop = floorY - dh
            g.rect(dx - 3, dTop - 3, doorW + 6, dh + 3, mix(.rgb(0x10151B), .rgb(0x1E242C), dim))
            g.rect(dx, dTop, doorW, dh, .rgb(0x0C1016))
            let open = Int(Double(doorW / 2) * doorAnim)
            let leaf = doorW / 2
            let dcol = mix(spec.doorColor.shade(-0.5), spec.doorColor, dim)
            for side in 0..<2 {
                let lx = side == 0 ? dx - open : dx + leaf + open
                g.rect(lx, dTop, leaf, dh, dcol)
                g.rect(lx, dTop, leaf, 2, dcol.shade(0.28))
                g.rect(lx, dTop + dh - 3, leaf, 3, .rgb(0xE8C93E))
                g.rect(lx + 1, dTop + 4, leaf - 2, dh * 45 / 100, glass)
                g.rect(lx + 1, dTop + 4, leaf - 2, 1, glass.shade(0.3))
            }
        }

        if head {
            let cabW = max(20, Int(42 * scale))
            let cx0 = bodyEnd - cabW
            g.rect(cx0 - 1, topY + 4, cabW + 1, h * 36 / 100 + 2, mix(.rgb(0x080E15), .rgb(0x16202C), dim))
            g.rect(cx0, topY + 6, cabW - 1, h * 36 / 100 - 2, mix(.rgb(0x0A1119), spec.glass, dim))
            g.rect(cx0, topY + 6, cabW - 1, 2, mix(.rgb(0x24303E), spec.glass.shade(0.35), dim))
            let lx = x1 - max(7, Int(11 * scale))
            let ly = floorY - max(9, Int(14 * scale))
            g.rect(lx - 1, ly - 1, 9, 6, mix(.rgb(0x14181C), .rgb(0x2A3038), dim))
            g.rect(lx, ly, 7, 4, night ? .rgb(0xFFF9D0) : .rgb(0xD8DCE0))
            g.rect(lx, ly + 6, 5, 3, .rgb(0xC02020))
        }

        for k in 0..<3 {
            let bx = x0 + 16 + k * ((x1 - x0) / 3)
            if bx + 24 < bodyEnd {
                g.rect(bx, floorY + 1, 24, max(3, Int(6 * scale)), mix(.rgb(0x14181C), .rgb(0x30363E), dim))
            }
        }

        for bf in [0.22, 0.78] {
            let bx = x1 - Int(Double(x1 - x0) * bf)
            if bx > bodyEnd - 6 { continue }
            g.rect(bx - 16, floorY + 3, 32, max(4, Int(7 * scale)), skirt.shade(-0.2))
            wheel(g, bx - 8, base, max(3, Int(6 * scale)), wheelPhase)
            wheel(g, bx + 8, base, max(3, Int(6 * scale)), wheelPhase)
        }

        if !head && !tail {
            let px = x0 + (x1 - x0) / 2
            g.rect(px - 12, topY - 3, 24, 3, mix(.rgb(0x2E343A), .rgb(0x5A626A), dim))
            g.line(px - 9, topY - 3, px + 3, topY - 16, .rgb(0x8A9098), 2)
            g.line(px + 3, topY - 16, px + 12, topY - 8, .rgb(0x8A9098), 2)
            g.rect(px + 1, topY - 19, 16, 3, .rgb(0xB6BCC2))
        } else if !head {
            g.rect(x0 + (x1 - x0) / 3, topY - 3, 18, 3, mix(.rgb(0x2E343A), .rgb(0x6E767E), dim))
        }

        g.ctx.restoreGState()
    }

    private static func wheel(_ g: Pix, _ cx: Int, _ base: Int, _ r: Int, _ phase: Double) {
        let cy = base - r
        g.circle(cx, cy, r, .rgb(0x24282E))
        if r > 2 {
            g.circle(cx, cy, r - 1, .rgb(0x6E767E))
            let (x1, y1) = g.polar(cx, cy, Double(r - 2), phase * 2.2)
            g.rect(x1, y1, 2, 2, .rgb(0x24282E))
        }
    }
}
