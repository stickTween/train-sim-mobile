import SwiftUI

enum Lang: String, CaseIterable, Identifiable {
    case ru, en
    var id: String { rawValue }
    var title: String { self == .ru ? "Русский" : "English" }
}

final class Loc: ObservableObject {
    @Published var lang: Lang = .ru
    func t(_ k: String) -> String { Loc.table[lang]?[k] ?? k }
    static func s(_ k: String, _ l: Lang) -> String { table[l]?[k] ?? k }

    static let table: [Lang: [String: String]] = [
        .ru: [
            "title": "СИМУЛЯТОР ПОЕЗДОВ",
            "chooseTrain": "Выберите поезд",
            "start": "В КАБИНУ",
            "maxSpeed": "Макс. скорость",
            "cars": "вагонов",
            "menu": "Меню",
            "next": "Следующая",
            "autostop": "АВТОСТОП",
            "doors": "ДВЕРИ",
            "lights": "СВЕТ",
            "horn": "ГУДОК",
            "throttle": "ТЯГА",
            "brake": "ТОРМОЗ",
            "exit": "ВЫЙТИ",
            "enter": "В КАБИНУ",
            "hint": "Тяни рычаги пальцем, крути камеру свайпом, жми кнопки",
            "closed": "Двери закрыты",
            "startHint": "Отпусти тормоз (правая рукоятка), затем подними тягу (левая). Можно тянуть или просто нажимать",
            "station": "станция"
        ],
        .en: [
            "title": "TRAIN SIMULATOR",
            "chooseTrain": "Choose a train",
            "start": "ENTER CAB",
            "maxSpeed": "Top speed",
            "cars": "cars",
            "menu": "Menu",
            "next": "Next stop",
            "autostop": "AUTOSTOP",
            "doors": "DOORS",
            "lights": "LIGHTS",
            "horn": "HORN",
            "throttle": "THROTTLE",
            "brake": "BRAKE",
            "exit": "STEP OUT",
            "enter": "ENTER CAB",
            "hint": "Drag levers, swipe to look around, tap buttons",
            "closed": "Doors closed",
            "startHint": "Release the brake (right handle), then raise the throttle (left). Drag or just tap",
            "station": "station"
        ]
    ]
}
