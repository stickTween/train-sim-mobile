import SwiftUI

enum Lang: String, CaseIterable, Identifiable {
    case ru, en
    var id: String { rawValue }
    var title: String { self == .ru ? "Русский" : "English" }
}

final class Loc: ObservableObject {
    @Published var lang: Lang = .ru
    func t(_ k: String) -> String { Loc.table[lang]?[k] ?? k }
    static func s(_ k: String, _ l: Lang) -> String { table[l]?[k] ?? k }

    static let table: [Lang: [String: String]] = [
        .ru: [
            "title": "СИМУЛЯТОР ПОЕЗДОВ",
            "chooseTrain": "Выберите поезд",
            "start": "В КАБИНУ",
            "maxSpeed": "Макс. скорость",
            "cars": "вагонов",
            "cabStyle": "Пульт",
            "menu": "Меню",
            "next": "Следующая",
            "route": "МАРШРУТ",
            "autostop": "АВТОСТОП",
            "doors": "ДВЕРИ",
            "lights": "СВЕТ",
            "horn": "ГУДОК",
            "throttle": "ТЯГА",
            "brake": "ТОРМОЗ",
            "exit": "ВЫЙТИ",
            "enter": "В КАБИНУ",
            "hint": "Тяни рукоятки пальцем, крути камеру свайпом, жми кнопки",
            "closed": "Сначала остановись",
            "startHint": "Отпусти тормоз, затем подними тягу. Рукоятки можно тянуть или просто нажимать",
            "walkHint": "Джойстик слева — идти, свайп — осмотреться",
            "autoOn": "Автоостановка включена",
            "autoOff": "Автоостановка выключена",
            "hornSound": "Гудок!",
            "open": "открыты",
            "shut": "закрыты",
            "on": "вкл",
            "off": "выкл",
            "lastochkaCab": "Два джойстика, три экрана",
            "sapsanCab": "Т-образный контроллер, 4 экрана",
            "ivolgaCab": "Широкий экран, светлый пульт"
        ],
        .en: [
            "title": "TRAIN SIMULATOR",
            "chooseTrain": "Choose a train",
            "start": "ENTER CAB",
            "maxSpeed": "Top speed",
            "cars": "cars",
            "cabStyle": "Desk",
            "menu": "Menu",
            "next": "Next stop",
            "route": "ROUTE",
            "autostop": "AUTOSTOP",
            "doors": "DOORS",
            "lights": "LIGHTS",
            "horn": "HORN",
            "throttle": "THROTTLE",
            "brake": "BRAKE",
            "exit": "STEP OUT",
            "enter": "ENTER CAB",
            "hint": "Drag the handles, swipe to look around, tap the buttons",
            "closed": "Stop the train first",
            "startHint": "Release the brake, then raise the throttle. Drag the handles or just tap them",
            "walkHint": "Left stick to walk, swipe to look around",
            "autoOn": "Autostop enabled",
            "autoOff": "Autostop disabled",
            "hornSound": "Horn!",
            "open": "open",
            "shut": "shut",
            "on": "on",
            "off": "off",
            "lastochkaCab": "Twin joysticks, three displays",
            "sapsanCab": "T-handle controller, 4 displays",
            "ivolgaCab": "Wide display, light desk"
        ]
    ]
}
