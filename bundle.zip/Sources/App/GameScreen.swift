import SwiftUI

struct CanvasWrapper: UIViewRepresentable {
    let spec: TrainSpec
    let lang: Lang
    func makeUIView(context: Context) -> GameCanvasView { GameCanvasView(spec: spec, lang: lang) }
    func updateUIView(_ view: GameCanvasView, context: Context) {}
}

struct GameScreen: View {
    @EnvironmentObject var loc: Loc
    @Environment(\.dismiss) private var dismiss
    let spec: TrainSpec

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            CanvasWrapper(spec: spec, lang: loc.lang).ignoresSafeArea()
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Color.black.opacity(0.55)))
            }
            .padding(.top, 10)
            .padding(.trailing, 14)
        }
        .statusBarHidden()
    }
}
