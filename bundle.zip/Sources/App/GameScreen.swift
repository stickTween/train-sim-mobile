import SwiftUI

struct CanvasWrapper: UIViewRepresentable {
    let spec: TrainSpec
    let route: RouteDef
    let lang: Lang
    let onExit: () -> Void

    func makeUIView(context: Context) -> GameCanvasView {
        let v = GameCanvasView(spec: spec, route: route, lang: lang)
        v.onExit = onExit
        return v
    }

    func updateUIView(_ view: GameCanvasView, context: Context) {}
}

struct GameScreen: View {
    @EnvironmentObject var loc: Loc
    @Environment(\.dismiss) private var dismiss
    let spec: TrainSpec
    let route: RouteDef

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CanvasWrapper(spec: spec, route: route, lang: loc.lang) {
                dismiss()
            }
            .ignoresSafeArea()
        }
        .statusBarHidden()
    }
}
