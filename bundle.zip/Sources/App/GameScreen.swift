import SwiftUI
import simd

struct GameView: UIViewControllerRepresentable {
    let model: GameModel
    func makeUIViewController(context: Context) -> GameViewController { GameViewController(model: model) }
    func updateUIViewController(_ vc: GameViewController, context: Context) {}
}

struct GameScreen: View {
    @EnvironmentObject var loc: Loc
    @ObservedObject var model: GameModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            GameView(model: model).ignoresSafeArea()

            VStack(spacing: 0) {
                HStack(alignment: .top, spacing: 10) {
                    Button { dismiss() } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 42, height: 42)
                            .background(Circle().fill(Color.black.opacity(0.45)))
                    }
                    chips
                    Spacer()
                    speedCard
                }

                Spacer()

                HStack(alignment: .bottom) {
                    if model.mode == .walk {
                        Joystick(model: model)
                    } else {
                        leverBars
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 10) {
                        if !model.hint.isEmpty {
                            Text(model.hint)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white)
                                .multilineTextAlignment(.trailing)
                                .frame(maxWidth: 300, alignment: .trailing)
                                .padding(.horizontal, 14).padding(.vertical, 9)
                                .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.5)))
                        }
                        if model.mode == .cab && model.canExit {
                            actionButton(loc.t("exit"), "figure.walk")
                        }
                        if model.mode == .walk && model.canEnter {
                            actionButton(loc.t("enter"), "door.left.hand.open")
                        }
                    }
                }
            }
            .padding(18)
        }
        .statusBarHidden()
    }

    private var speedCard: some View {
        VStack(alignment: .trailing, spacing: 2) {
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("\(Int(model.speed * 3.6))")
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                Text("km/h")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white.opacity(0.6))
            }
            Text(model.nextStation)
                .font(.system(size: 14, weight: .semibold))
            HStack(spacing: 6) {
                ProgressView(value: max(0, min(1, 1 - model.distanceToStation / 1600)))
                    .frame(width: 90)
                    .tint(.green)
                Text("\(Int(model.distanceToStation)) m")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.7))
            }
        }
        .foregroundColor(.white)
        .padding(.horizontal, 16).padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.45)))
    }

    private var chips: some View {
        VStack(alignment: .leading, spacing: 6) {
            chip(loc.t("autostop"), model.autoStop ? loc.t("on") : loc.t("off"), model.autoStop ? .green : .gray)
            chip(loc.t("doors"), model.doorsOpen ? loc.t("open") : loc.t("shut"), model.doorsOpen ? .orange : .gray)
        }
    }

    private func chip(_ title: String, _ value: String, _ color: Color) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(title).font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.75))
            Text(value).font(.system(size: 10, weight: .heavy)).foregroundColor(.white)
        }
        .padding(.horizontal, 9).padding(.vertical, 5)
        .background(Capsule().fill(Color.black.opacity(0.42)))
    }

    private var leverBars: some View {
        HStack(spacing: 10) {
            bar(loc.t("throttle"), model.throttle, .cyan)
            bar(loc.t("brake"), model.brake, .red)
        }
    }

    private func bar(_ title: String, _ value: Double, _ color: Color) -> some View {
        VStack(spacing: 5) {
            ZStack(alignment: .bottom) {
                RoundedRectangle(cornerRadius: 5)
                    .fill(Color.black.opacity(0.42))
                    .frame(width: 12, height: 78)
                RoundedRectangle(cornerRadius: 5)
                    .fill(color)
                    .frame(width: 12, height: max(3, 78 * CGFloat(value)))
            }
            Text(title)
                .font(.system(size: 9, weight: .heavy))
                .foregroundColor(.white.opacity(0.8))
        }
    }

    private func actionButton(_ t: String, _ icon: String) -> some View {
        Button { model.toggleExit() } label: {
            HStack(spacing: 8) {
                Image(systemName: icon)
                Text(t)
            }
            .font(.system(size: 16, weight: .bold))
            .foregroundColor(.black)
            .frame(width: 190, height: 50)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.white))
        }
    }
}

struct Joystick: View {
    @ObservedObject var model: GameModel
    @State private var offset = CGSize.zero

    var body: some View {
        ZStack {
            Circle().fill(Color.white.opacity(0.12)).frame(width: 150, height: 150)
            Circle().stroke(Color.white.opacity(0.3), lineWidth: 2).frame(width: 150, height: 150)
            Circle().fill(Color.white.opacity(0.55)).frame(width: 62, height: 62).offset(offset)
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    let lim: CGFloat = 52
                    var t = v.translation
                    let len = max(1, sqrt(t.width * t.width + t.height * t.height))
                    if len > lim { t.width = t.width / len * lim; t.height = t.height / len * lim }
                    offset = t
                    model.walkVector = SIMD2<Float>(Float(t.width / lim), Float(t.height / lim))
                }
                .onEnded { _ in
                    offset = .zero
                    model.walkVector = .zero
                }
        )
    }
}
