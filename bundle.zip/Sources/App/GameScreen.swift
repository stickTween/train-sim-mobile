import SwiftUI
import simd

struct GameView: UIViewControllerRepresentable {
    let model: GameModel
    func makeUIViewController(context: Context) -> GameViewController { GameViewController(model: model) }
    func updateUIViewController(_ vc: GameViewController, context: Context) {}
}

struct GameScreen: View {
    @EnvironmentObject var loc: Loc
    @ObservedObject var model: GameModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            GameView(model: model).ignoresSafeArea()

            VStack {
                HStack(alignment: .top) {
                    Button { dismiss() } label: {
                        Text(loc.t("menu"))
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 16).padding(.vertical, 9)
                            .background(Capsule().fill(Color.black.opacity(0.45)))
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 3) {
                        Text("\(Int(model.speed * 3.6)) km/h")
                            .font(.system(size: 26, weight: .heavy, design: .rounded))
                        Text("\(loc.t("next")): \(model.nextStation)")
                            .font(.system(size: 13, weight: .medium))
                        Text("\(Int(model.distanceToStation)) m")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(.white.opacity(0.7))
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .background(RoundedRectangle(cornerRadius: 14).fill(Color.black.opacity(0.4)))
                }

                Spacer()

                HStack(alignment: .bottom) {
                    if model.mode == .walk {
                        Joystick(model: model)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 10) {
                        if !model.hint.isEmpty {
                            Text(model.hint)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 12).padding(.vertical, 6)
                                .background(Capsule().fill(Color.black.opacity(0.45)))
                        }
                        if model.mode == .cab && model.canExit {
                            actionButton(loc.t("exit"))
                        }
                        if model.mode == .walk && model.canEnter {
                            actionButton(loc.t("enter"))
                        }
                    }
                }
            }
            .padding(20)
        }
        .statusBarHidden()
    }

    private func actionButton(_ t: String) -> some View {
        Button { model.toggleExit() } label: {
            Text(t)
                .font(.system(size: 17, weight: .bold))
                .foregroundColor(.black)
                .frame(width: 180, height: 52)
                .background(RoundedRectangle(cornerRadius: 14).fill(Color.white))
        }
    }
}

struct Joystick: View {
    @ObservedObject var model: GameModel
    @State private var offset = CGSize.zero

    var body: some View {
        ZStack {
            Circle().fill(Color.white.opacity(0.14)).frame(width: 150, height: 150)
            Circle().stroke(Color.white.opacity(0.3), lineWidth: 2).frame(width: 150, height: 150)
            Circle().fill(Color.white.opacity(0.55)).frame(width: 62, height: 62).offset(offset)
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    let lim: CGFloat = 52
                    var t = v.translation
                    let len = max(1, sqrt(t.width * t.width + t.height * t.height))
                    if len > lim { t.width = t.width / len * lim; t.height = t.height / len * lim }
                    offset = t
                    model.walkVector = SIMD2<Float>(Float(t.width / lim), Float(t.height / lim))
                }
                .onEnded { _ in
                    offset = .zero
                    model.walkVector = .zero
                }
        )
    }
}
