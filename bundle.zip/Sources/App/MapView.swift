import SwiftUI

struct RouteMapView: View {
    @EnvironmentObject var loc: Loc
    let spec: TrainSpec
    @Binding var fromIndex: Int
    @Binding var toIndex: Int
    @Binding var note: String

    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var pan: CGFloat = 0
    @State private var lastPan: CGFloat = 0
    @State private var pickingTo = false

    private func baseX(_ pos: Double, _ w: CGFloat) -> CGFloat {
        CGFloat(pos / World.lineLength) * (w - 30) + 15
    }

    private func screenX(_ pos: Double, _ w: CGFloat) -> CGFloat {
        (baseX(pos, w) - w / 2) * zoom + w / 2 + pan
    }

    private func stationY(_ s: StationDef, _ h: CGFloat) -> CGFloat {
        s.central ? h * 0.42 : (s.index % 2 == 0 ? h * 0.30 : h * 0.56)
    }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ZStack(alignment: .topLeading) {
                Canvas { ctx, size in
                    let lineY = size.height * 0.42
                    ctx.fill(Path(CGRect(x: 0, y: 0, width: size.width, height: size.height)),
                             with: .color(Color(red: 0.05, green: 0.08, blue: 0.13)))

                    var rail = Path()
                    rail.move(to: CGPoint(x: screenX(0, w), y: lineY))
                    rail.addLine(to: CGPoint(x: screenX(World.lineLength, w), y: lineY))
                    ctx.stroke(rail, with: .color(Color.white.opacity(0.22)), lineWidth: 3)

                    if fromIndex >= 0 && toIndex >= 0 {
                        let a = World.stations[min(fromIndex, toIndex)].pos
                        let b = World.stations[max(fromIndex, toIndex)].pos
                        var sel = Path()
                        sel.move(to: CGPoint(x: screenX(a, w), y: lineY))
                        sel.addLine(to: CGPoint(x: screenX(b, w), y: lineY))
                        ctx.stroke(sel, with: .color(Color(spec.liveryMain)), lineWidth: 5)
                    }

                    for c in 0..<4 {
                        let x = screenX(Double(c) * World.cityGap + 6000, w)
                        if x < -60 || x > size.width + 60 { continue }
                        ctx.fill(Path(CGRect(x: x - 1, y: lineY - 46, width: 2, height: 40)),
                                 with: .color(Color.white.opacity(0.18)))
                        ctx.draw(Text(World.cityName(c, loc.lang))
                            .font(.system(size: 11, weight: .heavy))
                            .foregroundColor(.white.opacity(0.85)),
                                 at: CGPoint(x: x, y: lineY - 54))
                    }

                    for s in World.stations {
                        let x = screenX(s.pos, w)
                        if x < -40 || x > size.width + 40 { continue }
                        let y = stationY(s, size.height)
                        var stem = Path()
                        stem.move(to: CGPoint(x: x, y: lineY))
                        stem.addLine(to: CGPoint(x: x, y: y))
                        ctx.stroke(stem, with: .color(Color.white.opacity(0.16)), lineWidth: 1)

                        let isFrom = s.index == fromIndex
                        let isTo = s.index == toIndex
                        let allowed = !spec.express || s.central
                        let r: CGFloat = s.central ? 7 : 5
                        var color = allowed ? Color.white.opacity(0.75) : Color.white.opacity(0.22)
                        if isFrom { color = Color(red: 0.35, green: 0.85, blue: 0.45) }
                        if isTo { color = Color(red: 0.95, green: 0.45, blue: 0.35) }
                        ctx.fill(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)),
                                 with: .color(color))
                        if isFrom || isTo {
                            ctx.stroke(Path(ellipseIn: CGRect(x: x - r - 3, y: y - r - 3,
                                                              width: r * 2 + 6, height: r * 2 + 6)),
                                       with: .color(color.opacity(0.6)), lineWidth: 1.5)
                        }
                        if zoom > 1.6 || s.central {
                            ctx.draw(Text(s.name(loc.lang))
                                .font(.system(size: 8, weight: .semibold))
                                .foregroundColor(.white.opacity(allowed ? 0.8 : 0.35)),
                                     at: CGPoint(x: x, y: y + (y > lineY ? 14 : -14)))
                        }
                    }
                }
                .contentShape(Rectangle())
                .gesture(
                    SimultaneousGesture(
                        DragGesture()
                            .onChanged { v in pan = lastPan + v.translation.width }
                            .onEnded { _ in lastPan = pan },
                        MagnificationGesture()
                            .onChanged { v in zoom = max(1, min(9, lastZoom * v)) }
                            .onEnded { _ in lastZoom = zoom }
                    )
                )
                .onTapGesture(count: 1, coordinateSpace: .local) { p in
                    var best = -1
                    var bestD: CGFloat = 26
                    for s in World.stations {
                        let x = screenX(s.pos, w)
                        let y = stationY(s, h)
                        let d = hypot(p.x - x, p.y - y)
                        if d < bestD { bestD = d; best = s.index }
                    }
                    guard best >= 0 else { return }
                    if !pickingTo {
                        fromIndex = best
                        toIndex = -1
                        pickingTo = true
                        note = loc.t("pickTo")
                    } else {
                        toIndex = best
                        pickingTo = false
                        let (route, adjusted) = World.buildRoute(spec: spec, from: fromIndex, to: toIndex)
                        fromIndex = route.stops[0]
                        toIndex = route.stops[route.stops.count - 1]
                        note = adjusted ? loc.t(spec.express ? "expressOnly" : "routeFixed") : ""
                    }
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(pickingTo ? loc.t("pickTo") : loc.t("pickFrom"))
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.white.opacity(0.7))
                    Text(loc.t("zoomHint"))
                        .font(.system(size: 8))
                        .foregroundColor(.white.opacity(0.35))
                }
                .padding(6)
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.12)))
        }
    }
}
