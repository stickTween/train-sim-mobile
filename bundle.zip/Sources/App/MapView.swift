import SwiftUI

struct RouteMapView: View {
    @EnvironmentObject var loc: Loc
    let spec: TrainSpec
    @Binding var fromIndex: Int
    @Binding var toIndex: Int
    @Binding var note: String

    @State private var zoom: CGFloat = 1.0
    @State private var lastZoom: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    @State private var pickingTo = false

    private func layoutX(_ pos: Double, _ w: CGFloat) -> CGFloat {
        CGFloat(pos / World.lineLength) * (w - 60) + 30
    }

    private func layoutY(_ s: StationDef, _ h: CGFloat) -> CGFloat {
        let lane: CGFloat = s.central ? 0 : (s.index % 2 == 0 ? -1 : 1)
        return h * 0.5 + lane * h * 0.20
    }

    // camera: scale around window center, then translate
    private func toScreen(_ lx: CGFloat, _ ly: CGFloat, _ w: CGFloat, _ h: CGFloat) -> CGPoint {
        CGPoint(x: (lx - w / 2) * zoom + w / 2 + offset.width,
                y: (ly - h / 2) * zoom + h / 2 + offset.height)
    }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            ZStack(alignment: .topLeading) {
                Canvas { ctx, size in
                    ctx.fill(Path(CGRect(origin: .zero, size: size)),
                             with: .color(Color(red: 0.05, green: 0.08, blue: 0.13)))
                    let lineLy = size.height * 0.5

                    var rail = Path()
                    rail.move(to: toScreen(layoutX(0, w), lineLy, w, h))
                    rail.addLine(to: toScreen(layoutX(World.lineLength, w), lineLy, w, h))
                    ctx.stroke(rail, with: .color(Color.white.opacity(0.20)), lineWidth: 3)

                    if fromIndex >= 0 && toIndex >= 0 {
                        let a = layoutX(World.stations[min(fromIndex, toIndex)].pos, w)
                        let b = layoutX(World.stations[max(fromIndex, toIndex)].pos, w)
                        var sel = Path()
                        sel.move(to: toScreen(a, lineLy, w, h))
                        sel.addLine(to: toScreen(b, lineLy, w, h))
                        ctx.stroke(sel, with: .color(Color(spec.liveryMain)), lineWidth: 5)
                    }

                    for c in 0..<4 {
                        let p = toScreen(layoutX(Double(c) * World.cityGap + 6000, w), lineLy - 60, w, h)
                        if p.x < -80 || p.x > size.width + 80 { continue }
                        ctx.draw(Text(World.cityName(c, loc.lang))
                            .font(.system(size: 11 * min(1.6, zoom), weight: .heavy))
                            .foregroundColor(.white.opacity(0.85)), at: p)
                    }

                    for s in World.stations {
                        let base = CGPoint(x: layoutX(s.pos, w), y: layoutY(s, h))
                        let p = toScreen(base.x, base.y, w, h)
                        if p.x < -50 || p.x > size.width + 50 { continue }
                        let linePt = toScreen(base.x, lineLy, w, h)
                        var stem = Path()
                        stem.move(to: linePt)
                        stem.addLine(to: p)
                        ctx.stroke(stem, with: .color(Color.white.opacity(0.15)), lineWidth: 1)

                        let allowed = !spec.express || s.central
                        let isFrom = s.index == fromIndex
                        let isTo = s.index == toIndex
                        let r: CGFloat = (s.central ? 7 : 5) * min(1.5, max(0.9, zoom))
                        var color = allowed ? Color.white.opacity(0.72) : Color.white.opacity(0.22)
                        if isFrom { color = Color(red: 0.35, green: 0.85, blue: 0.45) }
                        if isTo { color = Color(red: 0.95, green: 0.45, blue: 0.35) }
                        ctx.fill(Path(ellipseIn: CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)),
                                 with: .color(color))
                        if isFrom || isTo {
                            ctx.stroke(Path(ellipseIn: CGRect(x: p.x - r - 3, y: p.y - r - 3,
                                                              width: r * 2 + 6, height: r * 2 + 6)),
                                       with: .color(color.opacity(0.6)), lineWidth: 1.5)
                        }
                        if zoom > 1.5 || s.central {
                            ctx.draw(Text(s.name(loc.lang))
                                .font(.system(size: 8 * min(1.4, zoom), weight: .semibold))
                                .foregroundColor(.white.opacity(allowed ? 0.8 : 0.35)),
                                     at: CGPoint(x: p.x, y: p.y + (base.y > lineLy ? 14 : -14)))
                        }
                    }
                }
                .contentShape(Rectangle())
                .gesture(
                    SimultaneousGesture(
                        DragGesture()
                            .onChanged { v in
                                offset = CGSize(width: lastOffset.width + v.translation.width,
                                                height: lastOffset.height + v.translation.height)
                            }
                            .onEnded { _ in lastOffset = offset },
                        MagnificationGesture()
                            .onChanged { v in zoom = max(1, min(6, lastZoom * v)) }
                            .onEnded { _ in lastZoom = zoom }
                    )
                )
                .onTapGesture(count: 1, coordinateSpace: .local) { p in
                    var best = -1
                    var bestD: CGFloat = 30
                    for s in World.stations {
                        let sp = toScreen(layoutX(s.pos, w), layoutY(s, h), w, h)
                        let d = hypot(p.x - sp.x, p.y - sp.y)
                        if d < bestD { bestD = d; best = s.index }
                    }
                    guard best >= 0 else { return }
                    if !pickingTo {
                        fromIndex = best
                        toIndex = -1
                        pickingTo = true
                        note = loc.t("pickTo")
                    } else {
                        toIndex = best
                        pickingTo = false
                        let (route, adjusted) = World.buildRoute(spec: spec, from: fromIndex, to: toIndex)
                        fromIndex = route.stops[0]
                        toIndex = route.stops[route.stops.count - 1]
                        note = adjusted ? loc.t(spec.express ? "expressOnly" : "routeFixed") : ""
                    }
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(pickingTo ? loc.t("pickTo") : loc.t("pickFrom"))
                        .font(.system(size: 9, weight: .bold)).foregroundColor(.white.opacity(0.7))
                    Text(loc.t("zoomHint")).font(.system(size: 8)).foregroundColor(.white.opacity(0.35))
                }
                .padding(6)

                VStack(spacing: 4) {
                    zoomButton("+") { zoom = min(6, zoom * 1.4); lastZoom = zoom }
                    zoomButton("\u{2212}") { zoom = max(1, zoom / 1.4); lastZoom = zoom }
                    zoomButton("\u{25CE}") {
                        withAnimation(.easeOut(duration: 0.2)) {
                            zoom = 1; lastZoom = 1; offset = .zero; lastOffset = .zero
                        }
                    }
                }
                .padding(6)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
            }
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.12)))
        }
    }

    private func zoomButton(_ label: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 15, weight: .bold, design: .monospaced))
                .foregroundColor(.white)
                .frame(width: 26, height: 26)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.black.opacity(0.5)))
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.white.opacity(0.2)))
        }
    }
}
