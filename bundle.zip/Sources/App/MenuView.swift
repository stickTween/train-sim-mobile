import SwiftUI

struct MenuView: View {
    @EnvironmentObject var loc: Loc
    @State private var index = 0
    @State private var playing = false
    @StateObject private var model = GameModel()

    private func cabNote(_ s: TrainSpec) -> String {
        switch s.layout {
        case .lastochka: return loc.t("lastochkaCab")
        case .sapsan: return loc.t("sapsanCab")
        case .ivolga: return loc.t("ivolgaCab")
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.04, green: 0.07, blue: 0.13),
                                    Color(red: 0.09, green: 0.18, blue: 0.30)],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()

            VStack(spacing: 16) {
                Text(loc.t("title"))
                    .font(.system(size: 36, weight: .heavy))
                    .foregroundColor(.white)
                    .tracking(2)

                Text(loc.t("chooseTrain"))
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.white.opacity(0.6))

                HStack(spacing: 16) {
                    ForEach(Array(TrainSpec.all.enumerated()), id: \.element.id) { i, s in
                        card(i, s)
                    }
                }

                Button {
                    model.spec = TrainSpec.all[index]
                    model.lang = loc.lang
                    playing = true
                } label: {
                    Text(loc.t("start"))
                        .font(.system(size: 20, weight: .heavy))
                        .foregroundColor(.black)
                        .frame(width: 260, height: 56)
                        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white))
                }

                Text(loc.t("hint"))
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.45))
            }
            .padding(20)
        }
        .fullScreenCover(isPresented: $playing) {
            GameScreen(model: model).environmentObject(loc)
        }
    }

    private func card(_ i: Int, _ s: TrainSpec) -> some View {
        let on = i == index
        return Button {
            index = i
        } label: {
            VStack(spacing: 8) {
                ZStack(alignment: .bottom) {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(LinearGradient(colors: [Color(s.body), Color(s.body).opacity(0.75)],
                                             startPoint: .top, endPoint: .bottom))
                        .frame(height: 78)
                    Rectangle()
                        .fill(Color(s.stripe))
                        .frame(height: 16)
                        .offset(y: -22)
                    Rectangle()
                        .fill(Color(s.accent))
                        .frame(height: 5)
                        .offset(y: -14)
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color(s.skirt))
                        .frame(height: 12)
                }
                .clipShape(RoundedRectangle(cornerRadius: 12))

                Text(s.name(loc.lang))
                    .font(.system(size: 19, weight: .bold))
                    .foregroundColor(.white)

                Text("\(Int(s.maxSpeed)) km/h · \(s.cars + 2) \(loc.t("cars"))")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.65))

                HStack(spacing: 5) {
                    Circle().fill(Color(s.seat)).frame(width: 9, height: 9)
                    Circle().fill(Color(s.deskTop)).frame(width: 9, height: 9)
                    Circle().fill(Color(s.cabAccent)).frame(width: 9, height: 9)
                }

                Text(cabNote(s))
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.white.opacity(0.5))
                    .multilineTextAlignment(.center)
                    .frame(height: 26)
            }
            .padding(12)
            .frame(width: 210)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(on ? 0.16 : 0.06)))
            .overlay(RoundedRectangle(cornerRadius: 18)
                .stroke(on ? Color(s.stripe) : Color.white.opacity(0.12), lineWidth: on ? 3 : 1))
        }
    }
}
