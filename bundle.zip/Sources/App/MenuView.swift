import SwiftUI

struct MenuView: View {
    @EnvironmentObject var loc: Loc
    @State private var index = 0
    @State private var playing = false

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.04, green: 0.06, blue: 0.11),
                                    Color(red: 0.08, green: 0.15, blue: 0.26)],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()

            VStack(spacing: 14) {
                Text(loc.t("title"))
                    .font(.system(size: 32, weight: .heavy, design: .monospaced))
                    .foregroundColor(.white)

                Text(loc.t("chooseTrain"))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.6))

                HStack(spacing: 14) {
                    ForEach(Array(TrainSpec.all.enumerated()), id: \.element.id) { i, s in
                        card(i, s)
                    }
                }

                Button {
                    playing = true
                } label: {
                    Text(loc.t("start"))
                        .font(.system(size: 19, weight: .heavy, design: .monospaced))
                        .foregroundColor(.black)
                        .frame(width: 250, height: 52)
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white))
                }

                Text(loc.t("hint"))
                    .font(.system(size: 11))
                    .foregroundColor(.white.opacity(0.45))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 460)
            }
            .padding(18)
        }
        .fullScreenCover(isPresented: $playing) {
            GameScreen(spec: TrainSpec.all[index]).environmentObject(loc)
        }
    }

    private func card(_ i: Int, _ s: TrainSpec) -> some View {
        let on = i == index
        return Button {
            index = i
        } label: {
            VStack(spacing: 8) {
                ZStack(alignment: .bottomLeading) {
                    Rectangle().fill(Color(s.body)).frame(height: 56)
                    Rectangle().fill(Color(s.roof)).frame(height: 6)
                        .frame(maxHeight: .infinity, alignment: .top)
                    Rectangle().fill(Color(s.stripe)).frame(height: 9)
                        .offset(y: -18)
                    Rectangle().fill(Color(s.accent)).frame(height: 3)
                        .offset(y: -14)
                    Rectangle().fill(Color(s.skirt)).frame(height: 8)
                    HStack(spacing: 6) {
                        ForEach(0..<4, id: \.self) { _ in
                            Rectangle().fill(Color(s.glass)).frame(width: 16, height: 11)
                        }
                    }
                    .padding(.leading, 8)
                    .offset(y: -30)
                }
                .frame(height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 4))

                Text(s.name(loc.lang))
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.white)

                Text("\(loc.t("maxSpeed")) \(Int(s.maxSpeed)) km/h")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.65))

                Text("\(s.cars) \(loc.t("cars"))")
                    .font(.system(size: 11))
                    .foregroundColor(.white.opacity(0.45))
            }
            .padding(10)
            .frame(width: 190)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(on ? 0.16 : 0.06)))
            .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(on ? Color(s.stripe) : Color.white.opacity(0.12), lineWidth: on ? 3 : 1))
        }
    }
}
