import SwiftUI

struct MenuView: View {
    @EnvironmentObject var loc: Loc
    @State private var index = 0
    @State private var playing = false
    @StateObject private var model = GameModel()

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.05, green: 0.09, blue: 0.16),
                                    Color(red: 0.11, green: 0.22, blue: 0.34)],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            VStack(spacing: 18) {
                Text(loc.t("title"))
                    .font(.system(size: 40, weight: .heavy))
                    .foregroundColor(.white)
                Text(loc.t("chooseTrain"))
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.white.opacity(0.65))

                HStack(spacing: 18) {
                    ForEach(Array(TrainSpec.all.enumerated()), id: \.element.id) { i, s in
                        card(i, s)
                    }
                }

                Button {
                    model.spec = TrainSpec.all[index]
                    model.lang = loc.lang
                    playing = true
                } label: {
                    Text(loc.t("start"))
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.black)
                        .frame(width: 280, height: 62)
                        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white))
                }
                Text(loc.t("hint"))
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(24)
        }
        .fullScreenCover(isPresented: $playing) {
            GameScreen(model: model).environmentObject(loc)
        }
    }

    private func card(_ i: Int, _ s: TrainSpec) -> some View {
        let on = i == index
        return Button {
            index = i
        } label: {
            VStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(LinearGradient(colors: [Color(s.body), Color(s.stripe)],
                                             startPoint: .top, endPoint: .bottom))
                        .frame(height: 92)
                    Capsule()
                        .fill(Color(s.accent))
                        .frame(width: 150, height: 16)
                        .offset(y: 14)
                }
                Text(s.name(loc.lang))
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                Text("\(loc.t("maxSpeed")): \(Int(s.maxSpeed)) km/h")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.7))
                Text("\(s.cars + 2) \(loc.t("cars"))")
                    .font(.system(size: 13))
                    .foregroundColor(.white.opacity(0.5))
            }
            .padding(14)
            .frame(width: 220)
            .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(on ? 0.18 : 0.07)))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(on ? Color.white : Color.white.opacity(0.15), lineWidth: 2))
        }
    }
}
