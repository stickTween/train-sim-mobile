import SwiftUI

struct MenuView: View {
    @EnvironmentObject var loc: Loc
    @State private var trainIndex = 0
    @State private var fromIndex = 0
    @State private var toIndex = 6
    @State private var note = ""
    @State private var playing = false
    @State private var coins = Save.coins
    @State private var refresh = 0

    private var spec: TrainSpec { TrainSpec.all[trainIndex] }

    private var templates: [RouteDef] {
        World.routes.filter { $0.trainIDs.contains(spec.id) }
    }

    private var currentRoute: RouteDef {
        World.buildRoute(spec: spec, from: fromIndex, to: toIndex).0
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.05, blue: 0.09),
                                    Color(red: 0.07, green: 0.12, blue: 0.20)],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()

            VStack(spacing: 8) {
                HStack {
                    Text(loc.t("title"))
                        .font(.system(size: 18, weight: .heavy, design: .monospaced))
                        .foregroundColor(.white)
                    Spacer()
                    HStack(spacing: 5) {
                        Circle().fill(Color(red: 1, green: 0.82, blue: 0.25)).frame(width: 11, height: 11)
                        Text("\(coins)").font(.system(size: 14, weight: .heavy, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(Capsule().fill(Color.white.opacity(0.10)))
                }

                HStack(alignment: .top, spacing: 10) {
                    VStack(spacing: 6) {
                        ForEach(Array(TrainSpec.all.enumerated()), id: \.element.id) { i, s in
                            trainRow(i, s)
                        }
                        Text(loc.t("shop"))
                            .font(.system(size: 9, weight: .heavy, design: .monospaced))
                            .foregroundColor(.white.opacity(0.5))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        ScrollView {
                            VStack(spacing: 5) {
                                ForEach(Upgrade.allCases, id: \.rawValue) { u in upgradeRow(u) }
                            }
                        }
                    }
                    .frame(width: 250)

                    VStack(spacing: 6) {
                        RouteMapView(spec: spec, fromIndex: $fromIndex, toIndex: $toIndex, note: $note)
                            .frame(maxWidth: .infinity)
                            .frame(height: 150)
                        if !note.isEmpty {
                            Text(note)
                                .font(.system(size: 9, weight: .semibold))
                                .foregroundColor(Color(red: 1, green: 0.75, blue: 0.35))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        HStack(spacing: 6) {
                            Text(loc.t("templates"))
                                .font(.system(size: 9, weight: .heavy, design: .monospaced))
                                .foregroundColor(.white.opacity(0.5))
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 6) {
                                    ForEach(templates) { r in templateChip(r) }
                                }
                            }
                        }
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 1) {
                                Text(currentRoute.name(loc.lang))
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundColor(.white).lineLimit(1)
                                Text("\(currentRoute.stops.count) \(loc.t("stops")) · \(loc.t("traffic")): \(loc.t("traffic\(min(2, currentRoute.traffic))")) · \(loc.t("reward")) +\(currentRoute.reward)")
                                    .font(.system(size: 9))
                                    .foregroundColor(.white.opacity(0.55)).lineLimit(1)
                            }
                            Spacer()
                            Button { playing = true } label: {
                                Text(loc.t("start"))
                                    .font(.system(size: 15, weight: .heavy, design: .monospaced))
                                    .foregroundColor(.black)
                                    .frame(width: 130, height: 38)
                                    .background(RoundedRectangle(cornerRadius: 5).fill(Color.white))
                            }
                        }
                    }
                }
                Text(loc.t("hint"))
                    .font(.system(size: 9)).foregroundColor(.white.opacity(0.35)).lineLimit(1)
            }
            .padding(12)
        }
        .onAppear { coins = Save.coins; clampRoute() }
        .fullScreenCover(isPresented: $playing, onDismiss: { coins = Save.coins }) {
            GameScreen(spec: spec, route: currentRoute).environmentObject(loc)
        }
    }

    private func clampRoute() {
        let r = World.buildRoute(spec: spec, from: fromIndex, to: toIndex).0
        fromIndex = r.stops[0]
        toIndex = r.stops[r.stops.count - 1]
    }

    private func templateChip(_ r: RouteDef) -> some View {
        Button {
            fromIndex = r.stops[0]
            toIndex = r.stops[r.stops.count - 1]
            note = ""
        } label: {
            Text(r.name(loc.lang))
                .font(.system(size: 9, weight: .semibold))
                .foregroundColor(.white.opacity(0.85))
                .lineLimit(1)
                .padding(.horizontal, 8).padding(.vertical, 5)
                .background(Capsule().fill(Color.white.opacity(0.08)))
                .overlay(Capsule().stroke(Color.white.opacity(0.12)))
        }
    }

    private func trainRow(_ i: Int, _ s: TrainSpec) -> some View {
        let on = i == trainIndex
        return Button {
            trainIndex = i
            clampRoute()
        } label: {
            HStack(spacing: 8) {
                ZStack(alignment: .bottom) {
                    Rectangle().fill(Color(s.body))
                    Rectangle().fill(Color(s.liveryMain)).frame(height: 8)
                    Rectangle().fill(Color(s.roof)).frame(height: 3)
                        .frame(maxHeight: .infinity, alignment: .top)
                }
                .frame(width: 48, height: 23)
                .clipShape(RoundedRectangle(cornerRadius: 3))
                VStack(alignment: .leading, spacing: 0) {
                    Text(s.name(loc.lang)).font(.system(size: 13, weight: .bold)).foregroundColor(.white)
                    Text("\(Int(s.maxSpeed)) km/h · \(s.cars()) \(loc.t("cars"))")
                        .font(.system(size: 9)).foregroundColor(.white.opacity(0.55))
                }
                Spacer()
                if s.express {
                    Text(loc.t("express"))
                        .font(.system(size: 7, weight: .heavy)).foregroundColor(.black)
                        .padding(.horizontal, 4).padding(.vertical, 1)
                        .background(Capsule().fill(Color(s.liveryMain)))
                }
            }
            .padding(6)
            .background(RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(on ? 0.15 : 0.05)))
            .overlay(RoundedRectangle(cornerRadius: 6)
                .stroke(on ? Color(s.liveryMain) : Color.white.opacity(0.10), lineWidth: on ? 2 : 1))
        }
    }

    private func upgradeRow(_ u: Upgrade) -> some View {
        let owned = Save.owns(spec.id, u)
        let cost = spec.cost(u)
        let can = coins >= cost
        return HStack(spacing: 6) {
            VStack(alignment: .leading, spacing: 0) {
                Text(loc.t(u.titleKey())).font(.system(size: 11, weight: .bold)).foregroundColor(.white)
                Text(loc.t(u.descKey())).font(.system(size: 8)).foregroundColor(.white.opacity(0.5))
            }
            Spacer()
            if owned {
                Text(loc.t("owned")).font(.system(size: 8, weight: .heavy))
                    .foregroundColor(Color(red: 0.5, green: 0.9, blue: 0.6))
            } else {
                Button {
                    if Save.buy(spec.id, u, cost: cost) {
                        coins = Save.coins
                        refresh += 1
                    }
                } label: {
                    Text("\(cost)")
                        .font(.system(size: 10, weight: .heavy, design: .monospaced))
                        .foregroundColor(can ? .black : .white.opacity(0.4))
                        .frame(width: 48, height: 20)
                        .background(RoundedRectangle(cornerRadius: 3)
                            .fill(can ? Color(red: 1, green: 0.82, blue: 0.25) : Color.white.opacity(0.08)))
                }
                .disabled(!can)
            }
        }
        .id(refresh)
        .padding(6)
        .background(RoundedRectangle(cornerRadius: 5).fill(Color.white.opacity(0.05)))
    }
}
