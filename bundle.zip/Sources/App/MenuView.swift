import SwiftUI

struct MenuView: View {
    @EnvironmentObject var loc: Loc
    @State private var trainIndex = 0
    @State private var routeID: String = ""
    @State private var playing = false
    @State private var coins = Save.coins
    @State private var refresh = 0

    private var spec: TrainSpec { TrainSpec.all[trainIndex] }

    private var routes: [RouteDef] {
        World.routes.filter { $0.trainIDs.contains(spec.id) }
    }

    private var route: RouteDef {
        routes.first { $0.id == routeID } ?? routes[0]
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.05, blue: 0.09),
                                    Color(red: 0.07, green: 0.13, blue: 0.22)],
                           startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()

            VStack(spacing: 10) {
                HStack {
                    Text(loc.t("title"))
                        .font(.system(size: 20, weight: .heavy, design: .monospaced))
                        .foregroundColor(.white)
                    Spacer()
                    HStack(spacing: 6) {
                        Circle().fill(Color(red: 1, green: 0.82, blue: 0.25)).frame(width: 12, height: 12)
                        Text("\(coins)")
                            .font(.system(size: 15, weight: .heavy, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(Capsule().fill(Color.white.opacity(0.10)))
                }

                HStack(alignment: .top, spacing: 12) {
                    VStack(spacing: 8) {
                        sectionTitle(loc.t("trains"))
                        ForEach(Array(TrainSpec.all.enumerated()), id: \.element.id) { i, s in
                            trainRow(i, s)
                        }
                        sectionTitle(loc.t("shop"))
                        ScrollView {
                            VStack(spacing: 6) {
                                ForEach(Upgrade.allCases, id: \.rawValue) { u in
                                    upgradeRow(u)
                                }
                            }
                        }
                        .frame(maxHeight: 96)
                    }
                    .frame(width: 300)

                    VStack(spacing: 8) {
                        sectionTitle(loc.t("routes"))
                        ScrollView {
                            VStack(spacing: 6) {
                                ForEach(routes) { r in
                                    routeRow(r)
                                }
                            }
                        }
                        Button {
                            playing = true
                        } label: {
                            Text(loc.t("start"))
                                .font(.system(size: 18, weight: .heavy, design: .monospaced))
                                .foregroundColor(.black)
                                .frame(maxWidth: .infinity)
                                .frame(height: 44)
                                .background(RoundedRectangle(cornerRadius: 6).fill(Color.white))
                        }
                    }
                }

                Text(loc.t("hint"))
                    .font(.system(size: 10))
                    .foregroundColor(.white.opacity(0.4))
                    .lineLimit(2)
            }
            .padding(14)
        }
        .onAppear {
            if routeID.isEmpty { routeID = routes[0].id }
            coins = Save.coins
        }
        .fullScreenCover(isPresented: $playing, onDismiss: { coins = Save.coins }) {
            GameScreen(spec: spec, route: route).environmentObject(loc)
        }
    }

    private func sectionTitle(_ t: String) -> some View {
        HStack {
            Text(t)
                .font(.system(size: 10, weight: .heavy, design: .monospaced))
                .foregroundColor(.white.opacity(0.5))
            Spacer()
        }
    }

    private func trainRow(_ i: Int, _ s: TrainSpec) -> some View {
        let on = i == trainIndex
        return Button {
            trainIndex = i
            routeID = routes.first?.id ?? ""
        } label: {
            HStack(spacing: 10) {
                ZStack(alignment: .bottom) {
                    Rectangle().fill(Color(s.body))
                    Rectangle().fill(Color(s.liveryMain)).frame(height: 9)
                    Rectangle().fill(Color(s.roof)).frame(height: 4)
                        .frame(maxHeight: .infinity, alignment: .top)
                }
                .frame(width: 54, height: 26)
                .clipShape(RoundedRectangle(cornerRadius: 3))

                VStack(alignment: .leading, spacing: 1) {
                    Text(s.name(loc.lang))
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                    Text("\(Int(s.maxSpeed)) km/h · \(s.cars()) \(loc.t("cars"))")
                        .font(.system(size: 10))
                        .foregroundColor(.white.opacity(0.55))
                }
                Spacer()
                if s.express {
                    Text(loc.t("express"))
                        .font(.system(size: 8, weight: .heavy))
                        .foregroundColor(.black)
                        .padding(.horizontal, 5).padding(.vertical, 2)
                        .background(Capsule().fill(Color(s.liveryMain)))
                }
            }
            .padding(7)
            .background(RoundedRectangle(cornerRadius: 7).fill(Color.white.opacity(on ? 0.15 : 0.05)))
            .overlay(RoundedRectangle(cornerRadius: 7)
                .stroke(on ? Color(s.liveryMain) : Color.white.opacity(0.10), lineWidth: on ? 2 : 1))
        }
    }

    private func routeRow(_ r: RouteDef) -> some View {
        let on = r.id == route.id
        return Button {
            routeID = r.id
        } label: {
            VStack(alignment: .leading, spacing: 3) {
                Text(r.name(loc.lang))
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                HStack(spacing: 10) {
                    Text("\(r.stops.count) \(loc.t("stops"))")
                    Text("\(loc.t("traffic")): \(loc.t("traffic\(min(2, r.traffic))"))")
                    Text("\(loc.t("reward")) +\(r.reward)")
                        .foregroundColor(Color(red: 0.55, green: 0.9, blue: 0.6))
                }
                .font(.system(size: 10))
                .foregroundColor(.white.opacity(0.55))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(8)
            .background(RoundedRectangle(cornerRadius: 7).fill(Color.white.opacity(on ? 0.15 : 0.05)))
            .overlay(RoundedRectangle(cornerRadius: 7)
                .stroke(on ? Color.white : Color.white.opacity(0.10), lineWidth: on ? 2 : 1))
        }
    }

    private func upgradeRow(_ u: Upgrade) -> some View {
        let owned = Save.owns(spec.id, u)
        let cost = spec.cost(u)
        let can = coins >= cost
        return HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 1) {
                Text(loc.t(u.titleKey()))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white)
                Text(loc.t(u.descKey()))
                    .font(.system(size: 9))
                    .foregroundColor(.white.opacity(0.5))
            }
            Spacer()
            if owned {
                Text(loc.t("owned"))
                    .font(.system(size: 9, weight: .heavy))
                    .foregroundColor(Color(red: 0.5, green: 0.9, blue: 0.6))
            } else {
                Button {
                    if Save.buy(spec.id, u, cost: cost) {
                        coins = Save.coins
                        refresh += 1
                    }
                } label: {
                    Text("\(cost)")
                        .font(.system(size: 11, weight: .heavy, design: .monospaced))
                        .foregroundColor(can ? .black : .white.opacity(0.4))
                        .frame(width: 54, height: 22)
                        .background(RoundedRectangle(cornerRadius: 4)
                            .fill(can ? Color(red: 1, green: 0.82, blue: 0.25) : Color.white.opacity(0.08)))
                }
                .disabled(!can)
            }
        }
        .id(refresh)
        .padding(7)
        .background(RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.05)))
    }
}
