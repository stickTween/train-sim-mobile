import SwiftUI
import simd

enum PlayMode { case cab, walk }

final class GameModel: ObservableObject {
    @Published var speed: Double = 0
    @Published var nextStation: String = ""
    @Published var distanceToStation: Double = 0
    @Published var mode: PlayMode = .cab
    @Published var canExit = false
    @Published var canEnter = false
    @Published var autoStop = true
    @Published var doorsOpen = false
    @Published var hint: String = ""

    var walkVector = SIMD2<Float>(0, 0)
    var spec: TrainSpec = TrainSpec.all[0]
    var lang: Lang = .ru
    weak var controller: GameViewController?

    func toggleExit() { controller?.toggleExit() }
}
