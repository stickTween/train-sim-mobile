import SwiftUI

@main
struct TrainGameApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

struct RootView: View {
    @StateObject private var loc = Loc()
    @State private var picked = false

    var body: some View {
        Group {
            if picked {
                MenuView().environmentObject(loc)
            } else {
                LanguageView(picked: $picked).environmentObject(loc)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct LanguageView: View {
    @EnvironmentObject var loc: Loc
    @Binding var picked: Bool

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.06, green: 0.10, blue: 0.18),
                                    Color(red: 0.10, green: 0.20, blue: 0.32)],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 28) {
                Text("🚄").font(.system(size: 70))
                Text("Выберите язык / Select language")
                    .font(.system(size: 26, weight: .semibold))
                HStack(spacing: 20) {
                    ForEach(Lang.allCases) { l in
                        Button {
                            loc.lang = l
                            withAnimation { picked = true }
                        } label: {
                            Text(l.title)
                                .font(.system(size: 22, weight: .bold))
                                .frame(width: 200, height: 70)
                                .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.12)))
                                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.3)))
                        }
                    }
                }
            }
            .foregroundColor(.white)
        }
    }
}
