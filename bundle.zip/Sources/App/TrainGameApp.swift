import SwiftUI

@main
struct TrainGameApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

struct RootView: View {
    @StateObject private var loc = Loc()
    @State private var stage = 0

    var body: some View {
        Group {
            switch stage {
            case 0: LanguageView(next: { withAnimation { stage = 1 } }).environmentObject(loc)
            case 1: TransportView(next: { withAnimation { stage = 2 } }).environmentObject(loc)
            default: MenuView().environmentObject(loc)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct LanguageView: View {
    @EnvironmentObject var loc: Loc
    let next: () -> Void

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.04, green: 0.07, blue: 0.14),
                                    Color(red: 0.08, green: 0.16, blue: 0.28)],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 26) {
                Text("\u{1F684}").font(.system(size: 64))
                Text("Выберите язык / Select language")
                    .font(.system(size: 24, weight: .semibold))
                HStack(spacing: 18) {
                    ForEach(Lang.allCases) { l in
                        Button {
                            loc.lang = l
                            next()
                        } label: {
                            Text(l.title)
                                .font(.system(size: 21, weight: .bold))
                                .frame(width: 190, height: 66)
                                .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.12)))
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.3)))
                        }
                    }
                }
            }
            .foregroundColor(.white)
        }
    }
}

struct TransportView: View {
    @EnvironmentObject var loc: Loc
    let next: () -> Void

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.04, green: 0.07, blue: 0.14),
                                    Color(red: 0.08, green: 0.16, blue: 0.28)],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 22) {
                Text(loc.t("chooseTransport"))
                    .font(.system(size: 24, weight: .heavy, design: .monospaced))
                    .foregroundColor(.white)
                HStack(spacing: 22) {
                    trainCard
                    metroCard
                }
            }
            .padding(20)
        }
    }

    private var trainCard: some View {
        Button { next() } label: {
            VStack(spacing: 14) {
                Text("\u{1F684}").font(.system(size: 74))
                Text(loc.t("modeTrain"))
                    .font(.system(size: 22, weight: .bold)).foregroundColor(.white)
                Text(loc.t("modeTrainD"))
                    .font(.system(size: 12)).foregroundColor(.white.opacity(0.6))
                    .multilineTextAlignment(.center)
            }
            .frame(width: 260, height: 240)
            .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.10)))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(red: 0.9, green: 0.3, blue: 0.25), lineWidth: 2))
        }
    }

    private var metroCard: some View {
        ZStack {
            VStack(spacing: 14) {
                Text("\u{1F687}").font(.system(size: 74)).opacity(0.4)
                Text(loc.t("modeMetro"))
                    .font(.system(size: 22, weight: .bold)).foregroundColor(.white.opacity(0.5))
                Text(loc.t("modeMetroD"))
                    .font(.system(size: 12)).foregroundColor(.white.opacity(0.35))
                    .multilineTextAlignment(.center)
            }
            .frame(width: 260, height: 240)
            .background(RoundedRectangle(cornerRadius: 20).fill(Color.black.opacity(0.35)))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.12)))

            Chains()

            Text(loc.t("inDev"))
                .font(.system(size: 15, weight: .heavy, design: .monospaced))
                .foregroundColor(.white)
                .padding(.horizontal, 14).padding(.vertical, 7)
                .background(Capsule().fill(Color(red: 0.75, green: 0.15, blue: 0.15)))
                .rotationEffect(.degrees(-12))
        }
        .frame(width: 260, height: 240)
    }
}

struct Chains: View {
    var body: some View {
        Canvas { ctx, size in
            for diag in [true, false] {
                var path = Path()
                if diag {
                    path.move(to: CGPoint(x: 6, y: 6))
                    path.addLine(to: CGPoint(x: size.width - 6, y: size.height - 6))
                } else {
                    path.move(to: CGPoint(x: size.width - 6, y: 6))
                    path.addLine(to: CGPoint(x: 6, y: size.height - 6))
                }
                ctx.stroke(path, with: .color(Color(white: 0.16)),
                           style: StrokeStyle(lineWidth: 16, lineCap: .round))
                ctx.stroke(path, with: .color(Color(white: 0.55)),
                           style: StrokeStyle(lineWidth: 13, lineCap: .round, dash: [5, 6]))
                ctx.stroke(path, with: .color(Color(white: 0.30)),
                           style: StrokeStyle(lineWidth: 4, lineCap: .round, dash: [5, 6]))
            }
        }
        .allowsHitTesting(false)
    }
}
